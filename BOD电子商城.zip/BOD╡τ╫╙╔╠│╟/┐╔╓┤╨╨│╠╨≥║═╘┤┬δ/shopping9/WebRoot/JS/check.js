function checkLogin(){
	var username = document.getElementById("username").value;
	var pwd = document.getElementById("PWD").value;
	
	if(username==""||username==null){
		if(pwd ==""||pwd==null){
			document.getElementById("userinfo").style.color="red";
			document.getElementById("userinfo").innerHTML="*";
			document.getElementById("pwdinfo").style.color="red";
			document.getElementById("pwdinfo").innerHTML="*";
			alert("用户名和密码不能为空");
			return false;
		} else{
			document.getElementById("userinfo").style.color="red";
			document.getElementById("userinfo").innerHTML="*";
			alert("用户名不能为空！！"); 
			document.getElementById("pwdinfo").innerHTML="";
			return false;
		}
	} else{
		if(pwd ==""||pwd==null){
			document.getElementById("pwdinfo").style.color="red";
			document.getElementById("pwdinfo").innerHTML="*";
			document.getElementById("userinfo").innerHTML="";
			alert("密码不能为空！！");
			return false;
		}else {
			var code1 = document.getElementById("validatecode1").value;
			var code2 = document.getElementById("validatecode2").value;
			
			//先让恒为false
			if(false){
				
				document.getElementById("codeImg").click();
				return false;
			} else return true;
		};
	}
}

function checkuid(){
	var u = document.getElementById("userid").value;
	var name = document.getElementById("name").value;
	var dd = /^[0-9]*[1-9][0-9]*$/;
	var pp = /[0-9]+/;
	if (name != "" && name != null) {
		if ((u!=""&&u!=null)&&!pp.exec(u)) {
			alert("会员编号只能为数字");
			//document.search.userid.focus();
			return false;
		}
		return true;
	} else if (!pp.exec(u)) {
		alert("会员编号只能为数字");
		//document.search.userid.focus();
		return false;
	} else
		return true;
}

function checkPassword(){
	var pwd1 = document.getElementById("pwd1").value;
	var pwd2 = document.getElementById("pwd2").value;
	
	var patrn=/^[a-zA-Z0-9_]{6,20}$/;
	var flag = false;
	if (pwd1 == "" || pwd1 == null) {
		document.getElementById("pwd1info").innerHTML="请输入旧密码";
		document.modifypwd.pwd1.focus();
	} else if (pwd2 == "" || pwd2 == null) {
		document.getElementById("pwd1info").innerHTML = "";
		document.getElementById("pwd2info").style.color = "red";
		document.getElementById("pwd2info").innerHTML = "*密码不能为空";
		document.modifypwd.pwd2.focus();
	} else if (pwd2.match(patrn) != pwd2) {
		document.getElementById("pwd1info").innerHTML = "";
		document.getElementById("pwd2info").style.color = "red";
		document.getElementById("pwd2info").innerHTML = "*密码为6-10位的数字字母或下划线";
	} else {
		flag = true;
	}
	return flag;
}


function checkInfo(){
	var flag =false;
	if((((checkname()&&checkadd())&&checkpro())&&checkpost())&&checktel()){
		return flag = true;
	}
	return flag;
}

function checkname(){
	var name = document.getElementById("name").value;
	if(name==""||name==null){
		document.getElementById("nameinfo").style.color="red";
		document.getElementById("nameinfo").innerHTML="请输入姓名";
		return false;
	}else return true;
}

function checkadd(){
	var add = document.getElementById("add").value;
	if(add==""||add==null){
		document.getElementById("nameinfo").innerHTML="";
		document.getElementById("addinfo").style.color="red";
		document.getElementById("addinfo").innerHTML="请输入地址";
		return false;
	}else return true;
}
function checkpro(){
	var province = document.getElementById("province").value;
	if(province=="请选择"){
		document.getElementById("nameinfo").innerHTML="";
		document.getElementById("addinfo").innerHTML="";
		document.getElementById("locinfo").style.color="red";
		document.getElementById("locinfo").innerHTML="请选择地区";
		return false;
	}else return true;
}
function checkpost(){
	var post = document.getElementById("post").value;
	if(post==""||post==null){
		document.getElementById("nameinfo").innerHTML="";
		document.getElementById("addinfo").innerHTML="";
		document.getElementById("locinfo").innerHTML="";
		document.getElementById("postinfo").style.color="red";
		document.getElementById("postinfo").innerHTML="请输入邮编";
		return false;
	}else return true;
}
function checktel(){
	var tel = document.getElementById("tel").value;
	if(tel==""||tel==null){
		document.getElementById("nameinfo").innerHTML="";
		document.getElementById("addinfo").innerHTML="";
		document.getElementById("locinfo").innerHTML="";
		document.getElementById("postinfo").innerHTML="";
		document.getElementById("telinfo").style.color="red";
		document.getElementById("telinfo").innerHTML="请输入电话";
		return false;
	}else return true;
}














