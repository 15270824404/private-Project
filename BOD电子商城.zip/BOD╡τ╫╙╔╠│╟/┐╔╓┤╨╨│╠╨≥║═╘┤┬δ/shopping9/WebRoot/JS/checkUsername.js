function checkUsername(){
	var username = document.getElementById("usernamecheck").value;
	var url = "checkUsernameServlet?username="+username;
	sendRequest(url);
}


//----------------------------------AJAX验证注册时会员名是否存在----------------------------------//

 // 创建XMLHttpRequest对象
	function createXMLHttpRequest() {
 		if (window.XMLHttpRequest) {
	      //Mozilla 浏览器 
	      XMLHttpReq = new XMLHttpRequest();
	    } else{
	     // IE浏览器
	      if (window.ActiveXObject) {
	       try {
	    	   XMLHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
	         }catch (e) {
	            try {
	            	XMLHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
	                             }catch (e) { }
	                      }
	           }
	        }
       } 

   //发送客户端的请求
   function sendRequest(url)
   {
       //调用创建XMLHttpRequest对像方法
	   createXMLHttpRequest();
	   XMLHttpReq.open("GET",url,true);
   	//指定响应函数
	   XMLHttpReq.onreadystatechange = handleResponse;
   	//发送请求
	   XMLHttpReq.send(null);
   	
   }

   function showInfo()
   {
	 	if(XMLHttpReq.status == 200)//信息已经成功返回，开始处理信息
	 	{
	 		//接收服务器返回的内容(XML)
  	 		var info = "";
  	 		var xml = XMLHttpReq.responseXML;
  	 		//获得节点的内容
  	 		info = xml.getElementsByTagName("root")[0].firstChild.nodeValue;
  	 		if(info=="3")
  	 		{//把内容设置到控件中
  	 			document.getElementById("userNameInfo").innerHTML="<img src='/shopping8/images/reg18.gif'>"+"*&nbsp;此用户名已存在！！";
  	 		}
  	 		else if(info=="1")
  	 		{	
  	 			document.getElementById("userNameInfo").style.color="green";
  	 			document.getElementById("userNameInfo").style.style="bold";
  	 			document.getElementById("userNameInfo").innerHTML="<img src='/shopping8/images/reg02.jpg'>"+"&nbsp;恭喜您，用户名可用！！";
  	 		}
  	 		else
  	 		{
  	 			document.getElementById("userNameInfo").innerHTML="<img src='/shopping8/images/reg18.gif'>"+"&nbsp;用户名不能为空";
  	 		}
  	 	}
   }
   
   //处理响应结果
   function handleResponse()
   {
   	 	// 判断对象状态
  	 	if(XMLHttpReq.readyState == 4)
  	 	{
  	 		setTimeout("showInfo()",1500);	//延迟验证
  	 		document.getElementById("userNameInfo").innerHTML="<font color='red'>检测中..." +
  	 				"&nbsp;&nbsp;</font><img src='/shopping8/images/05043122.gif'>";
      	}
   }

   
   
   
 //-------------------------------------密码验证-----------------------//  

function validatePassword(){
	var patrn=/^[a-zA-Z0-9_]{6,20}$/;
	var password=document.getElementById("password1").value;
	var flag = false;
	if(password==""||password==null){
		document.getElementById("passWordInfo").style.color="red";
		document.getElementById("passWordInfo").innerHTML="*密码不能为空";
	}
	else
		if(password.match(patrn)!=password){
			document.getElementById("passWordInfo").style.color="red";
			document.getElementById("passWordInfo").innerHTML="*6-10位的数字字母或下划线";
		}else{
			document.getElementById("passWordInfo").style.color="green";
			document.getElementById("passWordInfo").innerHTML="<img src='/shopping8/images/reg02.jpg'>";
			flag = true;
		}
	
	return flag;
}

//-------------------------------------确认密码-----------------------//

function validateRePassword(){     //密码验证
	var flag = false;
	var password=document.getElementById("password1").value;
	var repassword=document.getElementById("password2").value;
	if(password==""||password==null){
		document.getElementById("passWordInfo").style.color="red";
		document.getElementById("passWordInfo").innerHTML="*请输入密码！";
	}if(password!=""||password!=null){
		validatePassword();
		if(repassword==""||repassword==null){
			//document.getElementById("passWordInfo").innerHTML="*";
			document.getElementById("passWord2Info").style.color="red";
			document.getElementById("passWord2Info").innerHTML="*密码不能为空";
		}
		else{
			if(password==repassword){
				//document.getElementById("passWordInfo").innerHTML="*";
				document.getElementById("passWord2Info").style.color="green";
				document.getElementById("passWord2Info").innerHTML="<img src='/shopping8/images/reg02.jpg'>";
				flag = true;
			}else{
				//document.getElementById("passWordInfo").innerHTML="*";
				document.getElementById("passWord2Info").style.color="red";
				document.getElementById("passWord2Info").innerHTML="您两次输的密码不一致！";
				}		     
		    }
	}
	return flag;
}
//对电子邮件的验证
function checkEmail() {
	var temp = document.getElementById("mail").value;
	var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	if (temp!= "") {
		if (!reg.test(temp)) {
			document.getElementById("verifyemail").style,color="red";
			document.getElementById("verifyemail").innerHTML="*请输入有效的E_mail！";
			return false;
		} else{
			document.getElementById("verifyemail").innerHTML="<img src='/shopping8/images/reg02.jpg'>"
			return true;
		}
	}else {
		document.getElementById("verifyemail").innerHTML="邮箱为空";
		return false;
	}
}

function checkRealname(){
	var realname = document.getElementById("Realname").value;
	if(realname==""||realname==null){
		document.getElementById("verifyRealname").innerHTML="<img src='/shopping8/images/reg18.gif'>";
		//document.form.Realname.focus();
		return false;
	}else{
		document.getElementById("verifyRealname").innerHTML="<img src='/shopping8/images/reg02.jpg'>";
		return true;
	}
}

function checkAdd(){
	var add = document.getElementById("Add").value;
	if(add==""||add==null){
		document.getElementById("verifyAdd").innerHTML="<img src='/shopping8/images/reg18.gif'>";
		//document.form.Add.focus();
		return false;
	}else{
		document.getElementById("verifyAdd").innerHTML="<img src='/shopping8/images/reg02.jpg'>";
		return true;
	}
}

function checkPost(){
	var post = document.getElementById("post").value;
	var reg = /^[0-9]{6,6}$/;
	if(post==""||post==null){
		document.getElementById("verifyPost").innerHTML="<img src='/shopping8/images/reg18.gif'>";
		//document.form.Postcode.focus();
		return false;
	}else{
		if(!reg.test(post)){
			document.getElementById("verifyPost").style.color="red";
			document.getElementById("verifyPost").innerHTML="<img src='/shopping8/images/reg18.gif'>";
			return false;
		}else{
			document.getElementById("verifyPost").innerHTML="<img src='/shopping8/images/reg02.jpg'>";
			return true;
		}
	}
}

function checkTel() {
	var tel = document.getElementById("Tel").value;
	var pattern = /(^[0-9]{3,4}\-[0-9]{3,8}$)|(^[0-9]{3,8}$)|(^\([0-9]{3,4}\)[0-9]{3,8}$)|(^0{0,1}1[0-9]{10}$)/;
	if (tel == "" || tel == null) {
		document.getElementById("verifyTel").style.color="red";
		document.getElementById("verifyTel").innerHTML="号码为空！！";
		return false;
	} else {
		if (!pattern.test(tel)) {
			document.getElementById("verifyTel").style.color="red";
			document.getElementById("verifyTel").innerHTML="请输入正确号码";
			return false;
		} else {
			document.getElementById("verifyTel").innerHTML="<img src='/shopping8/images/reg02.jpg'>";
			return true;
		}
	}
}



function checkAll(){
	flag = validatePassword() && validateRePassword();
	flag = flag && checkEmail();
	flag = flag && checkRealname();
	flag = flag && checkPost();
	flag = flag && checkAdd();
	flag = flag && checkTel();
	if(!flag){
		document.getElementById("msg").style.color="red";
		document.getElementById("msg").innerHTML="请检查各项不能为空";
	}
	return flag;
}



//密码强度




