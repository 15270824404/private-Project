var ar = new Array();
$(document).ready(function(){
	  if(!navigator.cookieEnabled){
		 alert("请在您的浏览器internet选项中,选择支持cookie，否则您将无法购物");
	  }
		$.getJSON("./selGoodsTypeServlet.do",null,function(data){
			var a = data;
			var objSel = $("#supertype");
			var objSpan = $("#menutree");
            objSel.change(function(){           	          	
               	    var c = objSel.val(); 
               	    $("#typeID").empty();              	   
    				$.getJSON("./selMiddGoodsType.do?id="+c,null,function(data){
    					var b = data;
    					var objSel = $("#typeID");
    					for(var n=0;n<b.length;n=n+1){
    						var objOption = $("<option>");
    						objOption.val(data[n].id);    
    						objOption.html(data[n].typename);
    						objSel.append(objOption);   						
    					}
    				});	
            	
            });
            
			for(var n=0;n<a.length;n=n+1){
				var objOption = $("<option>");
				ar[n] = data[n];
				objOption.val(data[n].id);    
				objOption.html(data[n].typename);
				objSel.append(objOption);
				var objOl = $("<ul onclick=\"show(this)\">");
				objOl.addClass(""+data[n].id);				
				objOl.val(data[n].id);		
				objOl.html(data[n].typename);
				objSpan.append(objOl);
			}		
//			for (var n = 0; n<a.length;n = n+1){
//				var objClass = ar[n].id;
//				$("."+objClass).click(function(){
//					$.getJSON("./selMiddGoodsType.do?id="+objClass,null,function (data){
//						var d = data;
//						for (var m = 0; m<d.length;m=m+1){
//							objLi= $("<li>");
//							objLi.val(d[m].id);
//							objLi.html("<a href=''>"+d[m].typename+"</a>");
//							$("."+objClass).append(objLi);
//						}					
//					});
//				
//				});
//			
//			}
		}); 
		
	
});

function show(data){
	var objUl = data;
	$.getJSON("./selMiddGoodsType.do?id="+objUl.value,null,function(data1){	
	var d = data1;
	for (var m=0;m<d.length;m=m+1){
		var objLi = $("<li>");
		objLi.val(data1[m].id);
		objLi.html(data1[m].typename);
		objUl.append(objLi);
	}
});
}








function cancelOrderDetail(value){
	var odid = value;
	var id= "orderDetail"+odid;	
	var objSpanC = document.getElementById(id).innerHTML = "";
	$.getJSON("./cancelOrderDetail.do?odid="+odid,null,function(data){
		var oid =data['oid'];		
		if (oid!=0){
			var pid = "order"+oid;
			 var objSpanP = document.getElementById(pid).innerHTML="";
		}
	});
	
}

function cancelOrder(value){
	var oid = value;
	var id = "order"+oid;
	var objSpanP = document.getElementById(id).innerHTML="";
	$.getJSON("./cancelOrder.do?oid="+oid,null,function(){});
}

function confirmOrder(value){
	var oid = value;
	var id ="orderStatus"+oid;	
	var objSpanS = document.getElementById(id).innerHTML="已收到";
	$.getJSON("./confirmOrder.do?oid="+oid,null,function(){});

}

function sendOrder(value){
	var oid = value;	
	$.getJSON("./sendOrder.do?oid="+oid,null,function(){
		
	});	
	$("#send").html("");
}

function showWinForOrder(id,flag){
	$("#win").css("top","55%");
	$("#win").css("display","block");
	if (flag == 1){
		$("#content1").html("确认删除订单商品嘛?");
		$(".confirm").attr("name",id);
		$(".confirm").attr("id",flag);
	}
	if (flag == 2){
		$("#content1").html("系统尚未发货，确认删除整个订单吗?");
		$(".confirm").attr("name",id);
		$(".confirm").attr("id",flag);
	
	}
	if (flag == 3){
		$("#content1").html("确认到货了嘛？否则可能钱财两空!");
		$(".confirm").attr("name",id);
		$(".confirm").attr("id",flag);

	}
	if (flag ==4){
		$("#content1").html("确认发货了？");
		$(".confirm").attr("name",id);
		$(".confirm").attr("id",flag);
	}
}
function closeWinForOrder(){
	$("#win").css("display","none");
}

function makeForOrder(value){

	var id = value.name;
	var flag = value.id;
	if (flag == 1){
		closeWinForOrder();
		cancelOrderDetail(id);
	}
	if (flag == 2){
		closeWinForOrder();
		cancelOrder(id);
	}
	if (flag == 3){
		closeWinForOrder();
		confirmOrder(id);
		
	}
	if (flag ==4){
		closeWinForOrder();
		sendOrder(id);
	}
}



function monthChange1(){
	var objY1 =$("#year1");
	
	var year = objY1.val();
	var objM1 = $("#month1");
	var month = objM1.val();
	var objD1 = $("#day1");
	objD1.empty();
	var day =31;
	if (month==4||month == 6||month == 9||month == 11){
		day = 30;
	}
	if (year /4 == 0 && month ==2){
		day =29;
	}else if(year/4 !=0 && month==2){
		day =28;
	}
	for (var i =1;i<=day;i=i+1){
		var objO1 = $("<option>");
		objO1.val(i);
		objO1.html(i);	
		objD1.append(objO1);
	}
	
}


function monthChange2(){
	var objY2 =$("#year2");	
	var year = objY2.val();
	var objM2 = $("#month2");
	var month = objM2.val();
	var objD2 = $("#day2");
	objD2.empty();
	var day =31;
	if (month==4||month == 6||month == 9||month == 11){
		day = 30;
	}
	if (year /4 == 0 && month ==2){
		day =29;
	}else if(year/4 !=0 && month==2){
		day =28;
	}
	for (var i =1;i<=day;i=i+1){
		var objO2 = $("<option>");
		objO2.val(i);
		objO2.html(i);	
		objD2.append(objO2);
	}
	
}

function showWindow(){
	//$("#win").css("display","block");
	$("#nullwin").slideDown("slow");
	
}
function closeWindow(){	
	$("#nullwin").fadeOut(600); 
}


function addFavDetail(gid,uid){
	if (uid != 0){
		$.getJSON("addFavDetail.do?gid="+gid+"&uid="+uid,null,function(data){
			var flag = data['flag'];
			if (flag == 1){
				showWin2("confirm","成功加入收藏！");
				closeWin();
			}else{
				showWin2("confirm","收藏夹已添加该商品！！");
				closeWin();
			}
		});		
	}else{
		showWin2("confirm","请您先登录：");
		closeWin();
	}	

}

function showFav(gid,value){
	var name = value.id;
	showWin(gid,name,"是否要将此商品加入收藏嘛？",2);
}




function showWinforBuy(value){
	var name = value.id;
	var gid = value.name;
	
	$.getJSON("checkCartExists.do?gid="+gid,null,function(data){
		var flag =data['flag'];

		if (flag!=0){			
			showWin(gid,name,"确认添加到你的购物车嘛？",1);
		}else{
			showWin2(name,"此商品已在您的购物车中了！");
		}
	});
}



function showWin(id,name,content1,flag){//业务div
	
	if (flag ==1){
		var offset = $("#"+name).offset();
		$("#win").css("top",offset.top-50);
		$("#win").css("display","block");
		$(".content1").html(content1);
		var objHidden1 = $("#hiddenID");
		$(".confirm").attr("name",id);
		$(".confirm").attr("id",flag);
	}
	if (flag==2){
		var offset = $("#"+name).offset();
		$("#win").css("top",offset.top-50);
		$("#win").css("display","block");
		$("#content1").html(content1);
		var objHidden1 = $("#hiddenID");
		$(".confirm").attr("name",id);
		$(".confirm").attr("id",flag);
		objHidden1.val(id);
	}	
}


function doBuyOrFav(value,uid){
	var flag = value.id;
	if (flag == 1){
		 addCartDetail(value);
	}
	if (flag == 2){
		var gid = value.name;
		addFavDetail(gid,uid);
	}
}

function closeWin(){
    $("#win").css("display","none");
    $("#wind").css("display","none");
    $("#nullwin").css("display","none");
}

function showWin2(name,content2){//状态div
	var offset;
	if (name=="confirm"){
		offset=$(".confirm").offset();
	}else{
		offset = $("#"+name).offset();
	}		
	$("#win2").css("top",offset.top-50);
	$("#content2").html(content2);
	$("#win2").css("display","block");
}

function closeWin2(){
    $("#win2").css("display","none");
}

function addCartDetail(value){
	var gid=value.name;
	$.getJSON("addCartDetail.do?gid="+gid,null,function(){});		
	showWin2("confirm","添加成功");
	closeWin();
}


function showWinForAddGood(value){
	var id = value.id;
	//var cpage = value.currentPage;
	$("#wind").slideDown("slow");
	$("#wind").css("display","block");
	var objHidden1 = $("#hiddenID");
	//var objHidden1 = $("hiddenCPAGE");
	objHidden1.val(id);
}
function addComment(uid,gid){	
	if (uid!=0){
		$.getJSON("./checkComment.do?uid="+uid+"&gid="+gid,null,function(data){
			var flag = data['flag'];
			if (flag == 1){
				showWin3(uid,gid);
			}
			else{
				showWin4("请亲先购买商品再评论");
			}
		});
	}else{
		showWin4("请先登录:");
	}
}

function showWin3(uid,gid){
	var offset = $("#comment").offset();
	$("#win3").css("top",offset.top-100);
	$("#win3").css("display","block");
	var objHidden1 = $("#hiddenGID");
	objHidden1.val(gid);
	var objHidden2 = $("#hiddenUID");
	objHidden2.val(uid);
}
function closeWin3(){
	$("#win3").css("display","none");
}


function showWin4(content){
	$("#win4").css("top","50%");
	$("#win4").css("display","block");
	$("#content4").html(content+"");
	
}
function closeWin4(){
	$("#win4").css("display","none");
}


