$(document).ready(bigSort);
function bigSort() {

	$.get("./selGoodsTypeServlet.do", null, callback1);

}
function callback1(data) {
	var objB = eval(data);
	var objT = $("#tree");

	for ( var i = 0; i < objB.length; i++) {

		var id = objB[i]["id"];
		var objdiv1 = $("<div id=\"qqq\" onclick=\"showSmallSort("+id+")\"  ondblclick=\"closeSmallSort("+id+")\"  >");
		objdiv1.addClass("bigSort"+id);
		objdiv1.html(objB[i]["typename"]);
		objT.append(objdiv1);
		smallSort(id);
	}
}

function smallSort(id) {

	$.get("./selMiddGoodsType.do?id=" + id, null, function(data) {
		var objS = eval(data);
		var objSmall = $(".bigSort"+id);
		
		for ( var i = 0; i < objS.length; i++) {

			var fid = objS[i]["id"];
			var objdiv2 = $("<div id=\"www\" style=\"display: none\"  onclick=\"showGoods("+fid+")\" >");
			objdiv2.addClass("smallSort" + id);		
			objdiv2.html(objS[i]["typename"]);
			//objdiv2.style.display("none");
			objSmall.append(objdiv2);
			
		}
	});
}
function showSmallSort(id){
	$(".smallSort"+id).slideDown(200);
}
function closeSmallSort(id){
	$(".smallSort"+id).fadeOut(300);
}
function showGoods(fid){
	
	window.location = "showGoodsByType.do?fid="+fid;

	
}
