function showTree(a){
	for (var n=0;n<a.length;n++){	
		addtree('<B>'+a[n].typename+'</B>'); 
        //alert(a[n].typename);		
		}
	createtree();
	}
