package com.shopping.dao;

import java.util.List;

import com.shopping.pojo.Comment;
import com.shopping.util.PageUtil;

public interface CommentDao {
	public void addComment(int uid,int gid,String content);
	public List<Comment> getCommentByGid(int gid,PageUtil page);
	public void deleteCommentByUid(int uid);
	public void deleteCommentByGid(int gid);
	public boolean checkComment(int uid,int gid);
}
