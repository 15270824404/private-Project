package com.shopping.dao;

import java.util.List;

import com.shopping.pojo.FavDetail;
import com.shopping.util.PageUtil;

public interface FavDetailDao {
	public List<FavDetail> getFavDetailsByFid(int uid,PageUtil pageUtil);
	public void deleteFavDetail(int id);
	public boolean addFavDetail(int uid,int gid);
}
