package com.shopping.dao;

import java.util.List;

import com.shopping.pojo.Good;
import com.shopping.util.PageUtil;

public interface GoodDao{
    public Good findGoodById(int id);
    public void addGood(int supertype,int typeID,String goodsName,int goodsAmount,double marketprice,double price,double rebate,String sale,String img,String content); 
    public void renewGood(int id,int supertype,int typeID,String goodsName,int goodsAmount,double marketprice,double price,double rebate,String sale,String img,String content);
    public void renewGoodStatus(String isvalid,int id);
    public void renewGoodAmount(int amount,int id);
    public int selectGoodAmount(int id);
    public List<Good> findSaleGoods();
    public List<Good> findBestGoods();
    public List<Good> findNewGoods(PageUtil pageUtil);
    public List<Good> findGoods(PageUtil pageUtil);
    public List<Good> findAllGoods();
    public List<Good> searchGoods(String gname,int gtid);
    public List<Good> searchGoodsByBGd(String gname,int gtid,int gsmallid);
    public List<Good> selGoodByGType(int id);
}
