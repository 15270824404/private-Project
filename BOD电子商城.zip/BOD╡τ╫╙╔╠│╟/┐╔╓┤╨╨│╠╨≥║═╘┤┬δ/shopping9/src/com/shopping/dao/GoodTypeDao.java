package com.shopping.dao;

import java.util.List;

import com.shopping.pojo.GoodType;

public interface GoodTypeDao {
	public List<GoodType> findGoodTypeById(int id);
	public List<GoodType> findTopGoodType();
	public List<GoodType> findMiddleGoodType(int id);
	public void addTopGood(String typename,String information);
	public void addMiddleGood(String typename,String information,int fid);
	public void renewTopGoodType(int id,String typename,String information);
	public void renewMiddleGoodType(int id,String typename,String information);
	public void removeMiddleGoodType(int id);
	public void removeTopGoodType(int id);
}
