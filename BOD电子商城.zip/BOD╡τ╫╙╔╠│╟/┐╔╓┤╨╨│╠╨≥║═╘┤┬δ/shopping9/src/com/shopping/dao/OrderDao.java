package com.shopping.dao;

import java.util.List;

import com.shopping.pojo.Order;
import com.shopping.util.PageUtil;

public interface OrderDao {
	public List<Order> showValidOrdersByUid(int uid,PageUtil pageUtil);//ǰ̨��ʾ
//	public List<Order> showAllOrders(); //��̨��ʾ
	public int addOrder(Order order,int uid);
//	public void cancelOrder(String status);
	public Order findOrderById(int oid);
	public void deleteOrderById(int id);
	public void updateOrderStatus(int id,int status);
	public List<Order> showOrders(int status,String num,PageUtil pageUtil);
	public double getUserMoney(int uid);
//	public boolean checkEmptyOrder(int id);
	public Order getLastOrder();
	

}
