package com.shopping.dao;

import java.util.List;

import com.shopping.pojo.OrderDetail;

public interface OrderDetailDao {
	public List<OrderDetail> findOrderDetailsByOid(int oid);
	public void addOrderDetail(int gid,int oid,int gnum);
	public int deleteOrderDetailById(int id);
	public double returnOrderTotalPrice(int oid);
	public void deleteOrderDetailByOid(int oid);
	public int getGoodSalesVolume(int gid);
	public int getOrderDetailsOid(int id);
	public boolean checkEmptyOrder(int oid);
	public List<OrderDetail> getAllGoodsByUid(int uid);
}
