package com.shopping.dao;

public class OrderId {
	private static int id = 1;
	public static int getOrderId()
	{
		id++;
		return id;
	}
}
