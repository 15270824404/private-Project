package com.shopping.dao;

import java.util.List;

import com.shopping.pojo.User;

public interface UserDao {
	public int saveUser(User user);
	
	public User findUserByUsername(String username);
	
	public User findUserById(int id);
	
	public List<User> findUserByUid(int id);
	
	public void changeUserStatus(User user);
	
	public void changeUserPassword(User user,String oldPassword);
	
	public void changeUserInformation(User user);

	public List<User> getUsers(int beginIndex,int userLength);
	
	public int getUserCount();
	
	public List<User> findUsersByUsername(String username);
}
