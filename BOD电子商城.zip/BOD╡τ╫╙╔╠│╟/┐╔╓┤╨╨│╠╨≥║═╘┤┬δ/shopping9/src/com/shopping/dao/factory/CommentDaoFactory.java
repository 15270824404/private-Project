package com.shopping.dao.factory;

import com.shopping.dao.CommentDao;
import com.shopping.util.PropUtil;

public class CommentDaoFactory {
	private static CommentDao commentDao;
	public static CommentDao getInstance(String path,String name){
//		OrderDao orderDao =null;
		try {
			commentDao = (CommentDao) Class.forName(PropUtil.getProp(path).getProperty(name)).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return commentDao;
	}
}
