package com.shopping.dao.factory;

import com.shopping.dao.FavDetailDao;
import com.shopping.util.PropUtil;

public class FavDetailDaoFactory {
	private static FavDetailDao favDetailDao;
	public static FavDetailDao getInstance(String path,String name){
//		OrderDao orderDao =null;
		try {
			favDetailDao = (FavDetailDao) Class.forName(PropUtil.getProp(path).getProperty(name)).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return favDetailDao;
	}
}
