package com.shopping.dao.factory;

import java.util.Properties;

import com.shopping.dao.GoodDao;
import com.shopping.util.PropUtil;

public class GoodDaoFactory {
      public static GoodDao getInstance(String path,String name){
    	  GoodDao goodDao = null;
    	  try {
    		Properties prop = PropUtil.getProp(path);
			goodDao = (GoodDao)Class.forName(prop.getProperty(name)).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  return goodDao;
      }
}
