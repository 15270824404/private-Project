package com.shopping.dao.factory;

import java.util.Properties;

import com.shopping.dao.GoodTypeDao;
import com.shopping.util.PropUtil;

public class GoodTypeDaoFactory {
    
	  public static GoodTypeDao getInstance(String path,String name){
    	GoodTypeDao goodTypeDao = null;
    	try {
    		Properties prop = PropUtil.getProp(path);
			goodTypeDao = (GoodTypeDao)Class.forName(prop.getProperty(name)).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return goodTypeDao;
    }
}
