package com.shopping.dao.factory;

import com.shopping.dao.NoticeDao;
import com.shopping.util.PropUtil;

public class NoticeDaoFactory {
	private static NoticeDao noticeDao;
	public static NoticeDao getInstance(String path,String name){
		try {
			noticeDao = (NoticeDao) Class.forName(PropUtil.getProp(path).getProperty(name)).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noticeDao;
	}
}
