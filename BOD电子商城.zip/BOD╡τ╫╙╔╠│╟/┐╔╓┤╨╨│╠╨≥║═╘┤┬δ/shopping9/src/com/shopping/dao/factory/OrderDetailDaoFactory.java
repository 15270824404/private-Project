package com.shopping.dao.factory;

import com.shopping.dao.OrderDetailDao;
import com.shopping.util.PropUtil;


public class OrderDetailDaoFactory {
	public static OrderDetailDao getInstance(String path,String name){
		OrderDetailDao orderDetailDao = null;
		
			try {
				orderDetailDao = (OrderDetailDao) Class.forName(PropUtil.getProp(path).getProperty(name)).newInstance();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return orderDetailDao;
	}
}
