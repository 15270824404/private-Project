package com.shopping.dao.factory;

import com.shopping.dao.UserDao;
import com.shopping.util.PropUtil;

public class UserDaoFactory {
	
	public static UserDao getInstance(String path,String name){
		UserDao userDao = null;
		try {
			userDao = (UserDao)Class.forName(PropUtil.getProp(path).getProperty(name)).newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return userDao;
	}
}
