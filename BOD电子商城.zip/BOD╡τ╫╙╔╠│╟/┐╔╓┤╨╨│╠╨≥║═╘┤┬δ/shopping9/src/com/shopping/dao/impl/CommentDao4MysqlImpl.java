package com.shopping.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.shopping.dao.CommentDao;
import com.shopping.dao.GoodDao;
import com.shopping.dao.OrderDetailDao;
import com.shopping.dao.UserDao;
import com.shopping.dao.factory.GoodDaoFactory;
import com.shopping.dao.factory.OrderDetailDaoFactory;
import com.shopping.dao.factory.UserDaoFactory;
import com.shopping.pojo.Comment;
import com.shopping.pojo.Good;
import com.shopping.pojo.OrderDetail;
import com.shopping.util.DBUtils;
import com.shopping.util.PageUtil;

public class CommentDao4MysqlImpl implements CommentDao {
	private static GoodDao goodDao;
	private static UserDao userDao;
	private static OrderDetailDao orderDetailDao;
	static {
		goodDao = GoodDaoFactory.getInstance("./daoConfig.properties", "GoodDao");
		userDao = UserDaoFactory.getInstance("./daoConfig.properties", "UserDao");
		orderDetailDao = OrderDetailDaoFactory.getInstance("./daoConfig.properties", "OrderDetailDao");
		
	}

	public void addComment(int uid, int gid, String content) {
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "insert into t_comment values (null,now(),?,?,?)");
		try {
			pstmt.setInt(1, gid);
			pstmt.setInt(2, uid);
			pstmt.setString(3, content);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void deleteCommentByGid(int gid) {
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "delete from t_comment where gid= ?");
		try {
			pstmt.setInt(1, gid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void deleteCommentByUid(int uid) {
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "delete from t_comment where uid = ?");
		try {
			pstmt.setInt(1, uid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public List<Comment> getCommentByGid(int gid,PageUtil pageUtil) {
		List<Comment> comments = new ArrayList<Comment>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_comment where gid =? limit ?,?");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, gid);
			pstmt.setInt(2, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
			pstmt.setInt(3, pageUtil.getPageRecord());
			rs = pstmt.executeQuery();
			while (rs.next()){
				Comment comment = new Comment();
				comment.setId(rs.getInt(1));
				comment.setAddtime(rs.getTimestamp(2));
				comment.setGood(goodDao.findGoodById(rs.getInt(3)));
				comment.setUser(userDao.findUserById(rs.getInt(4)));
				comment.setContent(rs.getString(5));
				comments.add(comment);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int total = getCommandAmount(gid);
		if(total % pageUtil.getPageRecord()==0){
			pageUtil.setTotalRecord(total);
			pageUtil.setTotalPage(total/pageUtil.getPageRecord());
			
		}else{
			pageUtil.setTotalRecord(total);
			pageUtil.setTotalPage(total/pageUtil.getPageRecord()+1);
		}
		return comments;
	}
	
	public boolean checkComment(int uid,int gid){
		boolean flag = false;
		List<OrderDetail> orderDetails = orderDetailDao.getAllGoodsByUid(uid);
		for(Iterator<OrderDetail> i = orderDetails.iterator();i.hasNext();){
			OrderDetail orderDetail = i.next();
			if (gid == orderDetail.getGood().getId()){
				flag = true;
				break;
			}
		}
		return flag;
	}
	
	
	public int getCommandAmount(int gid){
		int s = 0;
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select count(*) from t_comment where gid = ?");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, gid);
			rs = pstmt.executeQuery();
			while (rs.next()){
				s+=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	

}
