package com.shopping.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.shopping.dao.FavDetailDao;
import com.shopping.dao.GoodDao;
import com.shopping.dao.factory.GoodDaoFactory;
import com.shopping.pojo.FavDetail;
import com.shopping.util.DBUtils;
import com.shopping.util.PageUtil;

public class FavDetailDao4MysqlImpl implements FavDetailDao {
	private static GoodDao goodDao;
	static{
		goodDao = GoodDaoFactory.getInstance("./daoConfig.properties", "GoodDao");
	}
	public boolean addFavDetail(int uid,int gid){			//������Ʒ���ղذ�ť���ø÷���
		boolean flag = true;
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "insert into t_favDetail values(null,?,?)");
		try {
			pstmt.setInt(1, gid);
			pstmt.setInt(2, uid);
			if(checkFavDetail(gid,uid)){
				pstmt.executeUpdate();
			}else{
				flag = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
		return flag;
	}
	
	
	
	
	public List<FavDetail> getFavDetailsByFid(int uid,PageUtil pageUtil){		//���ղؽ������
		List<FavDetail> favDetails = new ArrayList<FavDetail>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_favDetail where uid = ? limit ?,?");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, uid);
			pstmt.setInt(2, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
			pstmt.setInt(3, pageUtil.getPageRecord());
			rs = pstmt.executeQuery();
			while (rs.next()){
				FavDetail favDetail = new FavDetail();
				favDetail.setId(rs.getInt(1));			
				favDetail.setGood(goodDao.findGoodById(rs.getInt(2)));
				favDetails.add(favDetail);
				int s = findTotalFavs(uid);
				if (s%pageUtil.getPageRecord()!=0){
					pageUtil.setTotalRecord(s);
					pageUtil.setTotalPage(s/pageUtil.getPageRecord()+1);
				}else{
					pageUtil.setTotalRecord(s);
					pageUtil.setTotalPage(s/pageUtil.getPageRecord());
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
		return favDetails;
	}
	
	
	public void deleteFavDetail(int id){				//ɾ��
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "delete from t_favDetail where id =?");
		try {
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
	}
	public boolean checkFavDetail(int gid,int uid){
		boolean flag = true;					//	�жϴ�����¼�Ƿ��Ѿ�����
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_favDetail where uid =? and gid =?");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, uid);
			pstmt.setInt(2, gid);
			rs = pstmt.executeQuery();
			if (rs.next()){
				flag = false;
			}else{
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
		return flag;
	}
	public int findTotalFavs(int uid){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select count(*) from t_favDetail where uid = ?");
		int s =0;
		ResultSet rs = null;
		try {
			pstmt.setInt(1, uid);
			rs = pstmt.executeQuery();
			while (rs.next()){
				s = rs.getInt(1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
		return s;
	}
}
