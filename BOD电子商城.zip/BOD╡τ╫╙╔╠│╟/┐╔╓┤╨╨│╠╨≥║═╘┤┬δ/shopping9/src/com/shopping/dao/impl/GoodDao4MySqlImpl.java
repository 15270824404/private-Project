package com.shopping.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.shopping.dao.GoodDao;
import com.shopping.dao.GoodTypeDao;
import com.shopping.dao.OrderDao;
import com.shopping.dao.OrderDetailDao;
import com.shopping.dao.factory.GoodTypeDaoFactory;
import com.shopping.dao.factory.OrderDaoFactory;
import com.shopping.dao.factory.OrderDetailDaoFactory;
import com.shopping.pojo.Good;
import com.shopping.util.DBUtils;
import com.shopping.util.PageUtil;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class GoodDao4MySqlImpl implements GoodDao {
    private static GoodTypeDao goodTypeDao;
    private static OrderDetailDao orderDetailDao;
	static {
		goodTypeDao = GoodTypeDaoFactory.getInstance("./daoConfig.properties", "GoodTypeDao");	
		orderDetailDao = OrderDetailDaoFactory.getInstance("./daoConfig.properties", "OrderDetailDao");	
	}
	
	
	
		   public Good findGoodById(int id){
			   Good good = new Good();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_good where id=? and isvalid='Y'");
			   ResultSet rs = null;
			   try {
				pstmt.setInt(1, id);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			   try {
				rs = pstmt.executeQuery();
				while(rs.next()){
					good.setId(rs.getInt(1));
					good.setGname(rs.getString(2));
//					good.setGoodType(goodTypeDao.findGoodTypeById(3));					
					good.setImg(rs.getString(5));
					good.setPrice(rs.getDouble(6));
					good.setMarketprice(rs.getDouble(7));
					good.setAmount(rs.getInt(8));
					good.setBuycount(rs.getInt(9));
					good.setRebate(rs.getDouble(10));
					good.setIssale(rs.getString(11));
					good.setIsvalid(rs.getString(12));
					good.setContent(rs.getString(13));	
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
             return good;
	}
		   
		   
		   
		   public void addGood(int supertype,int typeID,String goodsName,int goodsAmount,double marketprice,double price,double rebate,String sale,String img,String content){
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = null;
			   try{
			        pstmt = DBUtils.getPstmt(conn, "insert into t_good value(null,?,?,?,?,?,?,?,'0',?,?,'Y',?,now())");
					pstmt.setString(1, goodsName);
				    pstmt.setInt(2,supertype);
				    pstmt.setInt(3,typeID);
			        pstmt.setString(4, img);
			        pstmt.setDouble(5, price);
			        pstmt.setDouble(6, marketprice);
			        pstmt.setInt(7,goodsAmount );
			        pstmt.setDouble(8, rebate);
			        pstmt.setString(9, sale);
			        pstmt.setString(10,content);
			        pstmt.executeUpdate();
		           
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
	}
		   
		   
		   public void renewGood(int id,int supertype,int typeID,String goodsName,int goodsAmount,double marketprice,double price,double rebate,String sale,String img,String content){
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = null;
			   try{
			        pstmt = DBUtils.getPstmt(conn, "update t_good set gname=?,gtid=?,gsmallid=?,img=?,price=?,marketprice=?,amount=?,buycount=0,rebate=?,issale=?,isvalid='Y',content=? where id=?");
					pstmt.setString(1, goodsName);
				    pstmt.setInt(2, supertype);
			        pstmt.setInt(3, typeID);
			        pstmt.setString(4, img);
			        pstmt.setDouble(5, price);
			        pstmt.setDouble(6, marketprice);
			        pstmt.setInt(7, goodsAmount);
			        pstmt.setDouble(8, rebate);
			        pstmt.setString(9, sale);
			        pstmt.setString(10,content);			      
			        pstmt.setInt(11,id);
			        pstmt.executeUpdate();
		           
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}	
		   }
		   
		   
		   public void renewGoodStatus(String isvalid,int id){
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = null;
			   try{
			        pstmt = DBUtils.getPstmt(conn, "update t_good set isvalid=? where id=?");	
			        pstmt.setString(1, isvalid);		      
			        pstmt.setInt(2, id);
			        pstmt.executeUpdate();
		           
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}
}
		   
		   public void renewGoodAmount(int amount,int id){
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = null;
			   try{
			        pstmt = DBUtils.getPstmt(conn, "update t_good set amount=? where id=?");	
			        pstmt.setInt(1, amount);		      
			        pstmt.setInt(2, id);
			        pstmt.executeUpdate();
		           
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(pstmt);
				DBUtils.close(conn);
		   }
     }
		   
		   
		   
		   public int selectGoodAmount(int id){
                int amount = 0;
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select amount from t_good where id=?");
			   ResultSet rs = null;	
			        try {
						pstmt.setInt(1, id);
						
					} catch (SQLException e) {
						e.printStackTrace();
					}
						try{
							rs = pstmt.executeQuery();
						    while(rs.next()){
							amount=rs.getInt(1);
				           }
					} catch (SQLException e) {
						e.printStackTrace();
					}finally{
						DBUtils.close(rs);
						DBUtils.close(pstmt);
						DBUtils.close(conn);
					}				
		             return amount;
		   }
		   
		   
		   
		   public List<Good> findSaleGoods(){
			   List<Good> goods = new ArrayList<Good>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_good where issale='Y' and isvalid='Y'order by rebate desc");
			   ResultSet rs = null;
			   try {
				rs = pstmt.executeQuery();
				while(rs.next()){
					Good good = new Good();
					good.setId(rs.getInt(1));
					good.setGname(rs.getString(2));
					//good.setGoodType(goodTypeDao.findGoodTypeById(3));					
					good.setImg(rs.getString(5));
					good.setPrice(rs.getDouble(6));
					good.setMarketprice(rs.getDouble(7));
					good.setAmount(rs.getInt(8));
					good.setBuycount(rs.getInt(9));
					good.setRebate(rs.getDouble(10));
					good.setIssale(rs.getString(11));
					good.setIsvalid(rs.getString(12));
					good.setContent(rs.getString(13));
					goods.add(good);
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
             return goods;
	}
		   
		   
		   public List<Good> findBestGoods(){
			   List<Good> goods = new ArrayList<Good>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_good where isvalid='Y'order by buycount desc");
			   ResultSet rs = null;
			   try {
				rs = pstmt.executeQuery();
				while(rs.next()){
					Good good = new Good();
					good.setId(rs.getInt(1));
					good.setGname(rs.getString(2));
					//good.setGoodType(goodTypeDao.findGoodTypeById(3));					
					good.setImg(rs.getString(5));
					good.setPrice(rs.getDouble(6));
					good.setMarketprice(rs.getDouble(7));
					good.setAmount(rs.getInt(8));
					good.setBuycount(rs.getInt(9));
					good.setRebate(rs.getDouble(10));
					good.setIssale(rs.getString(11));
					good.setIsvalid(rs.getString(12));
					good.setContent(rs.getString(13));
					goods.add(good);
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
             return goods;
      }
		   
		   
		   public List<Good> findNewGoods(PageUtil pageUtil){
			   List<Good> goods = new ArrayList<Good>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_good where isvalid='Y' order by regtime desc limit ?,?");
			   ResultSet rs = null;
			   try {
				   pstmt.setInt(1, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
				   pstmt.setInt(2, pageUtil.getPageRecord());
				rs = pstmt.executeQuery();
				while(rs.next()){
					Good good = new Good();
					good.setId(rs.getInt(1));
					good.setGname(rs.getString(2));
					//good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(3)));					
					//good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(4)));					
					good.setImg(rs.getString(5));
					good.setPrice(rs.getDouble(6));
					good.setMarketprice(rs.getDouble(7));
					good.setAmount(rs.getInt(8));
					good.setBuycount(rs.getInt(9));
					good.setRebate(rs.getDouble(10));
					good.setIssale(rs.getString(11));
					good.setIsvalid(rs.getString(12));
					good.setContent(rs.getString(13));
					good.setOrderNum(orderDetailDao.getGoodSalesVolume(rs.getInt(1)));
					goods.add(good);
					int total = findTotalGoods();
					if(total % pageUtil.getPageRecord()==0){
						pageUtil.setTotalRecord(total);
						pageUtil.setTotalPage(total/pageUtil.getPageRecord());
						
					}else{
						pageUtil.setTotalRecord(total);
						pageUtil.setTotalPage(total/pageUtil.getPageRecord()+1);
					}
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
             return goods;
      }
		   
		   
		   
		   public List<Good> findGoods(PageUtil pageUtil){
			   List<Good> goods = new ArrayList<Good>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_good where isvalid='Y' limit ?,?");
			   ResultSet rs = null;
			   try {
				   pstmt.setInt(1, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
				   pstmt.setInt(2, pageUtil.getPageRecord());
				   rs = pstmt.executeQuery();
				   while(rs.next()){
					   Good good = new Good();
						good.setId(rs.getInt(1));
						good.setGname(rs.getString(2));
						//good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(3)));					
						//good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(4)));					
						good.setImg(rs.getString(5));
						good.setPrice(rs.getDouble(6));
						good.setMarketprice(rs.getDouble(7));
						good.setAmount(rs.getInt(8));
						good.setBuycount(rs.getInt(9));
						good.setRebate(rs.getDouble(10));
						good.setIssale(rs.getString(11));
						good.setIsvalid(rs.getString(12));
						good.setContent(rs.getString(13));
						good.setOrderNum(orderDetailDao.getGoodSalesVolume(rs.getInt(1)));
						goods.add(good);
						int total = findTotalGoods();
						if(total % pageUtil.getPageRecord()==0){
							pageUtil.setTotalRecord(total);
							pageUtil.setTotalPage(total/pageUtil.getPageRecord());
							
						}else{
							pageUtil.setTotalRecord(total);
							pageUtil.setTotalPage(total/pageUtil.getPageRecord()+1);
						}
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
             return goods;
		   }
		   
		   
		   public List<Good> findAllGoods(){
			   List<Good> goods = new ArrayList<Good>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_good");
			   ResultSet rs = null;
			   try {
				   rs = pstmt.executeQuery();
				   while(rs.next()){
					   Good good = new Good();
						good.setId(rs.getInt(1));
						good.setGname(rs.getString(2));
						//good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(3)));					
						//good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(4)));					
						good.setImg(rs.getString(5));
						good.setPrice(rs.getDouble(6));
						good.setMarketprice(rs.getDouble(7));
						good.setAmount(rs.getInt(8));
						good.setBuycount(rs.getInt(9));
						good.setRebate(rs.getDouble(10));
						good.setIssale(rs.getString(11));
						good.setIsvalid(rs.getString(12));
						good.setContent(rs.getString(13));
						good.setOrderNum(orderDetailDao.getGoodSalesVolume(rs.getInt(1)));
						goods.add(good);
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
             return goods;
		   }
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   public int findTotalGoods(){
				Connection conn = DBUtils.getConn();
				PreparedStatement pstmt = null;
				int s = 0;

				pstmt = DBUtils.getPstmt(conn, "select count(*) from t_good");
				
				ResultSet rs =null;
				try {				
					rs = pstmt.executeQuery();
					while(rs.next()){
						s = rs.getInt(1);					
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					DBUtils.close(rs);
					DBUtils.close(pstmt);
					DBUtils.close(conn);
				}
				return s;
			}
		   
		   
		   public List<Good> searchGoods(String gname,int gtid){
		   List<Good> goods = new ArrayList<Good>();
		   Connection conn = DBUtils.getConn();
		   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_good where isvalid='Y' and gname like? and gtid=?");
		   ResultSet rs = null;
		   try {			    
				pstmt.setString(1, "%"+gname+"%");
				pstmt.setInt(2, gtid);				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   try {
			rs = pstmt.executeQuery();			
			while(rs.next()){
				Good good = new Good();				
				good.setId(rs.getInt(1));
				good.setGname(rs.getString(2));
				good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(3)));					
				//good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(4)));					
				good.setImg(rs.getString(5));
				good.setPrice(rs.getDouble(6));
				good.setMarketprice(rs.getDouble(7));
				good.setAmount(rs.getInt(8));
				good.setBuycount(rs.getInt(9));
				good.setRebate(rs.getDouble(10));
				good.setIssale(rs.getString(11));
				good.setIsvalid(rs.getString(12));
				good.setContent(rs.getString(13));
				goods.add(good);
	           }
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}				
         return goods;
  }
		   
		   
		   public List<Good> searchGoodsByBGd(String gname,int gtid,int gsmallid){
			   List<Good> goods = new ArrayList<Good>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_good where isvalid='Y' and gname like? and gtid=? and gsmallid=?");
			   ResultSet rs = null;
			   try {			    
					pstmt.setString(1, "%"+gname+"%");
					pstmt.setInt(2, gtid);				
					pstmt.setInt(3, gsmallid);				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   try {
				rs = pstmt.executeQuery();			
				while(rs.next()){
					Good good = new Good();				
					good.setId(rs.getInt(1));
					good.setGname(rs.getString(2));
					//good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(3)));					
					//good.setSmallgoodType();					
					good.setImg(rs.getString(5));
					good.setPrice(rs.getDouble(6));
					good.setMarketprice(rs.getDouble(7));
					good.setAmount(rs.getInt(8));
					good.setBuycount(rs.getInt(9));
					good.setRebate(rs.getDouble(10));
					good.setIssale(rs.getString(11));
					good.setIsvalid(rs.getString(12));
					good.setContent(rs.getString(13));
					goods.add(good);
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
	         return goods;
		   }
		   		
		   
		   public List<Good> selGoodByGType(int id){
			   List<Good> goods = new ArrayList<Good>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select t_good.id,t_good.gname,t_good.gtid,t_good.gsmallid,t_good.img,t_good.price,t_good.marketprice,t_good.amount,t_good.buycount,t_good.rebate,t_good.content,t_good.issale,t_good.isvalid from t_goodstype,t_good where t_good.gsmallid=t_goodstype.id and isvalid='Y' and t_goodstype.id = ? ;");
			   ResultSet rs = null;
			   try {			    
					pstmt.setInt(1, id);							
				} catch (SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   try {
				rs = pstmt.executeQuery();			
				while(rs.next()){
					Good good = new Good();				
					good.setId(rs.getInt(1));
					good.setGname(rs.getString(2));
					good.setGoodType(goodTypeDao.findGoodTypeById(rs.getInt(3)));					
					good.setSmallgoodType(goodTypeDao.findGoodTypeById(rs.getInt(4)));				
					good.setImg(rs.getString(5));
					good.setPrice(rs.getDouble(6));
					good.setMarketprice(rs.getDouble(7));
					good.setAmount(rs.getInt(8));
					good.setBuycount(rs.getInt(9));
					good.setRebate(rs.getDouble(10));
					good.setIssale(rs.getString(11));
					good.setIsvalid(rs.getString(12));
					good.setContent(rs.getString(13));
					goods.add(good);
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
	         return goods;
		   }	   
		   
}
		   
		   
	