package com.shopping.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shopping.dao.GoodTypeDao;
import com.shopping.pojo.GoodType;
import com.shopping.util.DBUtils;

public class GoodType4MySqlImpl implements GoodTypeDao {

	
	       public List<GoodType> findGoodTypeById(int id){
		   List<GoodType> goodTypes = new ArrayList<GoodType>();
		   Connection conn = DBUtils.getConn();
		   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_goodsType where id=?");
		   ResultSet rs = null;
		   try {
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while(rs.next()){
				GoodType goodType = new GoodType();
				goodType.setId(id);	
				goodType.setTypename(rs.getString(2));
				goodType.setInformation(rs.getString(3));
				goodType.setIsleaf(rs.getString(4));
				goodType.setFid(rs.getInt(5));
				goodTypes.add(goodType);
	           }
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}				
			return goodTypes;
    }
	       
	       
	       public List<GoodType> findTopGoodType(){
	    	   List<GoodType> goodTypes = new ArrayList<GoodType>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_goodsType where fid=0");
			   ResultSet rs = null;
			   try {
				rs = pstmt.executeQuery();
				while(rs.next()){
					GoodType goodType = new GoodType();
					goodType.setId(rs.getInt(1));	
					goodType.setTypename(rs.getString(2));
					goodType.setInformation(rs.getString(3));
					goodType.setIsleaf(rs.getString(4));
					goodType.setFid(rs.getInt(5));
					goodTypes.add(goodType);
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
				return goodTypes;
	       }
	       
	       
	       public List<GoodType> findMiddleGoodType(int id){
	    	   List<GoodType> goodTypes = new ArrayList<GoodType>();
			   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_goodsType where fid=?");
			   ResultSet rs = null;
			   try {
				pstmt.setInt(1, id);
				rs = pstmt.executeQuery();
				while(rs.next()){
					GoodType goodType = new GoodType();
					goodType.setId(rs.getInt(1));	
					goodType.setTypename(rs.getString(2));
					goodType.setInformation(rs.getString(3));
					goodType.setIsleaf(rs.getString(4));
					goodType.setFid(id);
					goodTypes.add(goodType);
		           }
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(rs);
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}				
				return goodTypes;
	       }
	       
	       
	       public void addTopGood(String typename,String information){
	    	   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = null;
			   try{
			        pstmt = DBUtils.getPstmt(conn, "insert into t_goodstype value(null,?,?,'N',0)");
					pstmt.setString(1, typename);
				    pstmt.setString(2,information);
			        pstmt.executeUpdate();		           
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}			
	       }
	       
	       public void addMiddleGood(String typename,String information,int fid){
	    	   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = null;
			   try{
			        pstmt = DBUtils.getPstmt(conn, "insert into t_goodstype value(null,?,?,'N',?)");
					pstmt.setString(1, typename);
				    pstmt.setString(2,information);
				    pstmt.setInt(3,fid);
			        pstmt.executeUpdate();		           
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}			
	       }
	       
	       public void renewTopGoodType(int id,String typename,String information){
	    	   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = null;
			   try{
			        pstmt = DBUtils.getPstmt(conn, "update t_goodstype set typename=?,information=? where id=?");	
			        pstmt.setString(1, typename);		      
			        pstmt.setString(2, information);		      
			        pstmt.setInt(3, id);
			        pstmt.executeUpdate();
		           
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}
	       }
	       
	       
	       public void renewMiddleGoodType(int id,String typename,String information){
	    	   Connection conn = DBUtils.getConn();
			   PreparedStatement pstmt = null;
			   try{
			        pstmt = DBUtils.getPstmt(conn, "update t_goodstype set typename=?,information=? where id=?");	
			        pstmt.setString(1, typename);		      
			        pstmt.setString(2, information);		      
			        pstmt.setInt(3, id);
			        pstmt.executeUpdate();
		           
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtils.close(pstmt);
				DBUtils.close(conn);
			}
	    	   
	       }	      
	       
	       public void removeMiddleGoodType(int id){
	    	   Connection conn = DBUtils.getConn();
		    	PreparedStatement pstmt =null;    	
	                try {
						pstmt = DBUtils.getPstmt(conn, "delete from t_goodstype where id=?");
						pstmt.setInt(1, id);
						pstmt.executeUpdate();
					} catch (SQLException e) {
						e.printStackTrace();
					}              
		              finally{
					  DBUtils.close(pstmt);
					  DBUtils.close(conn);
				}
	       }
	       
	       
	       public void removeTopGoodType(int id){
	    	   Connection conn = DBUtils.getConn();
	    	   PreparedStatement pstmt =null;    	
	    	   try {
	    		   pstmt = DBUtils.getPstmt(conn, "delete from t_goodstype where id=?");
	    		   pstmt.setInt(1, id);
	    		   pstmt.executeUpdate();
	    	   } catch (SQLException e) {
	    		   e.printStackTrace();
	    	   }              
	    	   finally{
	    		   DBUtils.close(pstmt);
	    		   DBUtils.close(conn);
	    	   }
	       }
	       
}
