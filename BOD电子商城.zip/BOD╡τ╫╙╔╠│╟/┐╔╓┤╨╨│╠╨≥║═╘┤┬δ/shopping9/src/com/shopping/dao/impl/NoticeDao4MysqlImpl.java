package com.shopping.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import com.shopping.dao.NoticeDao;
import com.shopping.pojo.Notice;
import com.shopping.util.DBUtils;
import com.shopping.util.PageUtil;

public class NoticeDao4MysqlImpl implements NoticeDao {

	public void addNotice(String title, String content, String uptime,
			String deadtime) {
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "insert into t_notices values(null,?,?,?,?)");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
		Date update = null;
		Date deaddate = null;
		try {
			update = sdf.parse(uptime);
			deaddate = sdf.parse(deadtime);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setDate(3, new java.sql.Date(update.getTime()));
			pstmt.setDate(4, new java.sql.Date(deaddate.getTime()));
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		

	}

	public List<Notice> getNotices(PageUtil pageUtil) {
		List<Notice> notices = new ArrayList<Notice>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_notices limit ?,?");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
			pstmt.setInt(2, pageUtil.getPageRecord());
			rs = pstmt.executeQuery();
			while (rs.next()){
				Notice notice = new Notice();
				notice.setId(rs.getInt(1));			
				notice.setTitle(rs.getString(2));
				notice.setContent(rs.getString(3));
				notice.setUptime(rs.getTimestamp(4));
				notice.setDeadtime(rs.getTimestamp(5));
				notices.add(notice);
				pageUtil.setTotalRecord(findTotalNotices());
				if (findTotalNotices()%pageUtil.getPageRecord()==0){
					pageUtil.setTotalPage(findTotalNotices()/pageUtil.getPageRecord());
				}else{
					pageUtil.setTotalPage(findTotalNotices()/pageUtil.getPageRecord()+1);
				}
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
		return notices;
	}
	
	public void deleteNotice(int id){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "delete from t_notices where id =?");
		try {
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
	}
	public Notice findNoticeById(int id){
		Notice notice = new Notice();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_notices where id =?");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()){
				
				notice.setId(rs.getInt(1));			
				notice.setTitle(rs.getString(2));
				notice.setContent(rs.getString(3));
				notice.setUptime(rs.getTimestamp(4));
				notice.setDeadtime(rs.getTimestamp(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
		return notice;
	}
	
	public void updateNotice(String title,String content,String uptime,String deadtime,int nid){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "update t_notices set title = ?,content =?,uptime=?,deadtime=? where id = ?");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
		Date update = null;
		Date deaddate = null;
		try {
			update = sdf.parse(uptime);
			deaddate = sdf.parse(deadtime);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setDate(3, new java.sql.Date(update.getTime()));
			pstmt.setDate(4, new java.sql.Date(deaddate.getTime()));
			pstmt.setInt(5, nid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
	}
	public int findTotalNotices(){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select count(*) from t_notices ");
		ResultSet rs = null;
		int s = 0;
		try {
			rs = pstmt.executeQuery();
			while (rs.next()){
				s = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}		
		return s;
	}

}
