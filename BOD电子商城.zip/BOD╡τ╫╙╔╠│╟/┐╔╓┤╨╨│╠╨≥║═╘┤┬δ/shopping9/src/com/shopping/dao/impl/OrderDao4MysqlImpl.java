package com.shopping.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shopping.dao.OrderDao;
import com.shopping.dao.OrderDetailDao;
import com.shopping.dao.UserDao;
import com.shopping.dao.factory.OrderDetailDaoFactory;
import com.shopping.dao.factory.UserDaoFactory;
import com.shopping.pojo.Order;
import com.shopping.util.DBUtils;
import com.shopping.util.PageUtil;

public class OrderDao4MysqlImpl implements OrderDao {
	private static OrderDetailDao orderDetailDao;
	private static UserDao userdao;
	static {
		orderDetailDao = OrderDetailDaoFactory.getInstance("./daoConfig.properties", "OrderDetailDao");
		userdao = UserDaoFactory.getInstance("./daoConfig.properties", "UserDao");
	}
	
	public int addOrder(Order order ,int uid) {

		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "insert into t_order values(null,?,now(),?,?,?,?,?,?,?,?,?)");
		
		try {
			pstmt.setString(1, order.getNum());
			pstmt.setInt(2, order.getPaymethod());

			pstmt.setInt(3, order.getSendmethod());
			pstmt.setInt(4, order.getStatus());
			pstmt.setInt(5, uid);
			
			pstmt.setString(6, order.getRealname());
			pstmt.setString(7, order.getAddress());
			pstmt.setString(8, order.getPostcode());
			
			pstmt.setString(9, order.getTel());
			pstmt.setString(10, order.getRemark());
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return findCurrentInsertOrder();
		
		
		
	}
	
	
	
	
	public List<Order> showValidOrdersByUid(int uid,PageUtil pageUtil){
		List<Order> orders = new ArrayList<Order>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_order where uid = ? order by id desc limit ?,?");
		ResultSet rs =null;
		try {
			pstmt.setInt(1, uid);
			pstmt.setInt(2, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
			pstmt.setInt(3, pageUtil.getPageRecord());
			rs = pstmt.executeQuery();
			while(rs.next()){
				Order order = new Order();
				order.setId(rs.getInt(1));
				order.setNum(rs.getString(2));
				order.setOrdtime(rs.getTimestamp(3));
				order.setPaymethod(rs.getInt(4));
				order.setSendmethod(rs.getInt(5));
				order.setStatus(rs.getInt(6));
//				order.setUser(userdao.findUserById(rs.getInt(7)));
				order.setRealname(rs.getString(8));
				order.setAddress(rs.getString(9));
				order.setPostcode(rs.getString(10));
				
				order.setTel(rs.getString(11));
				order.setRemark(rs.getString(12));
				order.setOrderDetail(orderDetailDao.findOrderDetailsByOid(rs.getInt(1)));
				order.setAllprice(orderDetailDao.returnOrderTotalPrice(rs.getInt(1)));
				orders.add(order);
				int total = findTotalOrders(uid); 
				if (total%pageUtil.getPageRecord()==0){
					pageUtil.setTotalRecord(total);
					pageUtil.setTotalPage(total/pageUtil.getPageRecord());
				}else{
					pageUtil.setTotalRecord(total);
					pageUtil.setTotalPage(total/pageUtil.getPageRecord()+1);
				}
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return orders;
	}
	
	
/*	
	public List<Order> showAllOrders(){
		List<Order> orders = new ArrayList<Order>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_order");
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			while(rs.next()){
				Order order = new Order();
				order.setId(rs.getInt(1));
				order.setNum(rs.getString(2));
				order.setOrdtime(rs.getTimestamp(3));
				order.setPaymethod(rs.getInt(4));
				order.setStatus(rs.getInt(5));
				order.setUser(userdao.findUserById(rs.getInt(6)));
				order.setOrderDetail(orderDetailDao.findOrderDetailsByOid(rs.getInt(1)));
				order.setRealname(rs.getString(7));
				order.setAddress(rs.getString(8));
				order.setPostcode(rs.getString(9));
				order.setProvince(rs.getInt(10));
				order.setCity(rs.getInt(11));
				order.setArea(rs.getInt(12));
				order.setTel(rs.getString(13));
				order.setRemark(rs.getString(14));
				order.setOrderDetail(orderDetailDao.findOrderDetailsByOid(rs.getInt(1)));
				order.setAllprice(orderDetailDao.returnOrderTotalPrice(rs.getInt(1)));
				
				orders.add(order);
			}

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return orders;
	}	
	
*/	
	
	
	public Order findOrderById(int id){
		Order order = new Order();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_order where id = ? order by id desc");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while(rs.next()){				
				order.setId(id);
				order.setNum(rs.getString(2));
				order.setOrdtime(rs.getTimestamp(3));
				order.setPaymethod(rs.getInt(4));
				order.setSendmethod(rs.getInt(5));
				order.setStatus(rs.getInt(6));
				order.setUser(userdao.findUserById(rs.getInt(7)));
				order.setOrderDetail(orderDetailDao.findOrderDetailsByOid(rs.getInt(1)));
				order.setRealname(rs.getString(8));
				order.setAddress(rs.getString(9));
				order.setPostcode(rs.getString(10));
				
				order.setTel(rs.getString(11));
				order.setRemark(rs.getString(12));
				order.setAllprice(orderDetailDao.returnOrderTotalPrice(rs.getInt(1)));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return order;
	}
	
	
/*	
	public void cancelOrder(String status){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "update t_order set status =3");
		
		try {
			pstmt.setString(1, status);			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
			                                                                                                                                                                                 
	}
	*/
	public void deleteOrderById(int id){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "delete from t_order where id = ?");
		orderDetailDao.deleteOrderDetailByOid(id);
		try {
			
			pstmt.setInt(1, id);			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
	}
	public void updateOrderStatus(int id,int status){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "update t_order set status = ? where id =?");
		
		try {
			pstmt.setInt(1, status);	
			pstmt.setInt(2, id);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
	}
	public List<Order> showOrders(int status , String num,PageUtil pageUtil){
		List<Order> orders = new ArrayList<Order>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			if (status == 0){
				if (num.equals("-1")){
					pstmt= DBUtils.getPstmt(conn, "select * from t_order limit ?,?");
					pstmt.setInt(1, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
					pstmt.setInt(2, pageUtil.getPageRecord());
				}
				else{
					pstmt = DBUtils.getPstmt(conn, "select * from t_order where num like ? limit ?,?");
					pstmt.setString(1, "%"+num+"%");
					pstmt.setInt(2, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
					pstmt.setInt(3, pageUtil.getPageRecord());
				}
			}
			else {
					if (num.equals("-1")){
						pstmt= DBUtils.getPstmt(conn, "select * from t_order where status = ? limit ?,?");
						pstmt.setInt(1, status);
						pstmt.setInt(2, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
						pstmt.setInt(3, pageUtil.getPageRecord());
					}else{
						pstmt = DBUtils.getPstmt(conn, "select * from t_order where status = ? and num like ? limit ?,?");
						pstmt.setInt(1, status);
						pstmt.setString(2, "%"+num+"%");
						pstmt.setInt(3, (pageUtil.getCurrentPage()-1)*pageUtil.getPageRecord());
						pstmt.setInt(4, pageUtil.getPageRecord());
				}
			} 
		
		
			rs = pstmt.executeQuery();
			while(rs.next()){
				Order order = new Order();
				order.setId(rs.getInt(1));
				order.setNum(rs.getString(2));
				order.setOrdtime(rs.getTimestamp(3));
				order.setPaymethod(rs.getInt(4));
				order.setSendmethod(rs.getInt(5));
				order.setStatus(rs.getInt(6));
				order.setUser(userdao.findUserById(rs.getInt(7)));
				order.setOrderDetail(orderDetailDao.findOrderDetailsByOid(rs.getInt(1)));
				order.setRealname(rs.getString(8));
				order.setAddress(rs.getString(9));
				order.setPostcode(rs.getString(10));
				
				order.setTel(rs.getString(11));
				order.setRemark(rs.getString(12));
				order.setOrderDetail(orderDetailDao.findOrderDetailsByOid(rs.getInt(1)));
				order.setAllprice(orderDetailDao.returnOrderTotalPrice(rs.getInt(1)));				
				orders.add(order);
				pageUtil.setTotalRecord(findDifferentOrder(status, num));
				if (findDifferentOrder(status, num)%pageUtil.getPageRecord()!=0){
					pageUtil.setTotalPage(findDifferentOrder(status, num)/pageUtil.getPageRecord()+1);
				}else{
					pageUtil.setTotalPage(findDifferentOrder(status, num)/pageUtil.getPageRecord());
				}
				
				
				
			}

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
	
		return orders;
	}
	
	
	
	
	public double getUserMoney(int uid){
		double userMoney=0;
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_order where uid = ? and status = 3");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, uid);
			rs = pstmt.executeQuery();
			while(rs.next()){				
				userMoney += orderDetailDao.returnOrderTotalPrice(rs.getInt(1));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return userMoney;
	}
	public int findTotalOrders(int uid){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = null;
		int s = 0;

		pstmt = DBUtils.getPstmt(conn, "select count(*) from t_order where uid = ?");
		
		ResultSet rs =null;
		try {
				pstmt.setInt(1, uid);
			
		
			rs = pstmt.executeQuery();
			while(rs.next()){
				s = rs.getInt(1);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return s;
	}
	public int findDifferentOrder(int status,String num){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = null;
		int s = 0;
		ResultSet rs =null;
		try {
			if (status == 0){
				if (num.equals("-1")){
					pstmt= DBUtils.getPstmt(conn, "select count(*) from t_order");
					
				}
				else{
					pstmt = DBUtils.getPstmt(conn, "select count(*) from t_order where num like ?");
					pstmt.setString(1, "%"+num+"%");
					
				}
			}
			else {
					if (num.equals("-1")){
						pstmt= DBUtils.getPstmt(conn, "select count(*) from t_order where status = ?");
						pstmt.setInt(1, status);
						
					}else{
						pstmt = DBUtils.getPstmt(conn, "select count(*) from t_order where status = ? and num like ? ");
						pstmt.setInt(1, status);
						pstmt.setString(2, "%"+num+"%");
						
				}
			} 
		
			rs = pstmt.executeQuery();
			while(rs.next()){
				s = rs.getInt(1);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return s;
	}
	public Order getLastOrder(){
		Order order = new Order();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select MAX(ordtime) from t_order");
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			while(rs.next()){		
				order.setOrdtime(rs.getTimestamp(1));
				order.setNum(findOrderNumByTime());
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return order;
	}
	public int findCurrentInsertOrder(){
		int oid=0;
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select id from t_order where ordtime =(select max(ordtime) from t_order);");
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			while(rs.next()){				
				oid = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return oid;
	}
	public String findOrderNumByTime(){
		String num = null;
		Connection conn = DBUtils.getConn();
		
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select num from t_order where ordtime =(select max(ordtime) from t_order);");
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
			while(rs.next()){				
				num = rs.getString(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return num;
	}
}
