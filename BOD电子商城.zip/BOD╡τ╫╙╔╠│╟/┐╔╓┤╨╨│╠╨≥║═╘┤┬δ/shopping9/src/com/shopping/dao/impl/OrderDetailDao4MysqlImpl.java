package com.shopping.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.shopping.dao.GoodDao;
import com.shopping.dao.OrderDao;
import com.shopping.dao.OrderDetailDao;
import com.shopping.dao.factory.GoodDaoFactory;
import com.shopping.dao.factory.OrderDaoFactory;
import com.shopping.pojo.OrderDetail;
import com.shopping.util.DBUtils;

public class OrderDetailDao4MysqlImpl implements OrderDetailDao {
	private static GoodDao goodDao;
	private static OrderDao orderDao;
	
	static {
		goodDao =  GoodDaoFactory.getInstance("./daoConfig.properties", "GoodDao");
		orderDao = OrderDaoFactory.getInstance("./daoConfig.properties", "OrderDao");
	}

	public void addOrderDetail(int gid,int oid,int gnum) {//����һ��������ϸ
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "insert into t_orderDetail values(null,?,?,?)");
		
		try {
			pstmt.setInt(1, oid);
			pstmt.setInt(2, gid);
			pstmt.setInt(3, gnum);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		

	}

	public List<OrderDetail> findOrderDetailsByOid(int oid) {//ͨ��oid�ҵ�������ϸ���ṩ��order����Ҷ�Ӧ�Ķ�����ϸ
		List<OrderDetail> orderDetails = new ArrayList<OrderDetail>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_orderDetail where oid = ?");
		ResultSet rs =null;
		try {
			pstmt.setInt(1, oid);
			rs = pstmt.executeQuery();
			while(rs.next()){
				OrderDetail orderDetail = new OrderDetail();
				orderDetail.setId(rs.getInt(1));
				
				orderDetail.setGood(goodDao.findGoodById(rs.getInt(3)));
				orderDetail.setGnum(rs.getInt(4));
				
				orderDetails.add(orderDetail);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return orderDetails;
	}
	
	
	
	
	public double returnOrderTotalPrice(int oid){//���ض����ܼ�ֵ
		double tp=0;
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_orderDetail where oid = ?");
		ResultSet rs =null;
		try {
			pstmt.setInt(1, oid);
			rs = pstmt.executeQuery();
			while(rs.next()){				
				tp += goodDao.findGoodById(rs.getInt(3)).getPrice()*rs.getInt(4);//ͨ���������۸�����
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return tp;
	}
	
	
	
	public int deleteOrderDetailById(int id){//ɾ����ϸ
		Connection conn = DBUtils.getConn();
		int oid = 0;
		boolean flag=false;//�ж��Ƿ�Ҫɾ��յĶ���
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "delete from t_orderDetail where id =?");
		try {
			pstmt.setInt(1, id);				
			oid = getOrderDetailsOid(id);
			pstmt.executeUpdate();
			if (checkEmptyOrder(oid)){
				orderDao.deleteOrderById(oid);
				flag=true;
			}
						
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		if (flag){
			return oid;
		}else{
			return 0;
		}
		
	}
	
	
	
	
	
	public void deleteOrderDetailByOid(int oid){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "delete from t_orderDetail where oid =?");
		try {
			pstmt.setInt(1, oid);
			pstmt.executeUpdate();				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
	}
	
	
	
	
	public int getGoodSalesVolume(int gid){
		int num = 0;
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select t_orderDetail.gnum from t_orderDetail,t_order where t_orderDetail.gid = ? and t_order.status =3 and t_orderDetail.oid = t_order.id");
		ResultSet rs =null;
		try {
			pstmt.setInt(1, gid);
			rs = pstmt.executeQuery();
			while(rs.next()){				
				num += rs.getInt(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return num;
	}
	
	
	
	
	public int getOrderDetailsOid(int id){
		int oid=0;
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select oid from t_orderDetail where id = ?");
		ResultSet rs =null;
		try {
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()){
				oid = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return oid;
	}
	
	public boolean checkEmptyOrder(int oid){
		boolean flag = false;
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_orderDetail where oid = ?");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, oid);
			rs = pstmt.executeQuery();
			if(rs.next()){				
				flag = false;
			}else{
				flag = true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return flag;
	}

	
	
	
	public List<OrderDetail> getAllGoodsByUid(int uid){
		List<OrderDetail> orderDetails = new ArrayList<OrderDetail>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select t_orderDetail.gid from t_orderDetail,t_order where t_order.uid =? and t_orderDetail.oid = t_order.id");
		ResultSet rs =null;
		try {
			pstmt.setInt(1, uid);
			rs = pstmt.executeQuery();
			while(rs.next()){
				OrderDetail orderDetail = new OrderDetail();				
				orderDetail.setGood(goodDao.findGoodById(rs.getInt(1)));				
				orderDetails.add(orderDetail);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return orderDetails;
	}


}


