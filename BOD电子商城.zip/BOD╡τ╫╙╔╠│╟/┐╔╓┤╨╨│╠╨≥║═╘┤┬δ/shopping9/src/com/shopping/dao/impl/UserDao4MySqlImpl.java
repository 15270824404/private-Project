package com.shopping.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shopping.dao.OrderDao;
import com.shopping.dao.UserDao;
import com.shopping.dao.factory.OrderDaoFactory;
import com.shopping.pojo.User;
import com.shopping.util.DBUtils;

public class UserDao4MySqlImpl implements UserDao {

	/*
	 * (non-Javadoc)
	 * @see com.shopping.dao.UserDao#saveUser(com.shopping.pojo.User)
	 */
	private static OrderDao orderDao;
	static{
		orderDao = OrderDaoFactory.getInstance("./daoConfig.properties", "OrderDao");
	}
	
	
	public int saveUser(User user) {
		int n = -1;
		Connection conn = DBUtils.getConn(); //id/name/pwd/mail/
		String sql = "insert into t_user values(null,?,?,?,now(),?,?, ?, ?,?,?,?,?,?,?)";
		                                                //date/amo/grade/status/
		PreparedStatement pstmt = DBUtils.getPstmt(conn, sql);
		try {
			String status = "unlock";
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getEmail());
			pstmt.setDouble(4, 0.0);              //amount�������ѽ���ʼֵΪ0
			
			pstmt.setInt(5, 3);     //3Ϊ��ͨ��Ա,2ΪVIP
			
			pstmt.setString(6, "unlock");         //status����״̬
			pstmt.setString(7, user.getRealname());
			pstmt.setString(8, user.getAddress());
			pstmt.setString(9, user.getPostcode());
			pstmt.setString(10, user.getProvince());
			pstmt.setString(11, user.getCity());
			pstmt.setString(12, user.getArea());
			pstmt.setString(13, user.getTel());
			
			n = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("DAO����++++++++++");
			e.printStackTrace();
		}
		return n;
	}

	/*
	 * (non-Javadoc)
	 * @see com.shopping.dao.UserDao#findUserByUsername(java.lang.String)
	 */
	public User findUserByUsername(String username) {
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_user where username=?");
		ResultSet rs = null;
		User user = new User();
		try {
			//conn.setAutoCommit(false);
			pstmt.setString(1, username);
			rs = pstmt.executeQuery();
			while(rs.next()){
				user.setId(rs.getInt(1));
				user.setUsername(username);
				user.setPassword(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setRegDate(rs.getTimestamp(5));
				//ͨ��uid���ҹ�����
				user.setAmount(orderDao.getUserMoney(rs.getInt(1)));
				//user.setAmount(rs.getDouble(6));
				user.setGrade(rs.getInt(7));
				user.setStatus(rs.getString(8));
				user.setRealname(rs.getString(9));
				user.setAddress(rs.getString(10));
				user.setPostcode(rs.getString(11));
				user.setProvince(rs.getString(12));
				user.setCity(rs.getString(13));
				user.setArea(rs.getString(14));
				user.setTel(rs.getString(15));
			}
			//conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return user;
	}

	/*
	 * (non-Javadoc)
	 * @see com.shopping.dao.UserDao#findUserById(int)
	 */
	public User findUserById(int id) {
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_user where id=?");
		ResultSet rs = null;
		User user = new User();
		try {
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while(rs.next()){
				user.setId(id);
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setRegDate(rs.getTimestamp(5));
				user.setAmount(orderDao.getUserMoney(rs.getInt(1)));
				user.setGrade(rs.getInt(7));
				user.setStatus(rs.getString(8));
				user.setRealname(rs.getString(9));
				user.setAddress(rs.getString(10));
				user.setPostcode(rs.getString(11));
				user.setProvince(rs.getString(12));
				user.setCity(rs.getString(13));
				user.setArea(rs.getString(14));
				user.setTel(rs.getString(15));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return user;
	}

	public void changeUserStatus(User user) {
		String status = user.getStatus();
		String sql = null;
		if(status.equals("unlock")){
			sql = "update t_user set status = 'locked' where id =?";
		} else {
			sql = "update t_user set status = 'unlock' where id =?";
		}
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, sql);
		try {
			conn.setAutoCommit(false);
			pstmt.setInt(1, user.getId());
			pstmt.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void changeUserPassword(User user,String newPassword) {
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "update t_user set password = ? where id = ?");
		try {
			conn.setAutoCommit(false);
			pstmt.setString(1, newPassword);
			pstmt.setInt(2, user.getId());
			pstmt.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void changeUserInformation(User user) {
		Connection conn = DBUtils.getConn();
		String sql = null;
		sql = "update t_user set realname=?,address=?,province=?,city=?,area=?,postcode=?,tel=? where id =?";
		PreparedStatement pstmt = DBUtils.getPstmt(conn, sql);
		try {
			pstmt.setString(1, user.getRealname());
			pstmt.setString(2, user.getAddress());
			pstmt.setString(3, user.getProvince());
			pstmt.setString(4, user.getCity());
			pstmt.setString(5, user.getArea());
			pstmt.setString(6, user.getPostcode());
			pstmt.setString(7, user.getTel());
			pstmt.setInt(8, user.getId());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<User> getUsers(int beginIndex,int userLength) {
		List<User> users = new ArrayList<User>();
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_user where username not in('admin')limit ?,?");
		ResultSet rs = null;
		try {
			pstmt.setInt(1, beginIndex);
			pstmt.setInt(2, userLength);
			rs = pstmt.executeQuery();
			while(rs.next()){
				User user = new User();
				user.setId(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setRegDate(rs.getTimestamp(5));
				user.setAmount(orderDao.getUserMoney(rs.getInt(1)));
				user.setGrade(rs.getInt(7));
				user.setStatus(rs.getString(8));
				user.setRealname(rs.getString(9));
				user.setAddress(rs.getString(10));
				user.setPostcode(rs.getString(11));
				user.setProvince(rs.getString(12));
				user.setCity(rs.getString(13));
				user.setArea(rs.getString(14));
				user.setTel(rs.getString(15));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return users;
	}
	
	public int getUserCount(){
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select count(*) from t_user");
		ResultSet rs = null;
		int n = -1;
		try {
			rs = pstmt.executeQuery();
			if(rs.next()){
				n = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return n;
	}
	
	
	//ʵ��ģ����ѯ������username�ؼ��ֽ��в�ѯ
	public List<User> findUsersByUsername(String username){
		Connection conn = DBUtils.getConn();
		String sql = "select * from t_user where username like '%"+username+"%'";
		PreparedStatement pstmt = DBUtils.getPstmt(conn, sql);
		ResultSet rs = null;
		List<User> users = new ArrayList<User>();
		try {
			rs = pstmt.executeQuery();
			while(rs.next()){
				User user = new User();
				user.setId(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setRegDate(rs.getTimestamp(5));
				user.setAmount(orderDao.getUserMoney(rs.getInt(1)));
				user.setGrade(rs.getInt(7));
				user.setStatus(rs.getString(8));
				user.setRealname(rs.getString(9));
				user.setAddress(rs.getString(10));
				user.setPostcode(rs.getString(11));
				user.setProvince(rs.getString(12));
				user.setCity(rs.getString(13));
				user.setArea(rs.getString(14));
				user.setTel(rs.getString(15));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return users;
	}
	
	public List<User> findUserByUid(int id) {
		Connection conn = DBUtils.getConn();
		PreparedStatement pstmt = DBUtils.getPstmt(conn, "select * from t_user where id=?");
		ResultSet rs = null;
		List<User> users = new ArrayList<User>();
		try {
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while(rs.next()){
				User user = new User();
				user.setId(id);
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setRegDate(rs.getTimestamp(5));
				user.setAmount(orderDao.getUserMoney(rs.getInt(1)));
				user.setGrade(rs.getInt(7));
				user.setStatus(rs.getString(8));
				user.setRealname(rs.getString(9));
				user.setAddress(rs.getString(10));
				user.setPostcode(rs.getString(11));
				user.setProvince(rs.getString(12));
				user.setCity(rs.getString(13));
				user.setArea(rs.getString(14));
				user.setTel(rs.getString(15));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtils.close(rs);
			DBUtils.close(pstmt);
			DBUtils.close(conn);
		}
		return users;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
