package com.shopping.exception;

public class PasswordErrorException extends RuntimeException {

}
