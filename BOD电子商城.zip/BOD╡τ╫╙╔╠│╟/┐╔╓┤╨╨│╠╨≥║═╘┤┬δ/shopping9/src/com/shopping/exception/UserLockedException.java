package com.shopping.exception;

public class UserLockedException extends RuntimeException {

}
