package com.shopping.exception;

public class UserNotFoundException extends RuntimeException {

}
