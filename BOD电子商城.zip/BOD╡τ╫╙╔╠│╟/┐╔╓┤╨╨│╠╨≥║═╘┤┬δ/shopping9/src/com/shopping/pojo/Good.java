package com.shopping.pojo;

import java.util.Date;
import java.util.List;


public class Good {
	private int id;
	private String gname;
	private List<GoodType> goodType;	
	private List<GoodType> smallgoodType;	
	private String img;
    private double price;
    private double marketprice;
	private int amount;
	private int buycount;
	private double rebate;
	private String issale;
	private String isvalid;
	private String content;
	private Date regtime;
	private int orderNum;
	
	public int getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public List<GoodType> getGoodType() {
		return goodType;
	}
	public void setGoodType(List<GoodType> list) {
		this.goodType = list;
	}
	public List<GoodType> getSmallgoodType() {
		return smallgoodType;
	}
	public void setSmallgoodType(List<GoodType> list) {
		this.smallgoodType = list;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getMarketprice() {
		return marketprice;
	}
	public void setMarketprice(double marketprice) {
		this.marketprice = marketprice;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getBuycount() {
		return buycount;
	}
	public void setBuycount(int buycount) {
		this.buycount = buycount;
	}
	public double getRebate() {
		return rebate;
	}
	public void setRebate(double rebate) {
		this.rebate = rebate;
	}
	public String getIssale() {
		return issale;
	}
	public void setIssale(String issale) {
		this.issale = issale;
	}
	public String getIsvalid() {
		return isvalid;
	}
	public void setIsvalid(String isvalid) {
		this.isvalid = isvalid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getRegtime() {
		return regtime;
	}
	public void setRegtime(Date regtime) {
		this.regtime = regtime;
	}

}
