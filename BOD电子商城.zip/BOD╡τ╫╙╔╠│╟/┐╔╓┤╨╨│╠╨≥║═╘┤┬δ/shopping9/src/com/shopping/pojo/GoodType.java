package com.shopping.pojo;

import java.util.List;


public class GoodType {
	private int id;
	private String typename;
	private String information;
	private String isleaf;
	private int fid;
	private List<GoodType> children;
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTypename() {
		return typename;
	}
	public void setTypename(String typename) {
		this.typename = typename;
	}
	public String getInformation() {
		return information;
	}
	public void setInformation(String information) {
		this.information = information;
	}
	public String getIsleaf() {
		return isleaf;
	}
	public void setIsleaf(String isleaf) {
		this.isleaf = isleaf;
	}
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public List<GoodType> getChildren() {
		return children;
	}
	public void setChildren(List<GoodType> children) {
		this.children = children;
	}
}
