package com.shopping.pojo;

public class PageBean {
	private static int LENGTH= 4;
	private int currentPage;
	private int totalPage;
	
	
	public static int getLENGTH() {
		return LENGTH;
	}
	public static void setLENGTH(int lENGTH) {
		LENGTH = lENGTH;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	
	
}
