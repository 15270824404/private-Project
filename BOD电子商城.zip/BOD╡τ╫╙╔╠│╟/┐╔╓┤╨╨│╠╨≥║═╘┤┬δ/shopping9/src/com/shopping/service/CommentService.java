package com.shopping.service;

import java.util.List;
import com.shopping.pojo.Comment;
import com.shopping.util.PageUtil;

public interface CommentService {
	public void addComment(int gid,int uid,String content);
	public List<Comment> getComments(int gid,PageUtil pageUtil);
	public void deleteCommentByGid(int gid);
	public void deleteCommentByUid(int uid);
	public boolean checkComment(int uid,int gid);
}
