package com.shopping.service;

import java.util.List;

import com.shopping.pojo.FavDetail;
import com.shopping.util.PageUtil;

public interface FavDetailService {
	public boolean addFavDetail(int uid,int gid);
	
	public List<FavDetail> getFavDetails(int uid,PageUtil pageUtil);
	
	public void deleteFav(int id);
}
