package com.shopping.service;

import java.util.List;

import com.shopping.pojo.Good;
import com.shopping.util.PageUtil;

public interface GoodService {	
    public Good showGoodById(int id);
    public void insertGood(int supertype,int typeID,String goodsName,int goodsAmount,double marketprice,double price,double rebate,String sale,String img,String content);
    public void updateGood(int id,int supertype,int typeID,String goodsName,int goodsAmount,double marketprice,double price,double rebate,String sale,String img,String content);
    public void updateGoodStatus(String isvalid,int id);
    public void updateGoodAmount(int amount,int id);
    public int showGoodAmount(int id);
    public List<Good> showSaleGoods();
    public List<Good> showBestGoods();
    public List<Good> showNewGoods(PageUtil pageUtil);
    public List<Good> showGoods(PageUtil pageUtil);
    public List<Good> showAllGoods();
    public List<Good> showSearchGoods(String gname,int gtid);
    public List<Good> showSearchGoodsByBGd(String gname,int gtid,int gsmallid);
    public List<Good> showGoodByGType(int id);
}
