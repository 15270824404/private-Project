package com.shopping.service;

import java.util.List;

import com.shopping.pojo.GoodType;

public interface GoodTypeService {
       
	public List<GoodType> showGoodTypeById(int id);
	public List<GoodType> showTopGoodType();
	public List<GoodType> showMiddleGoodType(int id);
	public void insertTopGood(String typename,String information);
	public void insertMiddleGood(String typename,String information,int fid);
	public void updataTopGoodType(int id,String typename,String information);
	public void updataMiddleGoodType(int id,String typename,String information);
	public void deleteMiddleGoodType(int id);
	public void deleteTopGoodType(int id);
}
