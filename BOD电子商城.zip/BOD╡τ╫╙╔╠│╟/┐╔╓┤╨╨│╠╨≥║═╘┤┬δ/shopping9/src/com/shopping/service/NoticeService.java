package com.shopping.service;

import java.util.List;

import com.shopping.pojo.Notice;
import com.shopping.util.PageUtil;

public interface NoticeService {
	public void addNotice(String title,String content,String uptime,String deadtime);
	public List<Notice> getNotices(PageUtil pageUtil);
	public void deleteNotice(int id);
	public Notice findNoticeById(int id);
	public void updateNotice(String title,String content,String uptime,String deadtime,int nid);
}
