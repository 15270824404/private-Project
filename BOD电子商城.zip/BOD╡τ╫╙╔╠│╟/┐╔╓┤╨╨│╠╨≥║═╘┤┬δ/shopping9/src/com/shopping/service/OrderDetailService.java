package com.shopping.service;

import java.util.List;

import com.shopping.pojo.OrderDetail;

public interface OrderDetailService {
	public List<OrderDetail> showOrderDetailByOid(int oid);
	public void addOrderDetail(int gid,int oid,int gnum);
	public double returnOrderTotalPrice(int oid);
	public int deleteOrderDetail(int id);
}
