package com.shopping.service;

import java.util.List;

import com.shopping.pojo.Order;
import com.shopping.util.PageUtil;

public interface OrderService {
	public List<Order> showUserOrders(int uid,PageUtil pageUtil);
	public List<Order> showAllOrders(int status,String num,PageUtil pageUtil); 
	public int addOrder(Order order,int uid);
	public Order findOrderById(int id);
	public void deleteOrder(int id);
	public void confirmOrder(int id);
	public void sendOrder(int id);
	public Order getLastOrder();
}
