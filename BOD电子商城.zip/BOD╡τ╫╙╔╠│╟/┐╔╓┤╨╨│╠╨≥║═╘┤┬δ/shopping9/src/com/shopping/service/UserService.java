package com.shopping.service;

import java.util.List;

import com.shopping.pojo.User;

public interface UserService {

	//ע��ʱ�����û�
	public int addUser(User user);
	
	public User getUserByUsername(String username);
	
	public List<User> getUsersByUsername(String username);
	
	public User getUserById(int id);
	
	public List<User> getUserByUid(int id);
	//��¼����
	public void login(String username,String password);
	//�޸Ļ�Ա״̬
	public void changeStatus(User user);
	//�޸Ļ�Ա����
	public void changePassword(User user, String oldPassword,String newPassword);
	
	public void changeInformation(User user);

	public List<User> getUsers(int currentPage);
	
 }
