package com.shopping.service.impl;

import java.util.List;

import com.shopping.dao.CommentDao;
import com.shopping.dao.factory.CommentDaoFactory;
import com.shopping.pojo.Comment;
import com.shopping.service.CommentService;
import com.shopping.util.PageUtil;

public class CommentServiceImpl implements CommentService {

	private static CommentDao commentDao;
	static{
		commentDao = CommentDaoFactory.getInstance("./daoConfig.properties", "CommentDao");
	}
	
	
	public void addComment(int gid, int uid, String content) {
		commentDao.addComment(uid, gid, content);

	}

	public void deleteCommentByGid(int gid) {
		commentDao.deleteCommentByGid(gid);

	}

	public void deleteCommentByUid(int uid) {
		commentDao.deleteCommentByUid(uid);

	}

	public List<Comment> getComments(int gid,PageUtil pageUtil) {
		return commentDao.getCommentByGid(gid,pageUtil);
	}

	public boolean checkComment(int uid,int gid){
		return commentDao.checkComment(uid, gid);
	}
}
