package com.shopping.service.impl;

import java.util.List;

import com.shopping.dao.FavDetailDao;
import com.shopping.dao.factory.FavDetailDaoFactory;
import com.shopping.pojo.FavDetail;
import com.shopping.service.FavDetailService;
import com.shopping.util.PageUtil;

public class FavDetailServiceImpl implements FavDetailService {
		private static FavDetailDao favDetailDao;
		static{
			favDetailDao = FavDetailDaoFactory.getInstance("./daoConfig.properties", "FavDetailDao");
		}
		
		public boolean addFavDetail(int uid,int gid){
			return favDetailDao.addFavDetail(uid, gid);
		}
		
		public List<FavDetail> getFavDetails(int uid,PageUtil pageUtil){
			return favDetailDao.getFavDetailsByFid(uid,pageUtil);
		}
		
		public void deleteFav(int id){
			favDetailDao.deleteFavDetail(id);
		}
}
