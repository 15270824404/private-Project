package com.shopping.service.impl;

import java.util.List;

import com.shopping.dao.GoodDao;
import com.shopping.dao.factory.GoodDaoFactory;
import com.shopping.pojo.Good;
import com.shopping.service.GoodService;
import com.shopping.util.PageUtil;

public class GoodServiceImpl implements GoodService {
	private static GoodDao goodDao;
	static{
		goodDao = GoodDaoFactory.getInstance("./daoConfig.properties", "GoodDao");	
	}	
	public Good showGoodById(int id) {
		  return goodDao.findGoodById(id);
		}
	public void insertGood(int supertype,int typeID,String goodsName,int goodsAmount,double marketprice,double price,double rebate,String sale,String img,String content) {
		  goodDao.addGood(supertype,typeID,goodsName,goodsAmount,marketprice,price,rebate,sale,img,content);
		}
	public void updateGood(int id,int supertype,int typeID,String goodsName,int goodsAmount,double marketprice,double price,double rebate,String sale,String img,String content) {
		 goodDao.renewGood(id,supertype,typeID,goodsName,goodsAmount,marketprice,price,rebate,sale,img,content);
		}
	public void updateGoodStatus(String isvalid,int id) {
		 goodDao.renewGoodStatus(isvalid,id);
		}
	public void updateGoodAmount(int amount,int id) {
		goodDao.renewGoodAmount(amount,id);
	    }
	public int showGoodAmount(int id) {
		return goodDao.selectGoodAmount(id);
	}
	public List<Good> showSaleGoods() {
		return goodDao.findSaleGoods();
	    }
	public List<Good> showBestGoods() {
		return goodDao.findBestGoods();
	}
	public List<Good> showNewGoods(PageUtil pageUtil) {
		return goodDao.findNewGoods(pageUtil);
	}
	public List<Good> showGoods(PageUtil pageUtil) {
		return goodDao.findGoods(pageUtil);
	}
	public List<Good> showAllGoods(){
		return goodDao.findAllGoods();
    }
	public List<Good> showSearchGoods(String gname,int gtid) {
		return goodDao.searchGoods(gname, gtid);
	}
	public List<Good> showSearchGoodsByBGd(String gname,int gtid,int gsmallid) {
		return goodDao.searchGoodsByBGd(gname, gtid, gsmallid);
	}
	public List<Good> showGoodByGType(int id) {
		return goodDao.selGoodByGType(id);
	}
}
