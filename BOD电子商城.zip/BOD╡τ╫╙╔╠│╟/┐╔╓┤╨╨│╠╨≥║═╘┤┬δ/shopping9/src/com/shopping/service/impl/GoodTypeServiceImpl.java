package com.shopping.service.impl;

import java.util.List;

import com.shopping.dao.GoodTypeDao;
import com.shopping.dao.factory.GoodTypeDaoFactory;
import com.shopping.pojo.GoodType;
import com.shopping.service.GoodTypeService;

public class GoodTypeServiceImpl implements GoodTypeService {
	private static GoodTypeDao goodTypeDao;
	
	static{
		goodTypeDao = GoodTypeDaoFactory.getInstance("./daoConfig.properties", "GoodTypeDao");
	}
	
	public List<GoodType> showGoodTypeById(int id) {
		 return goodTypeDao.findGoodTypeById(id);	
	}
	public List<GoodType> showTopGoodType() {
		return goodTypeDao.findTopGoodType();	
	}
	public List<GoodType> showMiddleGoodType(int id) {
		return goodTypeDao.findMiddleGoodType(id);	
	}
	public void  insertTopGood(String typename,String information){
		 goodTypeDao.addTopGood(typename, information);	
	}
	public void insertMiddleGood(String typename,String information,int fid){
		goodTypeDao.addMiddleGood(typename, information, fid);	
	}
	public void updataTopGoodType(int id,String typename,String information){
		goodTypeDao.renewTopGoodType(id, typename, information);	
	}
	public void updataMiddleGoodType(int id,String typename,String information){
		goodTypeDao.renewMiddleGoodType(id, typename, information);	
	}
	public void deleteMiddleGoodType(int id){
		goodTypeDao.removeMiddleGoodType(id);
	}
	public void deleteTopGoodType(int id){
		goodTypeDao.removeTopGoodType(id);
	}

}
