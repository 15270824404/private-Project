package com.shopping.service.impl;

import java.util.List;

import com.shopping.dao.NoticeDao;
import com.shopping.dao.factory.NoticeDaoFactory;
import com.shopping.pojo.Notice;
import com.shopping.service.NoticeService;
import com.shopping.util.PageUtil;

public class NoticeServiceImpl implements NoticeService {

	private static NoticeDao noticeDao;
	static{
		noticeDao = NoticeDaoFactory.getInstance("./daoConfig.properties", "NoticeDao");
	}
	public void addNotice(String title, String content, String uptime,
			String deadtime) {
		// TODO Auto-generated method stub
		noticeDao.addNotice(title, content, uptime, deadtime);
	}

	public void deleteNotice(int id) {
		noticeDao.deleteNotice(id);
	}

	public List<Notice> getNotices(PageUtil pageUtil) {
		return noticeDao.getNotices(pageUtil);
	}
	public Notice findNoticeById(int id){
		return noticeDao.findNoticeById(id);
	}
	public void updateNotice(String title,String content,String uptime,String deadtime,int nid){
		noticeDao.updateNotice(title, content, uptime, deadtime, nid);
	}

}
