package com.shopping.service.impl;

import java.util.List;

import com.shopping.dao.OrderDetailDao;
import com.shopping.dao.factory.OrderDetailDaoFactory;
import com.shopping.pojo.OrderDetail;
import com.shopping.service.OrderDetailService;

public class OrderDetailServiceImpl implements OrderDetailService {
	private static OrderDetailDao orderDetailDao;
	static {
		orderDetailDao = OrderDetailDaoFactory.getInstance("./daoConfig.properties", "OrderDetailDao");
	}
	public List<OrderDetail> showOrderDetailByOid(int oid){
		return orderDetailDao.findOrderDetailsByOid(oid);
	}
	public void addOrderDetail(int gid,int oid,int gnum){
		orderDetailDao.addOrderDetail(gid,oid,gnum);
	}
	public double returnOrderTotalPrice(int oid){
		return orderDetailDao.returnOrderTotalPrice(oid);
	}
	public int deleteOrderDetail(int id){
		return orderDetailDao.deleteOrderDetailById(id);
	}
}
