package com.shopping.service.impl;

import java.util.List;

import com.shopping.dao.OrderDao;
import com.shopping.dao.factory.OrderDaoFactory;
import com.shopping.pojo.Order;
import com.shopping.service.OrderService;
import com.shopping.util.PageUtil;

public class OrderServiceImpl implements OrderService {
	private static OrderDao orderDao;
	static{
		orderDao = OrderDaoFactory.getInstance("./daoConfig.properties", "OrderDao");
	}
	public int addOrder(Order order,int uid) {
		return orderDao.addOrder(order,uid);
	}
	public List<Order> showUserOrders(int uid,PageUtil pageUtil){
		return orderDao.showValidOrdersByUid(uid,pageUtil);
	}
	public List<Order> showAllOrders(int status,String num,PageUtil pageUtil){
		return orderDao.showOrders(status,num,pageUtil);
		
	}
	public Order findOrderById(int oid){
		return orderDao.findOrderById(oid);
	}
	public void deleteOrder(int id){
		orderDao.deleteOrderById(id);
	}
	public void confirmOrder(int id){
		orderDao.updateOrderStatus(id,3);
	}
	
	public void sendOrder(int id){
		orderDao.updateOrderStatus(id,2);
	}
	public Order getLastOrder(){
		return orderDao.getLastOrder();
	}
}
