package com.shopping.service.impl;

import com.shopping.pojo.User;

public interface UserService {

	//ע��ʱ����û�
	public int addUser(User user);
	
	public User getUserByUsername(String username);
	
	public User getUserById(int id);
	//��¼����
	public void login(String username,String password);
	//�޸Ļ�Ա״̬
	public void changeStatus(User user);
	//�޸Ļ�Ա����
	public void changePassword(User user, String oldPassword,String newPassword);
	
	public void changeInformation(User user,String newName,String newAddress,int newProvince,int newCity,int newArea,String newPostcode,String newTel);
	
 }
