package com.shopping.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.shopping.dao.UserDao;
import com.shopping.dao.factory.UserDaoFactory;
import com.shopping.exception.PasswordErrorException;
import com.shopping.exception.UserLockedException;
import com.shopping.exception.UserNotFoundException;
import com.shopping.pojo.PageBean;
import com.shopping.pojo.User;
import com.shopping.service.UserService;

public class UserServiceImpl implements UserService {
	private static UserDao userDao;
	static {
		userDao = UserDaoFactory.getInstance("daoConfig.properties","UserDao");
	}

	public int addUser(User user) {
		return userDao.saveUser(user);
	}

	public User getUserByUsername(String username) {
		return userDao.findUserByUsername(username);
	}
	//��usernameʵ��ģ����ѯ
	public List<User> getUsersByUsername(String username){
		return userDao.findUsersByUsername(username);
	}

	public User getUserById(int id) {
		return userDao.findUserById(id);
	}
	
	public List<User> getUserByUid(int id){
		return userDao.findUserByUid(id);
	}

	public void login(String username, String password) {
		User user = userDao.findUserByUsername(username);
		if (user.getUsername()== null) {
			throw new UserNotFoundException();
		} else if (user.getStatus().equals("locked")) {
			throw new UserLockedException();
		} else if (!user.getPassword().equals(password)) {
			throw new PasswordErrorException();
		}

	}

	public void changeStatus(User user) {
		userDao.changeUserStatus(user);
	}

	public void changePassword(User user,String oldPassword, String newPassword) {
		if(user.getPassword().equals(oldPassword)){
			userDao.changeUserPassword(user,newPassword);
		}else {
			throw new PasswordErrorException();
		}
	}

	public void changeInformation(User user) {
		userDao.changeUserInformation(user);
	}

	public List<User> getUsers(int currentPage) {
		int length = PageBean.getLENGTH();
		List<User> list = new ArrayList<User>();
		int userCount = userDao.getUserCount();
		int totalPage = (userCount%length==0)? (userCount/length):(userCount/length)+1;
		//limit n,mysql���ݿ�ѡȡ(n,n+m];
		int beginIndex = (currentPage-1)*length;
		int userLength = length;
		if(currentPage == totalPage){
			userLength = userCount - (currentPage-1)*length;
		}
		list = userDao.getUsers(beginIndex, userLength);
		return list;
		
	}
	
	
	
	
	
	
	

}
