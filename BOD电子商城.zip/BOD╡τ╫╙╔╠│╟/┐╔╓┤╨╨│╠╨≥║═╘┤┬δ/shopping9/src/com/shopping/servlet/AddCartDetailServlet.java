package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shopping.pojo.CartDetail;
import com.shopping.pojo.Good;
import com.shopping.service.GoodService;
import com.shopping.service.impl.GoodServiceImpl;

public class AddCartDetailServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int gid = Integer.parseInt(request.getParameter("gid"));	
		HttpSession session =  request.getSession();
		GoodService goodService = new GoodServiceImpl();
		Good good = goodService.showGoodById(gid);
		CartDetail  cartDetail = new CartDetail();
		List<CartDetail> cartDetails = (List<CartDetail>)session.getAttribute("cartDetails");
		
		cartDetail.setGood(good);
		
			cartDetail.setGnum(1);
			cartDetails.add(cartDetail);
			session.setAttribute("cartDetails",cartDetails);
		
		request.getRequestDispatcher("./index.jsp").forward(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
		
	}

}
