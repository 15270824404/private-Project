package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.dao.FavDetailDao;
import com.shopping.service.FavDetailService;
import com.shopping.service.impl.FavDetailServiceImpl;

public class AddFavDetailServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			PrintWriter out = response.getWriter();
			int gid = Integer.parseInt(request.getParameter("gid"));
			int uid = Integer.parseInt(request.getParameter("uid"));
			FavDetailService favDetailService = new FavDetailServiceImpl();
			boolean flag = favDetailService.addFavDetail(uid, gid);
			StringBuffer str =new StringBuffer();
			if(flag){
				str.append("{flag:1}");
			}else{
				str.append("{flag:0}");
			}
			out.print(str);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
