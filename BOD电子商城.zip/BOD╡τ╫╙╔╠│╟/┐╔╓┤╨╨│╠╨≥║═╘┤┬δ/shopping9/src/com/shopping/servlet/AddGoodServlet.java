package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Good;
import com.shopping.service.GoodService;
import com.shopping.service.impl.GoodServiceImpl;

public class AddGoodServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		    request.setCharacterEncoding("UTF-8");
            int supertype = Integer.parseInt(request.getParameter("supertype"));
            int typeID = Integer.parseInt(request.getParameter("typeID"));
            String goodsName =request.getParameter("goodsName");
            int goodsAmount = Integer.parseInt(request.getParameter("goodsAmount"));
            double marketprice = Double.parseDouble((request.getParameter("marketprice")));
            double price = Double.parseDouble(request.getParameter("price"));
            double rebate = Double.parseDouble(request.getParameter("rebate"));
            String sale = request.getParameter("sale");
            String img ="images/goods/"+request.getParameter("img");            
            String content =request.getParameter("content");
            GoodService gService = new GoodServiceImpl();
            gService.insertGood(supertype, typeID, goodsName, goodsAmount, marketprice, price, rebate, sale, img, content);
            request.getRequestDispatcher("./manage/goodManage.jsp").forward(request,response);
            
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doGet(request, response);
	}

}
