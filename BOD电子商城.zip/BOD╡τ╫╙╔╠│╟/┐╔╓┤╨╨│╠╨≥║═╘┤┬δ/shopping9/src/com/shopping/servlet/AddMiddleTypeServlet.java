package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.CORBA.Request;

import com.shopping.service.GoodTypeService;
import com.shopping.service.impl.GoodTypeServiceImpl;
import com.sun.org.apache.regexp.internal.recompile;

public class AddMiddleTypeServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			request.setCharacterEncoding("UTF-8");
		    String typename = request.getParameter("typename");
		    String information = request.getParameter("information");
		    int fid = Integer.parseInt(request.getParameter("fid"));
		    GoodTypeService gTypeService = new GoodTypeServiceImpl();
		    gTypeService.insertMiddleGood(typename, information, fid);
		    request.getRequestDispatcher("showTopTypes.do").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doGet(request, response);
	}

}
