package com.shopping.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.dao.OrderId;
import com.shopping.pojo.CartDetail;
import com.shopping.pojo.Order;
import com.shopping.service.OrderDetailService;
import com.shopping.service.OrderService;
import com.shopping.service.impl.OrderDetailServiceImpl;
import com.shopping.service.impl.OrderServiceImpl;

public class AddOrderServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int uid = 0;
		if (request.getParameter("uid")!=null){
			uid = Integer.parseInt(request.getParameter("uid"));
		}else{
			request.setAttribute("path", "cart_checkout.jsp");
			request.setAttribute("infor", "亲，请您先登录再提交订单！！");
			request.getRequestDispatcher("infor.jsp").forward(request, response);
		}

		List<CartDetail> cartDetails = (List<CartDetail>)request.getSession().getAttribute("cartDetails");
		
		OrderService orderService = new OrderServiceImpl();
		Order lastOrder = orderService.getLastOrder();		
		OrderDetailService orderDetailService = new OrderDetailServiceImpl();
		Date orddate = new Date();		
		
		
		String num = "";
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMdd");
		System.out.println(lastOrder.getNum());
		int queer = Integer.parseInt(lastOrder.getNum().substring(3));
		queer++;
		if (queer < 10){
			num = "000"+queer;
		}else if (queer<100){
			num = "00"+queer;
		}else if (queer <1000){
			num ="0"+queer;
		}else{
			num=queer+"" + OrderId.getOrderId();
		}
		if (sdf1.format(orddate).equals(sdf1.format(lastOrder.getOrdtime()))){
			num = sdf1.format(orddate)+num + OrderId.getOrderId();
		}else{
			num = sdf1.format(orddate)+"0001" + OrderId.getOrderId();
		}
		int paymethod = Integer.parseInt(request.getParameter("paymethod"));
		int sendmethod = Integer.parseInt(request.getParameter("sendmethod"));
		int status = 1;
		
		String realname = request.getParameter("realname");
		String address = request.getParameter("address");
		String postcode = request.getParameter("postcode");
		
//		int province =Integer.parseInt(request.getParameter("province"));
//		int city =Integer.parseInt(request.getParameter("city"));
//		int area =Integer.parseInt(request.getParameter("area"));
		
		String tel = request.getParameter("tel");
		String remark =  request.getParameter("remark");
		lastOrder.setAddress(address);
		lastOrder.setNum(num);
		lastOrder.setPostcode(postcode);
		lastOrder.setRealname(realname);
		lastOrder.setRemark(remark);
		lastOrder.setPaymethod(paymethod);
		lastOrder.setSendmethod(sendmethod);
		lastOrder.setStatus(status);
//		lastOrder.setProvince(1);
//		lastOrder.setCity(1);
//		lastOrder.setArea(1);
		lastOrder.setTel(tel);
		int oid = orderService.addOrder(lastOrder,uid);
		for (Iterator<CartDetail> i= cartDetails.iterator();i.hasNext();){
			CartDetail cartDetail = i.next();
			orderDetailService.addOrderDetail(cartDetail.getGood().getId(),oid,cartDetail.getGnum());
		}
		request.getRequestDispatcher("./showOrdersForUser.do?uid="+uid).forward(request, response);
	
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			this.doGet(request, response);
	
	}

}
