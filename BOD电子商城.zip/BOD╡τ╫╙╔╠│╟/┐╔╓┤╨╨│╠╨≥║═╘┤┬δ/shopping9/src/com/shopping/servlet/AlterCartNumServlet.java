package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.CartDetail;

public class AlterCartNumServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<CartDetail> cartDetails = (List<CartDetail>) request.getSession().getAttribute("cartDetails");
		List<CartDetail> cartDetails2 = new ArrayList<CartDetail>();
		int i = 1;
		for (Iterator<CartDetail> it = cartDetails.iterator();it.hasNext();){
			CartDetail cartDetail = it.next();
			int gnum =  Integer.parseInt(request.getParameter("cartDetail"+(i++)));
			cartDetail.setGnum(gnum);
			cartDetails2.add(cartDetail);
		}
		request.getSession().setAttribute("cartDetails", cartDetails2);
		request.getRequestDispatcher("./cart_add.jsp").forward(request, response);
	
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			this.doGet(request, response);
		
	}

}
