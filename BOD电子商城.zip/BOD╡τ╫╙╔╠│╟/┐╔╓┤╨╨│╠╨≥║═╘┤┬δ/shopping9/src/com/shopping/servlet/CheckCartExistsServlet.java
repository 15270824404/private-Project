package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shopping.pojo.CartDetail;
import com.shopping.pojo.Good;
import com.shopping.service.GoodService;
import com.shopping.service.impl.GoodServiceImpl;

public class CheckCartExistsServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		boolean flag =true ;
		HttpSession session = request.getSession();
		int gid = Integer.parseInt(request.getParameter("gid"));
		GoodService goodService = new GoodServiceImpl();
		Good good = goodService.showGoodById(gid);
		List<CartDetail> cartDetails = (List<CartDetail>)session.getAttribute("cartDetails");
		for (Iterator<CartDetail> i = cartDetails.iterator();i.hasNext();){
			CartDetail cartDetail = i.next();
			if (good.getId() == cartDetail.getGood().getId()){
				flag = false;
				break;
			}
		}
		StringBuffer str = new StringBuffer();
		if (flag){
			str.append("{flag:"+1+"}");
		}else{
			str.append("{flag:"+0+"}");
		}
		out.print(str);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
