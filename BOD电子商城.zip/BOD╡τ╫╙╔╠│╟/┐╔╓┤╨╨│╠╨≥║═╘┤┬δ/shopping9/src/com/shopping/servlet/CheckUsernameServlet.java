package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.User;
import com.shopping.service.UserService;
import com.shopping.service.impl.UserServiceImpl;

public class CheckUsernameServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/xml");
		PrintWriter out = response.getWriter();

		response.setHeader("Cache-Control", "no-control");
		String username = request.getParameter("username");

		UserService us = new UserServiceImpl();
		User user = null;
		String str = "";
		user = us.getUserByUsername(username);
		if ((username == null) || ("".equals(username))) {
			// 2��ʾû�����û���
			str = "<root>2</root>";
		} else {
			if (user.getId() > 0) {
				// 0��ʾ���û���������
				str = "<root>3</root>";
			} else {
				// 1��ʾ���û�������
				str = "<root>1</root>";
			}
		}
		out.println(str);
		out.flush();
		out.close();
	}
}
