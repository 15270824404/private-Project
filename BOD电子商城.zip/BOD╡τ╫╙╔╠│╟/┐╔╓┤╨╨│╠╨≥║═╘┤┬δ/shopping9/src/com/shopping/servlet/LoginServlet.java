package com.shopping.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shopping.exception.PasswordErrorException;
import com.shopping.exception.UserLockedException;
import com.shopping.exception.UserNotFoundException;
import com.shopping.pojo.User;
import com.shopping.service.UserService;
import com.shopping.service.impl.UserServiceImpl;

public class LoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String username = request.getParameter("username");
		String pwd = request.getParameter("pwd");
		User user = null;
		UserService us = new UserServiceImpl();
		user = us.getUserByUsername(username);
		String path = "";
		String infor = "";
		try {
			us.login(username, pwd);
			session.setAttribute("user", user);
			infor = "登陆成功";
			path = "index.jsp";
		} catch (UserNotFoundException e) {
			infor = "用户名不存在!!请重新登录";
			path = "index.jsp";
		} catch (PasswordErrorException e) {
			infor = "密码错误!!!请核实后重新登录";
			path = "index.jsp";
		} catch (UserLockedException e) {
			infor = "对不起，您的用户已系统被冻结，请与管理员联系";
			path = "index.jsp";
		}
		request.setAttribute("path", path);
		request.setAttribute("infor", infor);
		request.getRequestDispatcher("infor.jsp").forward(request, response);
		
	}

}
