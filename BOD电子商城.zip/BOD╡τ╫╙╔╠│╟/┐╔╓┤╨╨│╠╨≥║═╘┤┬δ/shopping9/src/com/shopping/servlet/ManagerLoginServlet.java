package com.shopping.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shopping.exception.PasswordErrorException;
import com.shopping.pojo.User;
import com.shopping.service.UserService;
import com.shopping.service.impl.UserServiceImpl;

public class ManagerLoginServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String manager = request.getParameter("manager");
		String pwd = request.getParameter("pwd");
		if(!manager.equals("admin")){
			request.setAttribute("infor", "对不起，您不是管理员允许登录后台");
			request.setAttribute("path", "./manage/login.jsp");
		}else{
			UserService us = new UserServiceImpl();
			User user = us.getUserByUsername(manager);
			try {
				us.login(manager, pwd);
				session.setAttribute("user", user);
				request.setAttribute("infor", "登录成功，三秒钟自动跳转到相应页面");
				request.setAttribute("path", "showUserServlet");
			} catch (PasswordErrorException e) {
				request.setAttribute("infor", "管理员密码错误!");
				request.setAttribute("path", "./manage/login.jsp");
			}
		}
		request.getRequestDispatcher("infor.jsp").forward(request, response);

	}

}
