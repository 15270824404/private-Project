package com.shopping.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.exception.PasswordErrorException;
import com.shopping.pojo.User;
import com.shopping.service.UserService;
import com.shopping.service.impl.UserServiceImpl;

public class ModifyPwdServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String oldPassword = request.getParameter("oldpwd");
		String newPassword = request.getParameter("newpwd");
		UserService us = new UserServiceImpl();
		User user = new User();
		user = (User)request.getSession().getAttribute("user");
		String path = "member.jsp";
		String infor = null;
		try {
			us.changePassword(user, oldPassword, newPassword);
			infor = "密码修改成功";
		} catch (PasswordErrorException e) {
			infor = "密码修改失败，原密码错误";
			e.printStackTrace();
		}
		request.setAttribute("path", path);
		request.setAttribute("infor", infor);
		request.getRequestDispatcher("infor.jsp").forward(request, response);
	}

}
