package com.shopping.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shopping.exception.PasswordErrorException;
import com.shopping.pojo.User;
import com.shopping.service.UserService;
import com.shopping.service.impl.UserServiceImpl;

public class ModifyUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = new User();
		user = (User)request.getSession().getAttribute("user");
		String realname = request.getParameter("truename");
		String address = request.getParameter("address");
		String province = request.getParameter("province");
		String city = request.getParameter("city");
		String area = request.getParameter("area");
		String postcode = request.getParameter("postcode");
		String tel = request.getParameter("telephone");
		user.setRealname(realname);
		user.setAddress(address);
		user.setProvince(province);
		user.setCity(city);
		user.setArea(area);
		user.setPostcode(postcode);
		user.setTel(tel);
		
		UserService us = new UserServiceImpl();
		
		String path = "member.jsp";
		String infor = null;
		try {
			us.changeInformation(user);
			infor = "资料修改成功";
		} catch (Exception e) {
			infor = "资料修改失败";
			e.printStackTrace();
		}
		request.setAttribute("path", path);
		request.setAttribute("infor", infor);
		request.getRequestDispatcher("infor.jsp").forward(request, response);
		
	}

}
