package com.shopping.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.User;
import com.shopping.service.UserService;
import com.shopping.service.impl.UserServiceImpl;

public class RegisterServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String username = request.getParameter("username");
		String password = request.getParameter("pwd");
		String email = request.getParameter("email");
		String realname = request.getParameter("truename");
		String address = request.getParameter("address");
		String province = request.getParameter("province");
		String city = request.getParameter("city");
		String area = request.getParameter("area");
		String postcode = request.getParameter("postcode");
		String telephone = request.getParameter("telephone");
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		user.setRealname(realname);
		user.setAddress(address);
		user.setProvince(province);
		user.setCity(city);
		user.setArea(area);
		user.setPostcode(postcode);
		user.setTel(telephone);
		UserService us = new UserServiceImpl();
		int n = -1;
		n = us.addUser(user);
		String infor = "";
		String path = "";
		if(n == 1){
			infor = "注册成功";
			path = "index.jsp";
		}else{
			infor = "注册失败，请重试";
			path = "register.jsp";
		}
		request.setAttribute("infor", infor);
		request.setAttribute("path", path);
		request.getRequestDispatcher("infor.jsp").forward(request, response);
	}

}
