package com.shopping.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Good;
import com.shopping.service.GoodService;
import com.shopping.service.impl.GoodServiceImpl;

public class SearchGoodsServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		   request.setCharacterEncoding("UTF-8");
           int gtid = Integer.parseInt(request.getParameter("supertype"));           
           String gname = request.getParameter("key");
           int isSmallid = Integer.parseInt(request.getParameter("isSmallid"));//判断从前台还是后台传过来的页面，前台没有小类，后台需要小类,后台传1，前台传0
                   
           GoodService gService = new GoodServiceImpl();
           List<Good> good = new ArrayList<Good>();
//           if(isSmallid==1){
//        	   int gsmallid = Integer.parseInt(request.getParameter("typeID"));
//        	   good = gService.showSearchGoodsByBGd(gname, gtid, gsmallid);
//        	
          // }else if(isSmallid==0){
        	   good = gService.showSearchGoods(gname, gtid);
              
          // }    
           request.setAttribute("good",good );
           request.setAttribute("searchName", gname);
           request.getRequestDispatcher("search_deal.jsp").forward(request, response);         
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doGet(request, response);
	}

}
