package com.shopping.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.PageBean;
import com.shopping.pojo.User;
import com.shopping.service.UserService;
import com.shopping.service.impl.UserServiceImpl;
import com.shopping.util.UserPage;

public class SearchUserServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int currentPage = 1;
		Object opage = request.getParameter("page");
		currentPage = (opage==null)?1:(Integer.parseInt((String)opage));
		
		int uid = ("".equals(request.getParameter("uid")))? 0:Integer.parseInt(request.getParameter("uid"));
		String username = (request.getParameter("username").equals(null))? "":request.getParameter("username");
		
		List<User> users = new ArrayList<User>();
		UserService us = new UserServiceImpl();
		users = us.getUsers(currentPage);
		PageBean page = new PageBean();
		page = UserPage.getPage(currentPage);
		
		request.setAttribute("page", page);
		request.setAttribute("users", users);
		request.setAttribute("url","showUserServlet");
		
		//List<User> users = new ArrayList<User>();		
		//UserService us = new UserServiceImpl();
		if(uid==0){
			users = us.getUsersByUsername(username);
		}else{
			users = us.getUserByUid(uid);
		}
		//修改3.31
		int count = UserPage.getUserCount();
		request.setAttribute("count", count);
//修改3.31
		
		request.setAttribute("users", users);
		request.getRequestDispatcher("manage/memberManage.jsp").forward(request, response);
	}

}
