package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.shopping.pojo.GoodType;
import com.shopping.service.GoodTypeService;
import com.shopping.service.impl.GoodTypeServiceImpl;

public class SelGoodsTypeServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		     request.setCharacterEncoding("UTF-8");
		     response.setContentType( "text/html;charset=UTF-8");
		     PrintWriter out = response.getWriter();
		     GoodTypeService gTypeService = new GoodTypeServiceImpl();
		     List<GoodType> goodTypes = gTypeService.showTopGoodType();
		     StringBuffer str = new StringBuffer("[");
		     for(int i=0;i<goodTypes.size();i++){
		    	str.append("{").append("id:").append(goodTypes.get(i).getId())
		    	.append(",").append("typename:'").append(goodTypes.get(i).getTypename()).append("'}").append(",");
		     }
             str.deleteCharAt(str.length()-1);
             str.append("]");
             out.print(str);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doGet(request, response);
	}

}
