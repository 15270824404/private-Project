package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Comment;
import com.shopping.pojo.Good;
import com.shopping.pojo.GoodType;
import com.shopping.service.CommentService;
import com.shopping.service.GoodService;
import com.shopping.service.GoodTypeService;
import com.shopping.service.impl.CommentServiceImpl;
import com.shopping.service.impl.GoodServiceImpl;
import com.shopping.service.impl.GoodTypeServiceImpl;
import com.shopping.util.PageUtil;

public class ShowClickGoodServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	        int id = Integer.parseInt(request.getParameter("id"));
	        PageUtil pageUtil = new PageUtil();
	        pageUtil.setCurrentPage(1);
	        if (request.getParameter("cp")!= null){
	        	pageUtil.setCurrentPage(Integer.parseInt(request.getParameter("cp")));
	        }
	        pageUtil.setPageRecord(5);
	        GoodService gService = new GoodServiceImpl();
		    Good good= gService.showGoodById(id);
		    CommentService commentService = new CommentServiceImpl();
		    List<Comment> comments = commentService.getComments(id,pageUtil);
		    request.setAttribute("comments", comments);		 
		    request.setAttribute("good", good);
		    request.getRequestDispatcher("goods_detail.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doGet(request, response);
	}

}
