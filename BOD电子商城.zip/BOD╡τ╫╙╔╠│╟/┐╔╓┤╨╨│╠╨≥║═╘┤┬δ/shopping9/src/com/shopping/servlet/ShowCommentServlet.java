package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Comment;
import com.shopping.service.CommentService;
import com.shopping.service.impl.CommentServiceImpl;
import com.shopping.util.PageUtil;

public class ShowCommentServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			int gid = Integer.parseInt(request.getParameter("gid"));
			PageUtil pageUtil = new PageUtil();
			pageUtil.setCurrentPage(1);
			if (request.getParameter("cp")!= null){
				pageUtil.setCurrentPage(Integer.parseInt(request.getParameter("cp")));
			}
			pageUtil.setPageRecord(5);
			CommentService commentService = new CommentServiceImpl();
			List<Comment> comments = commentService.getComments(gid,pageUtil);
			request.setAttribute("comments", comments);
			request.getRequestDispatcher("").forward(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
