package com.shopping.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.FavDetail;
import com.shopping.service.FavDetailService;
import com.shopping.service.impl.FavDetailServiceImpl;
import com.shopping.util.PageUtil;

public class ShowFavDetailServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int uid = Integer.parseInt(request.getParameter("uid"));
		PageUtil pageUtil = new PageUtil();
		pageUtil.setCurrentPage(1);
		if (request.getParameter("cp")!=null){
			pageUtil.setCurrentPage(Integer.parseInt(request.getParameter("cp")));
		}
		pageUtil.setPageRecord(10);
		
		FavDetailService favDetailService = new FavDetailServiceImpl();
		List<FavDetail> favDetails = favDetailService.getFavDetails(uid,pageUtil);
		request.setAttribute("favDetails", favDetails);
		request.setAttribute("pageUtil", pageUtil);
		request.getRequestDispatcher("./favourite.jsp").forward(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			this.doGet(request, response);
	}

}
