package com.shopping.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Good;
import com.shopping.service.GoodService;
import com.shopping.service.impl.GoodServiceImpl;
import com.shopping.util.PageUtil;

public class ShowGoodManageServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
        PageUtil pageUtil = new PageUtil();
	    pageUtil.setCurrentPage(1);
	    if(request.getParameter("cpage")!=null){
	    	pageUtil.setCurrentPage(Integer.parseInt(request.getParameter("cpage")));
	    }
	    pageUtil.setPageRecord(3);	    
        GoodService gService = new GoodServiceImpl();
        List<Good> goods = gService.showGoods(pageUtil);
        request.setAttribute("goods", goods);
        request.setAttribute("pageUtil", pageUtil);
        request.getRequestDispatcher("./manage/goodManage.jsp").forward(request,response);
		    
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doGet(request, response);
	}

}
