package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Good;
import com.shopping.service.GoodService;
import com.shopping.service.impl.GoodServiceImpl;

public class ShowGoodsByTypeServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            request.setCharacterEncoding("UTF-8");
            int id =  Integer.parseInt(request.getParameter("fid"));
            GoodService gService = new GoodServiceImpl();
            List<Good> typeGoods = gService.showGoodByGType(id);
            if(typeGoods.size()==0){
            	request.setAttribute("typeName", null);
                request.setAttribute("smallTyepName", null);        	
            }else{
            String typeName = typeGoods.get(0).getGoodType().get(0).getTypename();
            String smallTyepName =  typeGoods.get(0).getSmallgoodType().get(0).getTypename();
            request.setAttribute("typeName", typeName);
            request.setAttribute("smallTyepName", smallTyepName);
            }
            request.setAttribute("typeGoods", typeGoods);
           
            request.getRequestDispatcher("./type.jsp").forward(request, response);            
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
           this.doGet(request, response);
	}

}
