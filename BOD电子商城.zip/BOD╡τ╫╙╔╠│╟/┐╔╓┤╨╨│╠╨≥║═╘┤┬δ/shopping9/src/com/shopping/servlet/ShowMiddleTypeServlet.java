package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Good;
import com.shopping.pojo.GoodType;
import com.shopping.service.GoodService;
import com.shopping.service.GoodTypeService;
import com.shopping.service.impl.GoodServiceImpl;
import com.shopping.service.impl.GoodTypeServiceImpl;

public class ShowMiddleTypeServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		    request.setCharacterEncoding("UTF-8");
		    int id = Integer.parseInt(request.getParameter("id"));
		    String topTypeName = request.getParameter("topTypeName");
            GoodTypeService gTypeService = new GoodTypeServiceImpl();
            List<GoodType> goodMiddleTypes = gTypeService.showMiddleGoodType(id);
            request.setAttribute("goodMiddleTypes", goodMiddleTypes);
            request.setAttribute("topTypeName",topTypeName);
            request.setAttribute("id",id);
            request.getRequestDispatcher("./manage/showMiddleType.jsp").forward(request,response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doGet(request, response);
	}

}
