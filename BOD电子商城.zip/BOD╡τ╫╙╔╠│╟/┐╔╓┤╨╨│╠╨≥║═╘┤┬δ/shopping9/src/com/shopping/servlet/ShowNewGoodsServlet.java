package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Good;
import com.shopping.pojo.Notice;
import com.shopping.service.GoodService;
import com.shopping.service.NoticeService;
import com.shopping.service.impl.GoodServiceImpl;
import com.shopping.service.impl.NoticeServiceImpl;
import com.shopping.util.PageUtil;

public class ShowNewGoodsServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            request.setCharacterEncoding("UTF-8");
            int a = Integer.parseInt(request.getParameter("a"));
            
            GoodService gService = new GoodServiceImpl();
            
            NoticeService noticeService = new NoticeServiceImpl();
            PageUtil pageUtil = new PageUtil();
     		pageUtil.setPageRecord(5);
     		pageUtil.setCurrentPage(1);
     		if (request.getParameter("cp")!= null){
     			pageUtil.setCurrentPage(Integer.parseInt(request.getParameter("cp")));
     		}
     		List<Notice> notices = noticeService.getNotices(pageUtil);
     		
            List<Good> goods = gService.showNewGoods(pageUtil);
            List<Good> saleGoods = gService.showSaleGoods();
            List<Good> bestGoods = gService.showBestGoods();
            request.setAttribute("goods",goods); 
            request.setAttribute("saleGoods", saleGoods);
            request.setAttribute("bestGoods", bestGoods);
            
            request.setAttribute("notices", notices);
     		request.setAttribute("pageUtil", pageUtil);
            
            
            String path = "index.jsp";
            if(a==0){
            	request.getRequestDispatcher(path).forward(request,response);
            }else if(a==1){
            	path="goods_detail.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }
            else if(a==2){
            	path="newGoods.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }
            else if(a==3){
                
            	path="saleGood.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }
            else if(a==4){
            	path="sellSort.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }
            else if(a==5){
            	path="search_deal.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==6){
            	path="placard_detail.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==7){
            	path="order.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==8){
            	path="cart_add.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==9){
            	path="cart_see.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==10){
            	path="favourite.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==11){
            	path="order_detail.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==12){
            	path="member.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==13){
            	path="cart_checkout.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==14){
            	path="register.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
            else if(a==15){
            	path="type.jsp";
            	request.getRequestDispatcher(path).forward(request,response);
            }           
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
             this.doGet(request, response);    		
	}

}
