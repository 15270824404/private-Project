package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.service.impl.NoticeServiceImpl;
import com.shopping.pojo.Notice;
import com.shopping.service.NoticeService;

public class ShowNoticeDetailServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		int nid = Integer.parseInt(request.getParameter("nid"));
//		int a = Integer.parseInt(request.getParameter("a"));
		NoticeService noticeService = new NoticeServiceImpl();
		Notice notice = noticeService.findNoticeById(nid);
		request.setAttribute("notice", notice);
		request.getRequestDispatcher("./placard_detail.jsp?nid="+nid).forward(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
		
	}

}
