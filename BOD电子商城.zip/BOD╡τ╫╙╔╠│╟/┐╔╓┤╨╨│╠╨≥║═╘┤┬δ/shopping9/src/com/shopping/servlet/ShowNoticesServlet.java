package com.shopping.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.service.impl.NoticeServiceImpl;
import com.shopping.pojo.Notice;
import com.shopping.service.NoticeService;
import com.shopping.util.PageUtil;

public class ShowNoticesServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		NoticeService noticeService = new NoticeServiceImpl();
		PageUtil pageUtil = new PageUtil();
		pageUtil.setPageRecord(3);
		pageUtil.setCurrentPage(1);
		if (request.getParameter("cp")!= null){
			pageUtil.setCurrentPage(Integer.parseInt(request.getParameter("cp")));
		}
		List<Notice> notices = noticeService.getNotices(pageUtil);
		request.setAttribute("notices", notices);
		request.setAttribute("pageUtil", pageUtil);
        request.getRequestDispatcher("./manage/placardManage.jsp").forward(request, response);
        
//        if(a==0){
//        	request.getRequestDispatcher(path).forward(request,response);
//        }else if(a==1){
//        	path="goods_detail.jsp";
//        	request.getRequestDispatcher(path).forward(request,response);
//        }
//        else if(a==2){
//        	path="newGoods.jsp";
//        	request.getRequestDispatcher(path).forward(request,response);
//        }
//        else if(a==3){
//        	path="saleGood.jsp";
//        	request.getRequestDispatcher(path).forward(request,response);
//        }
//        else if(a==4){
//        	path="sellSort.jsp";
//        	request.getRequestDispatcher(path).forward(request,response);
//        }else if(a==5){
//        	path ="placard_detail.jsp";
//        	request.getRequestDispatcher(path).forward(request, response);
//        }else if (a==6){
//        	path="./manage/placardManage.jsp";
//        	request.getRequestDispatcher(path).forward(request, response);
//        }
		
	
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			this.doGet(request, response);
	}

}
