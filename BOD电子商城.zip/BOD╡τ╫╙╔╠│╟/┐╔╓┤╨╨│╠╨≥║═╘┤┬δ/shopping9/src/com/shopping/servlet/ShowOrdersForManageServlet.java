package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.Order;
import com.shopping.service.OrderService;
import com.shopping.service.impl.OrderServiceImpl;
import com.shopping.util.PageUtil;

public class ShowOrdersForManageServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setHeader("Pragma","No-cache"); 
	    response.setHeader("Cache-Control","no-cache");
	    response.setHeader("Cache-Control", "no-store");
	    response.setDateHeader("Expires", 0);
	    PageUtil pageUtil = new PageUtil();
	    pageUtil.setCurrentPage(1);
	    pageUtil.setPageRecord(10);
		int status = Integer.parseInt(request.getParameter("status"));
		if (request.getParameter("cp") !=null){
			pageUtil.setCurrentPage(Integer.parseInt(request.getParameter("cp")));
		}
		String oid = request.getParameter("num");
		if (oid.equals("") ){
			oid = "-1";
		}else{
			oid =request.getParameter("num");
		}
		
		OrderService orderService = new OrderServiceImpl();
		List<Order> orders = orderService.showAllOrders(status,oid,pageUtil);
		request.setAttribute("num", oid);
		request.setAttribute("status", status);		
		request.setAttribute("orders", orders);
		request.setAttribute("pageUtil", pageUtil);
		request.getRequestDispatcher("./manage/orderManage.jsp").forward(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
