package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.dao.OrderDao;
import com.shopping.pojo.Order;
import com.shopping.service.OrderService;
import com.shopping.service.impl.OrderServiceImpl;
import com.shopping.util.PageUtil;

public class ShowOrdersForUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		int uid = 0;
		if(request.getParameter("uid")!=""){
			uid = Integer.parseInt(request.getParameter("uid"));
		}else{
			request.setAttribute("path", "index.jsp");
			request.setAttribute("infor", "亲，请登录后再查询订单");
			request.getRequestDispatcher("./infor.jsp").forward(request, response);
			return;
		}
		
		PageUtil pageUtil = new PageUtil();
		pageUtil.setCurrentPage(1);
		if (request.getParameter("cp")!= null){
			pageUtil.setCurrentPage(Integer.parseInt(request.getParameter("cp")));
		}
		pageUtil.setPageRecord(5);
		OrderService orderService = new OrderServiceImpl();
		List<Order> orders = orderService.showUserOrders(uid,pageUtil);
		request.setAttribute("orders", orders);
		request.setAttribute("pageUtil", pageUtil);
		request.getRequestDispatcher("order.jsp").forward(request, response);
	
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	
	}

}
