package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.dao.impl.GoodType4MySqlImpl;
import com.shopping.pojo.GoodType;
import com.shopping.service.GoodService;
import com.shopping.service.GoodTypeService;
import com.shopping.service.impl.GoodServiceImpl;
import com.shopping.service.impl.GoodTypeServiceImpl;

public class ShowTopTypesServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		    request.setCharacterEncoding("UTF-8");
		    GoodTypeService gTypeService = new GoodTypeServiceImpl();
		    List<GoodType> goodTypes = gTypeService.showTopGoodType();
		    request.setAttribute("goodTypes", goodTypes);
		    request.getRequestDispatcher("./manage/parameterManager.jsp").forward(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doGet(request, response);
	}

}
