package com.shopping.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.pojo.PageBean;
import com.shopping.pojo.User;
import com.shopping.service.UserService;
import com.shopping.service.impl.UserServiceImpl;
import com.shopping.util.UserPage;

public class ShowUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int currentPage = 1;
		Object opage = request.getParameter("page");
		currentPage = (opage==null)?1:(Integer.parseInt((String)opage));
		List<User> users = new ArrayList<User>();
		UserService us = new UserServiceImpl();
		users = us.getUsers(currentPage);
		PageBean page = new PageBean();
		page = UserPage.getPage(currentPage);
		
//修改3.31
		int count = UserPage.getUserCount();
		request.setAttribute("count", count);
//修改3.31
		
		request.setAttribute("page", page);
		request.setAttribute("users", users);
		request.setAttribute("url","showUserServlet");
		request.getRequestDispatcher("manage/memberManage.jsp").forward(request, response);
	
	}

}
