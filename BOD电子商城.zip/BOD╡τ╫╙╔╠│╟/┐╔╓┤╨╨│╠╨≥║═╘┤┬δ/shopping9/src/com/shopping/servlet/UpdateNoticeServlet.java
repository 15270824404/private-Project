package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.service.NoticeService;
import com.shopping.service.impl.NoticeServiceImpl;

public class UpdateNoticeServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String title = request.getParameter("title");
			String content = request.getParameter("content");
			int year1 = Integer.parseInt(request.getParameter("year1"));
			int year2 = Integer.parseInt(request.getParameter("year2"));
			int month1 = Integer.parseInt(request.getParameter("month1"));
			int month2 = Integer.parseInt(request.getParameter("month2"));
			int day1 = Integer.parseInt(request.getParameter("day1"));
			int day2 = Integer.parseInt(request.getParameter("day2"));
			String months1 = month1+"";
			String months2 = month2+"";
			String days1 = day1+"";
			String days2 = day2+"";
			int nid = Integer.parseInt(request.getParameter("nid"));
			if (month1<10){
				months1 = 0+months1;
			}
			if (day1<10){
				days1 = 0+days1;
			}
			if (month2<10){
				months2 = 0+months2;
			}
			if (day2<10){
				day2 = 0+day2;
			}
			String uptime = ""+year1+months1+days1;
			String deadtime =""+year2+months2+days2;

			
			NoticeService noticeService = new NoticeServiceImpl();
			if (nid == 0){
				noticeService.addNotice(title, content, uptime, deadtime);
			}else{
				noticeService.updateNotice(title, content, uptime, deadtime, Integer.parseInt(request.getParameter("nid")));
			}
			request.getRequestDispatcher("./showNotices.do").forward(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
