package com.shopping.util;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

public class JFreeChar {
	public static void main(String[] args) {
		// create a dataset...
		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("手机", 43.2);
		dataset.setValue("电视", 27.9);
		dataset.setValue("冰箱", 70.5);				
		dataset.setValue("1", 9.0);				
		// create a chart...
		JFreeChart chart = ChartFactory.createPieChart(
		"商城报表",
		dataset,
		true, // legend?
		true, // tooltips?
		false // URLs?		
		);
		// create and display a frame...
		ChartFrame frame = new ChartFrame("Test", chart);
		frame.pack();
		frame.setVisible(true);
	}

}
