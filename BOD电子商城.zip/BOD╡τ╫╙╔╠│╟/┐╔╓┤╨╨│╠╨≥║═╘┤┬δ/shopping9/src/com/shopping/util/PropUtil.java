package com.shopping.util;

import java.io.IOException;
import java.util.Properties;

public class PropUtil {
	public static Properties getProp(String path){
		Properties prop = new Properties();
		try {
			prop.load(PropUtil.class.getResourceAsStream(path));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prop;
	}
}
