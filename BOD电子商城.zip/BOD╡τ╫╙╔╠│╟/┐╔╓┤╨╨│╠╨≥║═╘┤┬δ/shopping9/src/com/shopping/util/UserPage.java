package com.shopping.util;

import java.util.List;

import com.shopping.dao.UserDao;
import com.shopping.dao.factory.UserDaoFactory;
import com.shopping.pojo.PageBean;
import com.shopping.pojo.User;

public class UserPage{
	private static UserDao userDao;
	static {
		userDao = UserDaoFactory.getInstance("daoConfig.properties","UserDao");
	}
	
	public static PageBean getPage(int currentPage){
		
		PageBean page = new PageBean();
		int length = PageBean.getLENGTH();
		//int userCount = users.size();
		int userCount = userDao.getUserCount();
		int totalPage = (userCount%length==0)? (userCount/length):(userCount/length)+1;
		page.setCurrentPage(currentPage);
		page.setTotalPage(totalPage);
		return page;
	}
	
	public static void changePageLength(int length){
		PageBean page = new PageBean();
		page.setLENGTH(length);
	}
	
	public static int getUserCount(){
		return userDao.getUserCount()-1;
	}
}
