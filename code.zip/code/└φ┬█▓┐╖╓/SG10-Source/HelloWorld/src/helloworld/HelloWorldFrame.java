package helloworld;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * <p>Title: Hello World</p>
 *
 * <p>Description: A simple Java Application</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Aptech Limited</p>
 *
 * @author Michael
 * @version 1.0
 */
public class HelloWorldFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * borderLayout1
     */
    BorderLayout borderLayout1 = new BorderLayout();

    /**
     * HelloWorldFrame
     */
    public HelloWorldFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setSize(new Dimension(400, 300));
        setTitle("Welcome to Hello World");
    }
}
