package layoutapplication;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.SwingConstants;

/**
 * <p>Title: Layout Application</p>
 *
 * <p>Description: Using the different layout</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Aptech</p>
 *
 * @author Michael
 * @version 1.0
 */
public class LayoutApplicationFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * borderLayout1
     */
    BorderLayout borderLayout1 = new BorderLayout();
    /**
     * gridLayout1
     */
    GridLayout gridLayout1 = new GridLayout();
    /**
     * btnNorth
     */
    JButton btnNorth = new JButton();
    /**
     * btnWest
     */
    JButton btnWest = new JButton();
    /**
     * btnSouth
     */
    JButton btnSouth = new JButton();
    /**
     * btnEast
     */
    JButton btnEast = new JButton();
    /**
     * pnlCenter
     */
    JPanel pnlCenter = new JPanel();
    /**
     * lblMessage
     */
    JLabel lblMessage = new JLabel();
    /**
     * txtMessage
     */
    JTextField txtMessage = new JTextField();
    /**
     * flowLayout1
     */
    FlowLayout flowLayout1 = new FlowLayout();

    /**
     * LayoutApplicationFrame
     */
    public LayoutApplicationFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setSize(new Dimension(400, 300));
        setTitle("��ӭʹ�ò��ֹ�����");
        btnNorth.setFont(new java.awt.Font("����", Font.PLAIN, 11));
        btnNorth.setText("��");
        btnNorth.addActionListener(
            new  LayoutApplicationFrame_btnNorth_actionAdapter(this));
        btnWest.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnWest.setText("��");
        btnWest.addActionListener(
            new LayoutApplicationFrame_btnWest_actionAdapter(this));
        btnSouth.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnSouth.setText("��");
        btnSouth.addActionListener(
            new LayoutApplicationFrame_btnSouth_actionAdapter(this));
        btnEast.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnEast.setText("��");
        btnEast.addActionListener(
            new LayoutApplicationFrame_btnEast_actionAdapter(this));
        pnlCenter.setFont(new java.awt.Font("", Font.PLAIN, 11));
        pnlCenter.setLayout(flowLayout1);
        lblMessage.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblMessage.setHorizontalAlignment(SwingConstants.CENTER);
        lblMessage.setText("��Ϣ:");
        txtMessage.setFont(new java.awt.Font("", Font.PLAIN, 11));
        txtMessage.setPreferredSize(new Dimension(150, 20));
        txtMessage.setText("");
        contentPane.add(btnWest, java.awt.BorderLayout.WEST);
        contentPane.add(btnSouth, java.awt.BorderLayout.SOUTH);
        contentPane.add(btnEast, java.awt.BorderLayout.EAST);
        contentPane.add(pnlCenter, java.awt.BorderLayout.CENTER);
        pnlCenter.add(lblMessage);
        pnlCenter.add(txtMessage);
        contentPane.add(btnNorth, java.awt.BorderLayout.NORTH);
    }

    /**
     * btnWest_actionPerformed
     * @param e ActionEvent
     */
    public void btnWest_actionPerformed(ActionEvent e) {
        txtMessage.setText("�㰴���˰�ť������");
    }

    /**
     * btnSouth_actionPerformed
     * @param e ActionEvent
     */
    public void btnSouth_actionPerformed(ActionEvent e) {
        txtMessage.setText("�㰴���˰�ť���ϡ�");
    }

    /**
     * btnEast_actionPerformed
     * @param e ActionEvent
     */
    public void btnEast_actionPerformed(ActionEvent e) {
        txtMessage.setText("�㰴���˰�ť������");
    }

    /**
     * btnNorth_actionPerformed
     * @param e ActionEvent
     */
    public void btnNorth_actionPerformed(ActionEvent e) {
        txtMessage.setText("�㰴���˰�ť������");
    }
}


/**
 * LayoutApplicationFrame_btnNorth_actionAdapter
 * <p>Title: Layout Application</p>  *
 * <p>Description: Using the different layout</p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: Aptech</p> *
 * @author not attributable
 * @version 1.0
 */
class LayoutApplicationFrame_btnNorth_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private LayoutApplicationFrame adaptee;
    /**
     *
     * @param adaptee LayoutApplicationFrame
     */
    LayoutApplicationFrame_btnNorth_actionAdapter(LayoutApplicationFrame
                                                  adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnNorth_actionPerformed(e);
    }
}


/**
 * LayoutApplicationFrame_btnEast_actionAdapter
 * <p>Title: Layout Application</p>  *
 * <p>Description: Using the different layout</p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: Aptech</p> *
 * @author not attributable
 * @version 1.0
 */
class LayoutApplicationFrame_btnEast_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private LayoutApplicationFrame adaptee;
    /**
     * LayoutApplicationFrame_btnEast_actionAdapter
     * @param adaptee LayoutApplicationFrame
     */
    LayoutApplicationFrame_btnEast_actionAdapter(
            LayoutApplicationFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnEast_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: Layout Application</p>
 *
 * <p>Description: Using the different layout</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Aptech</p>
 *
 * @author not attributable
 * @version 1.0
 */
class LayoutApplicationFrame_btnSouth_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private LayoutApplicationFrame adaptee;
    /**
     *
     * @param adaptee LayoutApplicationFrame
     */
    LayoutApplicationFrame_btnSouth_actionAdapter(LayoutApplicationFrame
                                                  adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnSouth_actionPerformed(e);
    }
}


/**
 * LayoutApplicationFrame_btnWest_actionAdapter
 * <p>Title: Layout Application</p>  *
 * <p>Description: Using the different layout</p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: Aptech</p> *
 * @author not attributable
 * @version 1.0
 */
class LayoutApplicationFrame_btnWest_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private LayoutApplicationFrame adaptee;
    /**
     * LayoutApplicationFrame_btnWest_actionAdapter
     * @param adaptee LayoutApplicationFrame
     */
    LayoutApplicationFrame_btnWest_actionAdapter(
            LayoutApplicationFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnWest_actionPerformed(e);
    }
}


