package studentapplication;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.border.Border;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Rectangle;
import javax.swing.SwingConstants;


/**
 * <p>Title: Application Form</p>
 *
 * <p>Description: Student Application Form</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Aptech</p>
 *
 * @author Michael
 * @version 1.0
 */
public class StudentApplicationFrameClass extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * objMessage
     */
    StringBuffer objMessage = new StringBuffer("");
    /**
     * lblName
     */
    JLabel lblName = new JLabel();
    /**
     * lblAddress
     */
    JLabel lblAddress = new JLabel();
    /**
     * txtName
     */
    JTextField txtName = new JTextField();
    /**
     * txaAddress
     */
    JTextArea txaAddress = new JTextArea();
    /**
     * lblQualification
     */
    JLabel lblQualification = new JLabel();
    /**
     * cboQualification
     */
    JComboBox cboQualification = new JComboBox();
    /**
     * lblHobby
     */
    JLabel lblHobby = new JLabel();
    /**
     * chkSinging
     */
    JCheckBox chkSinging = new JCheckBox();
    /**
     * chkReading
     */
    JCheckBox chkReading = new JCheckBox();
    /**
     * chkDancing
     */
    JCheckBox chkDancing = new JCheckBox();
    /**
     * btngrpSex
     */
    ButtonGroup btngrpSex = new ButtonGroup();
    /**
     * lblSex
     */
    JLabel lblSex = new JLabel();
    /**
     * radMale
     */
    JRadioButton radMale = new JRadioButton();
    /**
     * radFemale
     */
    JRadioButton radFemale = new JRadioButton();
    /**
     * pnlSex
     */
    JPanel pnlSex = new JPanel();
    /**
     * border1
     */
    Border border1 = BorderFactory.createLineBorder(Color.black, 2);
    /**
     * border2
     */
    Border border2 = BorderFactory.createLineBorder(Color.black, 2);
    /**
     * border3
     */
    Border border3 = BorderFactory.createLineBorder(Color.lightGray, 2);
    /**
     * pnlHobby
     */
    JPanel pnlHobby = new JPanel();
    /**
     * border4
     */
    Border border4 = BorderFactory.createEtchedBorder(
            Color.white, new Color(148, 145, 140));
    /**
     * btnValidate
     */
    JButton btnValidate = new JButton();
    /**
     * btnReset
     */
    JButton btnReset = new JButton();
    /**
     * lblDisplay
     */
    JLabel lblDisplay = new JLabel();
    /**
     * StudentApplicationFrameClass
     */
    public StudentApplicationFrameClass() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(420, 328));
        setTitle("ѧ����ϸ��Ϣ");
        lblName.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblName.setText("����:");
        lblName.setBounds(new Rectangle(23, 31, 56, 21));
        lblAddress.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblAddress.setText("��ַ:");
        lblAddress.setBounds(new Rectangle(23, 77, 54, 23));
        txtName.setFont(new java.awt.Font("", Font.PLAIN, 11));
        txtName.setText("");
        txtName.setBounds(new Rectangle(88, 28, 94, 28));
        txaAddress.setFont(new java.awt.Font("", Font.PLAIN, 11));
        txaAddress.setText("");
        txaAddress.setLineWrap(true);
        txaAddress.setWrapStyleWord(true);
        txaAddress.setBounds(new Rectangle(88, 75, 99, 61));
        lblQualification.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblQualification.setText("����:");
        lblQualification.setBounds(new Rectangle(197, 27, 70, 26));
        cboQualification.setBounds(new Rectangle(271, 28, 97, 24));
        lblHobby.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblHobby.setText("��Ȥ:");
        lblHobby.setBounds(new Rectangle(197, 75, 62, 22));
        chkSinging.setFont(new java.awt.Font("", Font.PLAIN, 11));
        chkSinging.setText("����");
        chkSinging.setBounds(new Rectangle(8, 30, 94, 22));

        chkReading.setFont(new java.awt.Font("", Font.PLAIN, 11));
        chkReading.setText("�Ķ�");
        chkReading.setBounds(new Rectangle(8, 5, 83, 23));

        chkDancing.setFont(new java.awt.Font("", Font.PLAIN, 11));
        chkDancing.setText("����");
        chkDancing.setBounds(new Rectangle(8, 58, 83, 23));
        lblSex.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblSex.setText("�Ա�:");
        lblSex.setBounds(new Rectangle(23, 162, 53, 23));
        radMale.setFont(new java.awt.Font("", Font.PLAIN, 11));
        radMale.setSelected(true);
        radMale.setText("��");
        radMale.setBounds(new Rectangle(5, 7, 47, 23));
        radFemale.setFont(new java.awt.Font("", Font.PLAIN, 11));
        radFemale.setText("Ů");
        radFemale.setBounds(new Rectangle(6, 32, 59, 23));
        pnlSex.setBorder(BorderFactory.createEtchedBorder());
        pnlSex.setBounds(new Rectangle(88, 164, 89, 60));
        pnlSex.setLayout(null);
        pnlHobby.setBorder(border4);
        pnlHobby.setBounds(new Rectangle(271, 75, 106, 87));
        pnlHobby.setLayout(null);
        btnValidate.setBounds(new Rectangle(142, 257, 84, 35));
        btnValidate.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnValidate.setText("��֤");
        btnValidate.addActionListener(
            new  StudentApplicationFrameClass_btnValidate_actionAdapter(this));
        btnReset.setBounds(new Rectangle(247, 258, 81, 34));
        btnReset.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnReset.setText("����");
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnReset_actionPerformed(e);
            }
        });

        lblDisplay.setFont(new java.awt.Font("", Font.BOLD | Font.ITALIC,
                                             11));
        lblDisplay.setForeground(Color.red);
        lblDisplay.setHorizontalAlignment(SwingConstants.CENTER);
        lblDisplay.setBounds(new Rectangle(181, 189, 218, 31));
        btngrpSex.add(radMale);
        btngrpSex.add(radFemale);
        cboQualification.addItem("������");
        cboQualification.addItem("�о���");
        cboQualification.addItem("����ʦ");
        cboQualification.addItem("��ʿ");
        cboQualification.addItem("����");
        contentPane.add(txtName);
        contentPane.add(txaAddress);
        contentPane.add(lblName);
        contentPane.add(lblAddress);
        contentPane.add(pnlSex);
        pnlSex.add(radMale);
        pnlSex.add(radFemale);
        contentPane.add(lblSex);
        pnlHobby.add(chkReading);
        pnlHobby.add(chkDancing);
        pnlHobby.add(chkSinging);
        contentPane.add(lblDisplay);
        contentPane.add(lblHobby);
        contentPane.add(btnValidate);
        contentPane.add(btnReset);
        contentPane.add(lblQualification);
        contentPane.add(cboQualification);
        contentPane.add(pnlHobby);
    }

    /**
     * btnValidate_actionPerformed
     * @param e ActionEvent
     */
    public void btnValidate_actionPerformed(ActionEvent e) {
        String name = txtName.getText();
        String address = txaAddress.getText();

        if (name.length() == 0) {
            objMessage = objMessage.append("����");
        }
        if (address.length() == 0) {
            objMessage = objMessage.append("��ַδ����");
        }
        lblDisplay.setText("");
        lblDisplay.setText(objMessage.toString());
    }

    /**
     * btnReset_actionPerformed
     * @param e ActionEvent
     */
    public void btnReset_actionPerformed(ActionEvent e) {
        txtName.setText("");
        txaAddress.setText("");
        cboQualification.setSelectedIndex(0);
        chkReading.setSelected(false);
        chkSinging.setSelected(false);
        chkDancing.setSelected(false);
    }


}


/**
 * StudentApplicationFrameClass_btnValidate_actionAdapter
 * <p>Title: Application Form</p>  *
 * <p>Description: Student Application Form</p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: Aptech</p> *
 * @author Michael
 * @version 1.0
 */
class StudentApplicationFrameClass_btnValidate_actionAdapter implements
        ActionListener {
    /**
     * adaptee
     */
    private StudentApplicationFrameClass adaptee;
    /**
     * StudentApplicationFrameClass_btnValidate_actionAdapter
     * @param adaptee StudentApplicationFrameClass
     */
    StudentApplicationFrameClass_btnValidate_actionAdapter(
            StudentApplicationFrameClass adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnValidate_actionPerformed(e);
    }
}


