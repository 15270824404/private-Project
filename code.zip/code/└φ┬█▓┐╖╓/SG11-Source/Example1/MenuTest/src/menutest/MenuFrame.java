package menutest;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JCheckBoxMenuItem;



/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class MenuFrame extends JFrame {
        /**
         *
         */
        JPanel contentPane;
        /**
     * mnuNotepad
     */
    JMenuBar mnuNotepad = new JMenuBar();

    /**
     * mnuFile
     */
    JMenu mnuFile = new JMenu();
    /**
     *
     */
    JMenu mnuEdit = new JMenu();
    /**
     *
     */
    JMenu mnuFormat = new JMenu();
    /**
     *
     */
    JMenuItem mnuOpen = new JMenuItem();
    /**
     *
     */
    JMenuItem mnuSave = new JMenuItem();
    /**
     *
     */
    JMenuItem mnuSaveAs = new JMenuItem();
    /**
     *
     */
    JMenuItem mnuExit = new JMenuItem();
    /**
     *
     */
    JMenu mnuHelp = new JMenu();
    /**
     *
     */
    JRadioButtonMenuItem jRadioButtonMenuItem1 = new JRadioButtonMenuItem();
    /**
     *
     */
    JMenuItem mnuNew = new JMenuItem();
    /**
     *
     */
    JMenu mnuFont = new JMenu();
    /**
     *
     */
    JRadioButtonMenuItem mnuBold = new JRadioButtonMenuItem();
    /**
     *
     */
    JRadioButtonMenuItem mnuItalics = new JRadioButtonMenuItem();
    /**
     *
     */
    JMenuItem mnuParagraph = new JMenuItem();
    /**
     *
     */
    JMenuItem mnuBulletsandNumbering = new JMenuItem();
    /**
     *
     */
    JMenu mnuBackground = new JMenu();
    /**
     *
     */
    JCheckBoxMenuItem mnuRed = new JCheckBoxMenuItem();
    /**
     *
     */
    JCheckBoxMenuItem mnuGreen = new JCheckBoxMenuItem();
    /**
     *
     */
    JCheckBoxMenuItem mnuBlack = new JCheckBoxMenuItem();
    /**
     * mnuRegular
     */
    JRadioButtonMenuItem mnuRegular = new JRadioButtonMenuItem();

    /**
     *
     */
    public MenuFrame() {
    try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        this.setJMenuBar(mnuNotepad);
        setSize(new Dimension(400, 300));
        setTitle("�˵�");
        mnuFile.setText("�ļ�");
        mnuEdit.setText("�༭");
        mnuFormat.setText("��ʽ");
        mnuOpen.setText("��...");
        mnuSave.setText("����");
        mnuSaveAs.setText("����Ϊ...");
        mnuExit.setText("�˳�");
        mnuHelp.setText("����");
        jRadioButtonMenuItem1.setText("�½�");
        mnuNew.setText("�½�");
        mnuFont.setText("����");
        mnuBold.setText("����");
        mnuItalics.setText("б��");
        mnuParagraph.setText("����");
        mnuBulletsandNumbering.setText("��Ŀ�б��ͱ��");
        mnuBackground.setText("����");
        mnuRed.setText("��ɫ");
        mnuGreen.setText("��ɫ");
        mnuBlack.setText("��ɫ");
        mnuRegular.setText("��ͨ");
        mnuNotepad.add(mnuFile);
        mnuNotepad.add(mnuEdit);
        mnuNotepad.add(mnuFormat);
        mnuNotepad.add(mnuHelp);
        mnuFile.add(mnuNew);
        mnuFile.add(mnuOpen);
        mnuFile.add(mnuSave);
        mnuFile.add(mnuSaveAs);
        mnuFile.add(mnuExit);
        mnuFormat.add(mnuFont);
        mnuFormat.add(mnuParagraph);
        mnuFormat.add(mnuBulletsandNumbering);
        mnuFormat.addSeparator();
        mnuFormat.add(mnuBackground);
        mnuFont.add(mnuBold);
        mnuFont.add(mnuItalics);
        mnuFont.add(mnuRegular);
        mnuBackground.add(mnuRed);
        mnuBackground.add(mnuGreen);
        mnuBackground.add(mnuBlack);

    }
}
