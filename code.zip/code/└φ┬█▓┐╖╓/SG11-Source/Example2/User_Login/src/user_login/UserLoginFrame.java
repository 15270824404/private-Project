package user_login;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Color;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class UserLoginFrame extends JFrame {
    /**
     * panel
     */
    JPanel contentPane;
    /**
     * username
     */
    JTextField txtUserName = new JTextField();
    /**
     * btnok
     */
    JButton btnOk = new JButton();
    /**
     * username
     */
    JLabel lblUserName = new JLabel();
    /**
     * password
     */
    JTextField txtPassword = new JTextField();
    /**
     * cancel
     */
    JButton btnCancel = new JButton();
    /**
     * password
     */
    JLabel lblPassword = new JLabel();
    /**
     * result
     */
    JLabel lblresult = new JLabel();
    /**
     * message
     */
    JOptionPane dlgMessage = new JOptionPane();
    /**
     * ���췽��
     */
    public UserLoginFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(400, 300));
        setTitle("��¼");
        txtUserName.setFont(new java.awt.Font("", Font.PLAIN, 11));
        txtUserName.setBounds(new Rectangle(141, 56, 81, 25));
        btnOk.setBounds(new Rectangle(18, 132, 70, 39));
        btnOk.setText("ȷ��");
        btnOk.addActionListener(new
                                UserLoginFrame_jButton1_actionAdapter(this));
        lblUserName.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblUserName.setText("�û���");
        lblUserName.setBounds(new Rectangle(21, 46, 105, 49));
        txtPassword.setFont(new java.awt.Font("", Font.PLAIN, 11));
        txtPassword.setBounds(new Rectangle(141, 96, 78, 23));
        btnCancel.setBounds(new Rectangle(107, 131, 70, 39));
        btnCancel.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnCancel.setText("ȡ��");
        btnCancel.addActionListener(
            new UserLoginFrame_btnCancel_actionAdapter(this));
        lblPassword.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblPassword.setText("����");
        lblPassword.setBounds(new Rectangle(17, 98, 112, 33));
        lblresult.setFont(new java.awt.Font("", Font.PLAIN, 20));
        lblresult.setForeground(Color.red);
        lblresult.setText("");
        lblresult.setBounds(new Rectangle(20, 12, 289, 29));

        dlgMessage.setBounds(new Rectangle(23, 192, 184, 58));
        contentPane.add(lblresult);
        contentPane.add(lblUserName);
        contentPane.add(txtUserName);
        contentPane.add(lblPassword);
        contentPane.add(txtPassword);
        contentPane.add(btnOk);
        contentPane.add(btnCancel);
        contentPane.add(btnOk);
        /**
         * Font
         */
        btnOk.setFont(new java.awt.Font("", Font.PLAIN, 11));
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnOk_actionPerformed(ActionEvent e) {
        String user;
        String password;
        user = txtUserName.getText();
        password = txtPassword.getText();
        if (user.equals("admin") && password.equals("aptech")) {
            dlgMessage.showMessageDialog(this, "��Ȩ�û�", "����֤�û�",
                                         JOptionPane.INFORMATION_MESSAGE);

        } else {

            dlgMessage.showMessageDialog(this, "�Ƿ��û���������", "�Ƿ��û�",
                                         JOptionPane.ERROR_MESSAGE);
            txtUserName.setText("");
            txtPassword.setText("");
            txtUserName.setFocusable(true);
        }

    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnCancel_actionPerformed(ActionEvent e) {
        System.exit(0);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class UserLoginFrame_btnCancel_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private UserLoginFrame adaptee;
    /**
     *
     * @param adaptee UserLoginFrame
     */
    UserLoginFrame_btnCancel_actionAdapter(UserLoginFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnCancel_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class UserLoginFrame_jButton1_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private UserLoginFrame adaptee;
    /**
     *
     * @param adaptee UserLoginFrame
     */
    UserLoginFrame_jButton1_actionAdapter(UserLoginFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnOk_actionPerformed(e);
    }
}
