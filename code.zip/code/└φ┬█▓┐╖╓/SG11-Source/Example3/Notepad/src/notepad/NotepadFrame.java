package notepad;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;



/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class NotepadFrame extends JFrame {
        /**
         * panel
         */
        JPanel contentPane;
        /**
         * layout
         */
        BorderLayout borderLayout1 = new BorderLayout();
        /**
         * notepade
         */
        JMenuBar mnuNotepad = new JMenuBar();
        /**
         * file
         */
        JFileChooser fcFile = new JFileChooser();
        /**
         * file
         */
        JMenu mnuFile = new JMenu();
        /**
         * menu
         */
        JMenuItem mnuOpen = new JMenuItem();
        /**
         * Textarea
         */
        JTextArea txaDisplay = new JTextArea();

        /**
         * ���췽��
         */
        public NotepadFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setTitle("Notepad");
        setSize(new Dimension(400, 300));
        mnuFile.setText("File");
        mnuOpen.setText("Open");
        mnuOpen.addActionListener(new NotepadFrame_mnuOpen_actionAdapter(this));
        txaDisplay.setText("");
        mnuNotepad.add(mnuFile);
        mnuFile.add(mnuOpen);
        contentPane.add(txaDisplay, java.awt.BorderLayout.CENTER);

        setJMenuBar(mnuNotepad);
    }

    /**
     * File | Exit action performed.
     *
     * @param actionEvent ActionEvent
     */
    void jMenuFileExit_actionPerformed(ActionEvent actionEvent) {
            /**
             * exit
             */
            System.exit(0);
            }

            /**
             *
             * @param e ActionEvent
             */
            public void mnuOpen_actionPerformed(ActionEvent e) {
            fcFile.showOpenDialog(this);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class NotepadFrame_mnuOpen_actionAdapter implements ActionListener {
        /**
         * adaptee
         */
        private NotepadFrame adaptee;
        /**
         *
         * @param adaptee NotepadFrame
         */
        NotepadFrame_mnuOpen_actionAdapter(NotepadFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
    adaptee.mnuOpen_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class NotepadFrame_jMenuFileExit_ActionAdapter implements ActionListener {
        /**
         * adaptee
         */
        NotepadFrame adaptee;

    /**
     *
     * @param adaptee NotepadFrame
     */
    NotepadFrame_jMenuFileExit_ActionAdapter(NotepadFrame adaptee) {
    this.adaptee = adaptee;
    }

    /**
     *
     * @param actionEvent ActionEvent
     */
    public void actionPerformed(ActionEvent actionEvent) {
    adaptee.jMenuFileExit_actionPerformed(actionEvent);
    }
}
