package notepad;

import java.awt.Frame;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JButton;

import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Rectangle;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class AboutUs extends JDialog {
        /**
         * icon
         */
        ImageIcon icon = new ImageIcon("c:/icon.gif");
        /**
     * panel
     */
    JPanel pnlContainer = new JPanel();
    /**
     * label
     */
    JLabel lblInformation = new JLabel();
    /**
     * button
     */
    JButton btnOk = new JButton();
    /**
     * label
     */
    JLabel lblCopyright = new JLabel();
    /**
     * label
     */
    JLabel lblImage = new JLabel("", icon, JLabel.CENTER);
    /**
     *
     * @param owner Frame
     * @param title String
     * @param modal boolean
     */
    public AboutUs(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * ���췽��
     */
    public AboutUs() {
        this(new Frame(), "��������", false);
    }

    /**
     *
     * @throws Exception e
     */
    private void jbInit() throws Exception {
        pnlContainer.setLayout(null);
        lblInformation.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblInformation.setText(
                "����Ʒʹ��Ȩ���� Aptech ���������");
        lblInformation.setBounds(new Rectangle(12, 166, 292, 45));
        btnOk.setBounds(new Rectangle(257, 205, 59, 29));
        btnOk.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnOk.setActionCommand("ȷ��");
        btnOk.setText("ȷ��");
        btnOk.addActionListener(new AboutUs_btnOk_actionAdapter(this));
        lblCopyright.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblCopyright.setIcon(null);
        lblCopyright.setText("Aptech �汾 1.0 ��Ȩ���� (c) 2005");
        lblCopyright.setBounds(new Rectangle(155, 18, 209, 121));
        pnlContainer.setFont(new java.awt.Font("", Font.PLAIN, 11));
        lblImage.setDisplayedMnemonic('0');
        lblImage.setBounds(new Rectangle(1, 29, 150, 91));
        getContentPane().add(pnlContainer);
        pnlContainer.add(lblImage);
        pnlContainer.add(lblInformation);
        pnlContainer.add(lblCopyright);
        pnlContainer.add(btnOk);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnOk_actionPerformed(ActionEvent e) {
        this.dispose();
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class AboutUs_btnOk_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private AboutUs adaptee;
    /**
     *
     * @param adaptee AboutUs
     */
    AboutUs_btnOk_actionAdapter(AboutUs adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnOk_actionPerformed(e);
    }
}
