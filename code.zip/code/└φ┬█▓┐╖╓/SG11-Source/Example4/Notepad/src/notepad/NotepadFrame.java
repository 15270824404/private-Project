package notepad;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import java.awt.Point;




/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class NotepadFrame extends JFrame {
        /**
         * panel
         */
        JPanel contentPane;
        /**
     * layout
     */
    BorderLayout borderLayout1 = new BorderLayout();
    /**
     * menubar
     */
    JMenuBar mnuNotepad = new JMenuBar();
    /**
     * file
     */
    JFileChooser fcFile = new JFileChooser();
    /**
     * menu
     */
    JMenu mnuFile = new JMenu();
    /**
     * menu
     */
    JMenuItem mnuOpen = new JMenuItem();
    /**
     * textarea
     */
    JTextArea txaDisplay = new JTextArea();
    /**
     * menu
     */
    JMenu mnuHelp = new JMenu();
    /**
     * menu
     */
    JMenuItem mnuAboutUs = new JMenuItem();

    /**
     * ���췽��
     */
    public NotepadFrame() {
    try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setTitle("���±�");
        setSize(new Dimension(600, 500));
        mnuFile.setText("�ļ�");
        mnuOpen.setText("��");
        mnuOpen.addActionListener(new NotepadFrame_mnuOpen_actionAdapter(this));
        txaDisplay.setText("");
        mnuHelp.setText("����");
        mnuAboutUs.setText("��������");
        mnuAboutUs.addActionListener(
            new NotepadFrame_mnuAboutUs_actionAdapter(this));
        mnuNotepad.add(mnuFile);
        mnuNotepad.add(mnuHelp);
        mnuFile.add(mnuOpen);
        contentPane.add(txaDisplay, java.awt.BorderLayout.CENTER);
        mnuHelp.add(mnuAboutUs);
        setJMenuBar(mnuNotepad);
    }

    /**
     * File | Exit action performed.
     *
     * @param actionEvent ActionEvent
     */
    void jMenuFileExit_actionPerformed(ActionEvent actionEvent) {
        System.exit(0);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void mnuOpen_actionPerformed(ActionEvent e) {
    fcFile.showOpenDialog(this);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void mnuAboutUs_actionPerformed(ActionEvent e) {
    AboutUs dlgAboutUs = new AboutUs(this, "��������", true);
        dlgAboutUs.setSize(350, 300);
        Dimension dlgSize = dlgAboutUs.getPreferredSize();
        Dimension frmSize = getSize();
        Point loc = getLocation();
        dlgAboutUs.setLocation((frmSize.width - dlgSize.width) / 4 + loc.x,
                               (frmSize.height - dlgSize.height) / 4 + loc.y);
        dlgAboutUs.setModal(true);
        dlgAboutUs.show();

    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class NotepadFrame_mnuAboutUs_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private NotepadFrame adaptee;
    /**
     *
     * @param adaptee NotepadFrame
     */
    NotepadFrame_mnuAboutUs_actionAdapter(NotepadFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuAboutUs_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class NotepadFrame_mnuOpen_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private NotepadFrame adaptee;
    /**
     *
     * @param adaptee NotepadFrame
     */
    NotepadFrame_mnuOpen_actionAdapter(NotepadFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuOpen_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class NotepadFrame_jMenuFileExit_ActionAdapter implements ActionListener {
    /**
     * adaptee
     */
    NotepadFrame adaptee;

    /**
     *
     * @param adaptee NotepadFrame
     */
    NotepadFrame_jMenuFileExit_ActionAdapter(NotepadFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param actionEvent ActionEvent
     */
    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.jMenuFileExit_actionPerformed(actionEvent);
    }
}
