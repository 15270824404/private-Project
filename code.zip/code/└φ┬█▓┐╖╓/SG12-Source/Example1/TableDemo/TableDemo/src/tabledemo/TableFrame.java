package tabledemo;


import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;

import javax.swing.table.JTableHeader;
import java.awt.Color;
import java.awt.Rectangle;

/**
 *
 * <p>Title: JTable Demo</p>
 *
 * <p>Description: Program to demonstrate JTable</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Aptech Limited</p>
 *
 * @author Ben
 * @version 1.0
 */
public class TableFrame extends JFrame {
    /**
     * panel
     */
    JPanel contentPane;
    /**
     * cells
     */
    Object[][] cells = {{"ACJTP", new Integer(01), new Integer(400)}, {"ACEP",
                       new Integer(02), new Integer(500)}, {"eACCP",
                       new Integer(03),
                       new Integer(700)},
    };

    /**
     * colnames
     */
    String[] colnames = {"�γ�����", "�γ̴���", "ѧ��(Ԫ)"};

    /**
     * table
     */
    JTable jTable1 = new JTable(cells, colnames);
    /**
     * table
     */
    JTableHeader jTableHeader1 = jTable1.getTableHeader();
    /**
     * ���췽��
     */
    public TableFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(400, 300));
        setTitle("��ӭʹ�� JTable");
        jTable1.setBackground(Color.yellow);
        jTable1.setBorder(null);
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable1.setCellSelectionEnabled(false);
        jTable1.setColumnSelectionAllowed(true);
        jTable1.setGridColor(Color.black);
        jTable1.setSelectionBackground(Color.orange);
        jTable1.setBounds(new Rectangle(11, 29, 251, 161));
        jTableHeader1.setBackground(Color.pink);
        jTableHeader1.setBounds(new Rectangle(10, 10, 252, 20));
        contentPane.setAlignmentX((float) 0.0);
        contentPane.setAlignmentY((float) 0.0);
        contentPane.setRequestFocusEnabled(false);
        contentPane.setVerifyInputWhenFocusTarget(false);
        contentPane.add(jTableHeader1);
        contentPane.add(jTable1);
    }
}
