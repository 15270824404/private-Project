package selectingtree;


import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTree;


import javax.swing.JTextField;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.JLabel;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.Rectangle;
import java.awt.Font;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class TreeFrame extends JFrame {
    /**
     * panel
     */
    JPanel contentPane;
    /**
     * textfield
     */
    JTextField txtName = new JTextField();
    /**
     * tree
     */
    JTree jTree2;

    /**
     * label
     */
    JLabel lblName = new JLabel();
    /**
     * label
     */
    JLabel lblType = new JLabel();
    /**
     * textfield
     */
    JTextField txtType = new JTextField();
    /**
     * label
     */
    JLabel lblNumber = new JLabel();
    /**
     * textfield
     */
    JTextField txtNumber = new JTextField();
    /**
     * label
     */
    JLabel lblNode = new JLabel();
    /**
     * textfield
     */
    JTextField txtNode = new JTextField();
    /**
     * ���췽��
     */
    public TreeFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(450, 350));
        setTitle("Welcome to JTree");
        // Creating Root node
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("���ڵ�");
        // Creating Parent node
        DefaultMutableTreeNode parent = new DefaultMutableTreeNode("�鼮");
        lblNode.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        lblNode.setText("Node Name:");
        lblNode.setBounds(new Rectangle(202, 115, 59, 14));
        txtNode.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        txtNode.setText("");
        txtNode.setBounds(new Rectangle(322, 112, 117, 20));
        txtName.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        contentPane.setMaximumSize(new Dimension(600, 400));
        contentPane.setPreferredSize(new Dimension(600, 400));
        root.add(parent);
        // Creating Leaf nodes
        DefaultMutableTreeNode java = new DefaultMutableTreeNode("Java");
        parent.add(java);
        DefaultMutableTreeNode complete = new DefaultMutableTreeNode(
                "Complete Reference");
        java.add(complete);
        DefaultMutableTreeNode professional = new DefaultMutableTreeNode(
                "Java Programming");
        java.add(professional);
        DefaultMutableTreeNode advanced = new DefaultMutableTreeNode(
                "Advanced Java Programming");
        java.add(advanced);

        DefaultMutableTreeNode oracle = new DefaultMutableTreeNode("Oracle");
        parent.add(oracle);
        DefaultMutableTreeNode learn = new DefaultMutableTreeNode(
                "Learning Oracle");
        oracle.add(learn);
        DefaultMutableTreeNode sql = new DefaultMutableTreeNode("Learning SQL");
        oracle.add(sql);
        DefaultMutableTreeNode plsql = new DefaultMutableTreeNode(
                "Learning SQL/PLSQL");
        oracle.add(learn);
        DefaultMutableTreeNode program = new DefaultMutableTreeNode(
                "Learning Programming");
        oracle.add(program);

        DefaultMutableTreeNode jsp = new DefaultMutableTreeNode("JSP");
        parent.add(jsp);
        DefaultMutableTreeNode jsp1 =
                new DefaultMutableTreeNode("Learning JSP");
        jsp.add(jsp1);
        DefaultMutableTreeNode jsp2 = new DefaultMutableTreeNode(
                "Programming In JSP");
        jsp.add(jsp2);

        DefaultMutableTreeNode leaf = new DefaultMutableTreeNode("C#");
        parent.add(leaf);
        DefaultMutableTreeNode programming = new DefaultMutableTreeNode(
                "Programming In C#");
        leaf.add(programming);

        // Creating another Branch node
        parent = new DefaultMutableTreeNode("����");
        root.add(parent);

        // Creating Leaf nodes
        leaf = new DefaultMutableTreeNode("Operating System");
        parent.add(leaf);
        DefaultMutableTreeNode dosObj = new DefaultMutableTreeNode("MS-DOS");
        leaf.add(dosObj);
        DefaultMutableTreeNode windowsObj = new DefaultMutableTreeNode(
                "Windows 2000 Server");
        leaf.add(windowsObj);
        DefaultMutableTreeNode winObj = new DefaultMutableTreeNode(
                "Windows 2000 Professional");
        leaf.add(winObj);

        leaf = new DefaultMutableTreeNode("Database");
        parent.add(leaf);
        DefaultMutableTreeNode accessObj = new DefaultMutableTreeNode(
                "MS-Access");
        leaf.add(accessObj);
        DefaultMutableTreeNode mssqlObj = new DefaultMutableTreeNode(
                "MS-SQL Server");
        leaf.add(mssqlObj);

        jTree2 = new JTree(root);

        txtName.setText("");
        txtName.setBounds(new Rectangle(322, 64, 115, 21));
        jTree2.setBounds(new
                         Rectangle(5, 6, 188, 276));
        jTree2.addTreeSelectionListener(
                new Frame1_jTree2_treeSelectionAdapter(this));
        lblName.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        lblName.setText("Parent Name:");
        lblName.setBounds(new Rectangle(201, 67, 66, 14));
        lblType.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        lblType.setText("Type of Node:");
        lblType.setBounds(new Rectangle(200, 162, 69, 14));
        txtType.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        txtType.setText("");
        txtType.setBounds(new Rectangle(322, 159, 104, 20));
        lblNumber.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        lblNumber.setText("Number of Child Nodes:");
        lblNumber.setBounds(new Rectangle(199, 210, 113, 14));
        txtNumber.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        txtNumber.setText("");
        txtNumber.setBounds(new Rectangle(322, 207, 78, 19));
        contentPane.add(jTree2);
        contentPane.add(lblNumber);
        contentPane.add(lblName);
        contentPane.add(txtName);
        contentPane.add(txtNode);
        contentPane.add(lblNode);
        contentPane.add(lblType);
        contentPane.add(txtType);
        contentPane.add(txtNumber);
    }

    /**
     *
     * @param e TreeSelectionEvent
     */
    public void jTree2_valueChanged(TreeSelectionEvent e) {
        try {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) jTree2.
                                          getLastSelectedPathComponent();
            String name = "";
            Object nodeInfo = node.getUserObject();
            if (node.isRoot()) {
                txtName.setText("");
                txtNode.setText(nodeInfo.toString());
                txtType.setText("Root");
                txtNumber.setText("" + node.getChildCount());
            } else {
                name = node.getParent().toString();
                txtName.setText(name);
                txtNode.setText(nodeInfo.toString());
                if (node.isLeaf()) {
                    txtType.setText("Leaf");
                } else {
                    txtType.setText("Parent");
                }
                int number = node.getChildCount();
                txtNumber.setText("" + number);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Dscription: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
class Frame1_jTree2_treeSelectionAdapter implements TreeSelectionListener {
    /**
     * adaptee
     */
    private TreeFrame adaptee;
    /**
     *
     * @param adaptee TreeFrame
     */
    Frame1_jTree2_treeSelectionAdapter(TreeFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e TreeSelectionEvent
     */
    public void valueChanged(TreeSelectionEvent e) {
        adaptee.jTree2_valueChanged(e);
    }
}
