/** (c) ��������APTECH
 * ��Ȩ����
 */

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

/** �������ʾ���� ResultSet ���÷�.
 * @version 1.0, 2005 �� 8�� 26 ��
 * @author Ben
 */

class JdbctestReverse {

  /** 
   * *���췽��. 
   */
  protected JdbctestReverse() {
  }

  /** ���� main ����.
        /** ����ʾ���� ResultSet ���÷�.
    * @param args �������� main ����
    */

   public static void main(String[] args) {
     try {
       Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
     }
     catch (ClassNotFoundException ce) {
       System.out.println(ce);
     }
     try {
       String url = "jdbc:odbc:test";
       Connection con = DriverManager.getConnection(url);
       Statement s = con.createStatement(
           ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
       ResultSet rs = s.executeQuery("select * from friends");
       rs.afterLast();
       while (rs.previous()) {
         System.out.print(rs.getString(1) + "\t");
         System.out.print(rs.getString(2) + "\t");
         System.out.print(rs.getInt(3) + "\t");
         System.out.print(rs.getDate(4) + "\t");
         System.out.println(" ");
       }
    

      rs.close();
      s.close();
      con.close();
    }
     catch (SQLException ce) {
       System.out.println(ce);
     }
   }
}
