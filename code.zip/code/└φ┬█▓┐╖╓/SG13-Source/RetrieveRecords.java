/** (c)��������APTECH
 * All Rights Reserved
 */

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

/** This class demonstrates the usage of PreparedStatement in an SQL query
 * based upon a condition.
 * @version 1.0 26 August 2005
 * @author Ben
 */

class RetrieveRecords {
  /** represents connection with database. */
  private Connection con;
  /** represents the SQLServer path. */
  private String url;
  /** represents the machine name. */
  private String serverName;
  /** stores the port number. */
  private String portNumber;
  /** stores the database name. */
  private String databaseName;
  /** stores the user name. */
  private String userName;
  /** stores the password. */
  private String password;
  /** stores the sql query statement. */
  private String sql;

  /** Constructor. */

  RetrieveRecords() {
    url = "jdbc:microsoft:sqlserver://";
    serverName = "localhost";
    portNumber = "1433";
    databaseName = "test";
    userName = "sa";
    password = "sa";
  }

  /** @return Url, Server name, Port number and Database name. */

  private String getConnectionUrl() {
    //constructing the connection string
    return url + serverName + ":" + portNumber + ";databaseName="
        + databaseName + ";";
  }

  /** @return the Connection status. */

  private java.sql.Connection getConnection() {
    try {
      Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
      //establishing the connection
      con = DriverManager.getConnection(
          getConnectionUrl(), userName, password);

      if (con != null) {
        System.out.println("Connection Successful!");
      }
    }
    catch (Exception e) {
      e.printStackTrace();
      System.out.println("Error Trace in getConnection() : "
                         + e.getMessage());
    }
    return con;
  }

  /** Method. */

  public void display() {
    try {
      con = getConnection();
      sql = "select * from Friends where Salary >?";
      PreparedStatement pstmt = con.prepareStatement(
          sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
      pstmt.setInt(1, 5000);
      ResultSet rs = pstmt.executeQuery();
      while (rs.next()) {
        System.out.print(rs.getString(1) + "\t");
        System.out.print(rs.getString(2) + "\t");
        System.out.print(rs.getInt(3) + "\t");
        System.out.print(rs.getDate(4) + "\t");
        System.out.print(rs.getInt(5) + "\t");
        System.out.println(" ");
      }
      rs.close();
      pstmt.close();
      con.close();
    }
    catch (SQLException ce) {
      System.out.println(ce);
    }
  }

  /** This is a main method.
   * It demonstrates the output displayed for a conditional
   * PreparedStatement in SQL
   * @param args passed to the main method
   */

  public static void main(String[] args) {
    RetrieveRecords retRec = new RetrieveRecords();
    retRec.display();
  }
}
