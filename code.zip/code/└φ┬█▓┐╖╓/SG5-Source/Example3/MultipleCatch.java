/*
 * (c)2005 Aptech Limited
 * All Rights Reserved
 */

/**
  * This class demonstrate the multiple catch statements.
  *
  * @version 1.0 2 June 2005
  * @author Michael
  */
class NumberException {


    /** Constructor. */
    protected NumberException() {
        }

     /** This method divides the number by zero.
       * @param number is used to store the args value.
       */
    public void test(String[] number) {

     try {

            /* Variable declaration for storing the vaue of args. */
            String num = number[0];
            int numValue = Integer.parseInt(num);

            System.out.println("The square is: " + numValue * numValue);

        /* Catching the array exxeptions. */
        } catch (ArrayIndexOutOfBoundsException ne) {

            System.out.println("No arguments given!");

        /* Catching the number format ecxeptions. */
        } catch (NumberFormatException nb) {

            System.out.println("Not a number!");
        }
    }
}

/**
  * This is a main class.
  */

class MultipleCatch {

    /** Constructor. */
    protected MultipleCatch() {
    }

    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */

    public static void main(String[] args) {

        NumberException obj = new NumberException();
        obj.test(args);

 }
}
