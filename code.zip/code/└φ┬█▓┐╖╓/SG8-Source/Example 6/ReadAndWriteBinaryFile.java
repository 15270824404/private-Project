/**
 * ��������APTECH
 * ��Ȩ����
 */
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.DataOutputStream;

/**
 * ��ʾ�������ļ��Ķ�д��
 */

public class ReadAndWriteBinaryFile {
  /**
   * main����
   * @param args String[]
   */
  public static void main(String[] args) {

    try {
      FileInputStream fis = new FileInputStream("ReadAndWriteBinaryFile.class");
      DataInputStream dis = new DataInputStream(fis);
      FileOutputStream outFile = new FileOutputStream("temp.class");
      DataOutputStream out = new DataOutputStream(outFile);
      int temp;
      while ( (temp = dis.read()) != -1) {
        out.write(temp);
      }
      fis.close();
      out.close();
    }
    catch (EOFException eof) {
      System.out.println("EOF reached ");
    }
    catch (IOException ioe) {
      System.out.println("IO error: " + ioe);
    }
    System.out.println("�ļ����Ƴɹ�");

  }
}
