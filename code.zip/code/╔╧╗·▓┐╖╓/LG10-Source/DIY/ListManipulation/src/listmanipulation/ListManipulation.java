package listmanipulation;


import java.awt.Dimension;
import java.util.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.*;
import java.awt.*;
import javax.swing.JList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class ListManipulation extends JFrame {
    /** */
    JPanel contentPane;
    /** */
    DefaultListModel obj = new DefaultListModel();
    /** */
    JButton btnAdd = new JButton();
    /** */
    JButton btnRemove = new JButton();
    /** */
    JList lstItems = new JList(obj);
    /** */
    String item;
    /** */
    JLabel lblDisplay = new JLabel();
    /** */
    public ListManipulation() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(400, 300));
        setTitle("List Manipulation");
        btnAdd.setBounds(new Rectangle(16, 25, 97, 37));
        btnAdd.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnAdd.setText("Add");
        btnAdd.addActionListener(
            new ListManipulation_btnAdd_actionAdapter(this));
        btnRemove.setBounds(new Rectangle(132, 26, 92, 37));
        btnRemove.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnRemove.setText("Remove");
        btnRemove.addActionListener(
            new ListManipulation_btnRemove_actionAdapter(this));
        lstItems.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        lstItems.setBounds(new Rectangle(37, 118, 170, 95));
        lblDisplay.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        lblDisplay.setText("List of Planets");
        lblDisplay.setBounds(new Rectangle(25, 71, 242, 37));
        contentPane.add(lstItems);
        contentPane.add(btnAdd);
        contentPane.add(btnRemove);
        contentPane.add(lblDisplay);
    }

    /**
     * btnAdd_actionPerformed
     * @param e ActionEvent
     */
    public void btnAdd_actionPerformed(ActionEvent e) {
        item = JOptionPane.showInputDialog("Enter the Name");
        obj.addElement(item);
    }

    /**
     * btnRemove_actionPerformed
     * @param e ActionEvent
     */
    public void btnRemove_actionPerformed(ActionEvent e) {
        int count = obj.getSize();
        if (count == 1) {
            JOptionPane.showMessageDialog(this,
                    "You cannot delete the only item in the list.", "ERROR",
                                          JOptionPane.ERROR_MESSAGE);
        } else {
            obj.remove(lstItems.getSelectedIndex());
        }
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class ListManipulation_btnAdd_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private ListManipulation adaptee;
    /**
     *
     * @param adaptee ListManipulation
     */
    ListManipulation_btnAdd_actionAdapter(ListManipulation adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnAdd_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class ListManipulation_btnRemove_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private ListManipulation adaptee;
    /**
     *
     * @param adaptee ListManipulation
     */
    ListManipulation_btnRemove_actionAdapter(ListManipulation adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnRemove_actionPerformed(e);
    }
}
