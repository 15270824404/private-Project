package listmanipulation;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class Main {
    /**
     * Main
     */
    public Main() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * main
     * @param args String[]
     */
    public static void main(String[] args) {
        ListManipulation obj = new ListManipulation();
//        Main main = new Main();
        obj.show();
    }

    /**
     * jbInit
     * @throws Exception e
     */
    private void jbInit() throws Exception {
    }
}
