package selectiondialog;


import java.awt.Dimension;
import javax.swing.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class SelectionDialog extends JFrame {
    /** contentPane*/
    JPanel contentPane;
    /** title*/
    String title = "����";
    /** message*/
    String message = "Country: ";
    /** selectionValues*/
    String[] selectionValues
            = {"India", "�й�", "Autralia", "England",
              "South Africa", "Dubai", "Sri Lanka"};
    /** btnShowDialog*/
    JButton btnShowDialog = new JButton();
    /**lblSelected */
    JLabel lblSelected = new JLabel();

    /**
     * SelectionDialog
     */
    public SelectionDialog() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        setSize(new Dimension(400, 300));
        setTitle("Selection Dialog");
        this.addWindowListener(new SelectionDialog_this_windowAdapter(this));
        btnShowDialog.setBounds(new Rectangle(156, 17, 126, 25));
        btnShowDialog.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnShowDialog.setText("Show Dialog");
        btnShowDialog.addActionListener(
            new SelectionDialog_btnShowDialog_actionAdapter(this));
        lblSelected.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        lblSelected.setToolTipText("");
        lblSelected.setText("");
        lblSelected.setBounds(new Rectangle(5, 83, 211, 37));
        contentPane.setLayout(null);
        contentPane.add(btnShowDialog, null);
        contentPane.add(lblSelected, null);
    }

    /**
     * this_windowOpened
     * @param e WindowEvent
     */
    public void this_windowOpened(WindowEvent e) {
        String value = (String) JOptionPane.showInputDialog(contentPane,
                message, title, JOptionPane.QUESTION_MESSAGE, null,
                selectionValues, selectionValues[3]);
    }

    /**
     * btnShowDialog_actionPerformed
     * @param e ActionEvent
     */
    public void btnShowDialog_actionPerformed(ActionEvent e) {
        String value = (String) JOptionPane.showInputDialog(contentPane,
                message, title, JOptionPane.QUESTION_MESSAGE, null,
                selectionValues, selectionValues[3]);
        lblSelected.setText("Country Selected: " + value);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class SelectionDialog_btnShowDialog_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private SelectionDialog adaptee;
    /**
     * SelectionDialog_btnShowDialog_actionAdapter
     * @param adaptee SelectionDialog
     */
    SelectionDialog_btnShowDialog_actionAdapter(SelectionDialog adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnShowDialog_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class SelectionDialog_this_windowAdapter extends WindowAdapter {
    /**
     * adaptee
     */
    private SelectionDialog adaptee;
    /**
     * SelectionDialog_this_windowAdapter
     * @param adaptee SelectionDialog
     */
    SelectionDialog_this_windowAdapter(SelectionDialog adaptee) {
    this.adaptee = adaptee;
    }

    /**
     * windowOpened
     * @param e WindowEvent
     */
    public void windowOpened(WindowEvent e) {
        adaptee.this_windowOpened(e);
    }
}
