package selectiondialog;
/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class SelectionMain {
        /**
         *
         * @param args String[]
         */
        public static void main(String[] args) {
        //        SelectionMain selectionmain = new SelectionMain();
        SelectionDialog obj = new SelectionDialog();
        obj.show();
    }
}
