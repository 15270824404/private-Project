package editor;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import com.borland.dbswing.FontChooser;
import java.io.*;
import java.util.Date;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class EditorFrame extends JFrame {
    /** contentPane*/
    JPanel contentPane;
    /**borderLayout1 */
    BorderLayout borderLayout1 = new BorderLayout();
    /**jMenuBar1 */
    JMenuBar jMenuBar1 = new JMenuBar();
    /**mnuFile */
    JMenu mnuFile = new JMenu();
    /**mnuNew */
    JMenuItem mnuNew = new JMenuItem();
    /**mnuOpen */
    JMenuItem mnuOpen = new JMenuItem();
    /**mnuExit */
    JMenuItem mnuExit = new JMenuItem();
    /**mnuEdit */
    JMenu mnuEdit = new JMenu();
    /**mnuFont */
    JMenuItem mnuFont = new JMenuItem();
    /**txaDisplay */
    JTextArea txaDisplay = new JTextArea();
    /**fntSelect */
    FontChooser fntSelect = new FontChooser();
    /**jMenu1 */
    JMenu jMenu1 = new JMenu();
    /**mnuBackground */
    JMenuItem mnuBackground = new JMenuItem();
    /**mnuForeground */
    JMenuItem mnuForeground = new JMenuItem();
    /**jColorChooser1 */
    JColorChooser jColorChooser1 = new JColorChooser();
    /**fcSelect */
    JFileChooser fcSelect = new JFileChooser();
    /**jTable1 */
    JTable jTable1 = new JTable();
    /**mnuPopupEdit */
    JPopupMenu mnuPopupEdit = new JPopupMenu();
    /**mnuDateTime */
    JMenuItem mnuDateTime = new JMenuItem();
    /**mnuEditable */
    JMenu mnuEditable = new JMenu();
    /**mnuLocked */
    JRadioButtonMenuItem mnuLocked = new JRadioButtonMenuItem();
    /**mnuUnLocked */
    JRadioButtonMenuItem mnuUnLocked = new JRadioButtonMenuItem();

    /**
     * EditorFrame
     */
    public EditorFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setSize(new Dimension(800, 800));
        setTitle("Editor");
        this.addWindowListener(new EditorFrame_this_windowAdapter(this));
        fntSelect.setFrame(this);
        mnuFile.setText("File");
        mnuNew.setText("New");
        mnuNew.addActionListener(new
                                 EditorFrame_jMenuFileExit_ActionAdapter(this));
        mnuOpen.setText("Open");
        mnuOpen.addActionListener(new EditorFrame_mnuOpen_actionAdapter(this));
        mnuExit.setText("Exit");
        mnuExit.addActionListener(new EditorFrame_mnuExit_actionAdapter(this));
        mnuEdit.setText("Edit");
        mnuFont.setText("Font");
        mnuFont.addActionListener(new EditorFrame_mnuFont_actionAdapter(this));
        txaDisplay.setText("");
        fntSelect.setTitle("FONT");
        jMenu1.setText("Color");
        mnuBackground.setText("Background");
        mnuBackground.addActionListener(
            new    EditorFrame_mnuBackground_actionAdapter(this));
        mnuForeground.setText("Foreground");
        mnuForeground.addActionListener(
            new    EditorFrame_mnuForeground_actionAdapter(this));
        mnuDateTime.setText("Date/Time");
        mnuDateTime.addActionListener(
            new EditorFrame_jMenuItem1_actionAdapter(this));
        mnuEditable.setText("Editable");
        mnuLocked.setText("Locked");
        mnuLocked.addActionListener(
            new EditorFrame_mnuLocked_actionAdapter(this));
        mnuUnLocked.setText("UnLocked");
        mnuUnLocked.addActionListener(
            new EditorFrame_mnuUnLocked_actionAdapter(this));
        jMenuBar1.add(mnuFile);
        jMenuBar1.add(mnuEdit);
        mnuFile.add(mnuNew);
        mnuFile.add(mnuOpen);
        mnuFile.add(mnuExit);
        mnuEdit.add(mnuFont);
        mnuEdit.add(jMenu1);
        mnuEdit.add(mnuDateTime);
        mnuEdit.add(mnuEditable);
        contentPane.add(txaDisplay, java.awt.BorderLayout.CENTER);
        contentPane.add(jTable1, java.awt.BorderLayout.NORTH);
        jMenu1.add(mnuBackground);
        jMenu1.add(mnuForeground);
        mnuEditable.add(mnuLocked);
        mnuEditable.add(mnuUnLocked);
        setJMenuBar(jMenuBar1);
    }

    /**
     * Load and display the specified file (if any) from the specified directory
     **/
    /**
     * File | Exit action performed.
     *
     * @param actionEvent ActionEvent
     */
    void jMenuFileExit_actionPerformed(ActionEvent actionEvent) {
        txaDisplay.setText("");
    }

    /**
     * mnuFont_actionPerformed
     * @param e ActionEvent
     */
    public void mnuFont_actionPerformed(ActionEvent e) {
        fntSelect.showDialog();
        if (fntSelect.showDialog()) {
            txaDisplay.setFont(fntSelect.getSelectedFont());
        }
    }

    /**
     * mnuColor_actionPerformed
     * @param e ActionEvent
     */
    public void mnuColor_actionPerformed(ActionEvent e) {

    }

    /**
     * mnuBackground_actionPerformed
     * @param e ActionEvent
     */
    public void mnuBackground_actionPerformed(ActionEvent e) {
        Color objColor = javax.swing.JColorChooser.showDialog(this,
                "Background Color", txaDisplay.getBackground());
        if (objColor != null) {
            txaDisplay.setBackground(objColor);
        }
    }

    /**
     * mnuForeground_actionPerformed
     * @param e ActionEvent
     */
    public void mnuForeground_actionPerformed(ActionEvent e) {
        Color objColor = javax.swing.JColorChooser.showDialog(this,
                "Foreground Color", txaDisplay.getForeground());
        if (objColor != null) {
            txaDisplay.setForeground(objColor);
        }
    }

    /**
     * mnuOpen_actionPerformed
     * @param e ActionEvent
     */
    public void mnuOpen_actionPerformed(ActionEvent e) {
        fcSelect.showOpenDialog(this);
        File file;
        FileReader in = null;
        // Read and display the file contents.  Since we're reading text, we
        // use a FileReader instead of a FileInputStream.
        try {
            file = new File(fcSelect.getSelectedFile().getPath());
            in = new FileReader(file); // Create a char stream to read  it
            int size = (int) file.length(); // Check file size
            char[] data = new char[size]; // Allocate an array big enough for it
            int chars_read = 0; // How many chars read so far?
            while (chars_read < size) { // Loop until we've read it all
                chars_read += in.read(data, chars_read, size - chars_read);
            }
            txaDisplay.setText(new String(data)); // Display chars in TextArea
        } catch (Exception ie) {
            txaDisplay.setText(ie.getClass().getName()
                               + ": " + ie.getMessage());
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException eee) {
                eee.printStackTrace();
            }
        }
        this.repaint();
    }

    /**
     * mnuCheck1_actionPerformed
     * @param e ActionEvent
     */
    public void mnuCheck1_actionPerformed(ActionEvent e) {
        boolean a;
    }

    /**
     * mnuExit_actionPerformed
     * @param e ActionEvent
     */
    public void mnuExit_actionPerformed(ActionEvent e) {
        System.exit(0);
    }

    /**
     * jMenuItem1_actionPerformed
     * @param e ActionEvent
     */
    public void jMenuItem1_actionPerformed(ActionEvent e) {
        Date objDate = new Date();
        txaDisplay.append(objDate.toString());
    }

    /**
     * jMenuItem1_actionPerformed
     * @param e ActionEvent
     */
    public void mnuLocked_actionPerformed(ActionEvent e) {
        txaDisplay.setEditable(false);
    }

    /**
     * mnuUnLocked_actionPerformed
     * @param e ActionEvent
     */
    public void mnuUnLocked_actionPerformed(ActionEvent e) {
        txaDisplay.setEditable(true);
    }

    /**
     * this_windowOpened
     * @param e WindowEvent
     */
    public void this_windowOpened(WindowEvent e) {
        String message;
        message = JOptionPane.showInputDialog("Please Enter you Name");
        this.setTitle(this.getTitle() + " - " + message);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_this_windowAdapter extends WindowAdapter {
        /**
         * adaptee
         */
        private EditorFrame adaptee;
        /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_this_windowAdapter(EditorFrame adaptee) {
    this.adaptee = adaptee;
    }

    /**
     *
     * @param e WindowEvent
     */
    public void windowOpened(WindowEvent e) {
    adaptee.this_windowOpened(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_mnuLocked_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private EditorFrame adaptee;
    /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_mnuLocked_actionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuLocked_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_mnuUnLocked_actionAdapter implements ActionListener {
    /**
     *
     */
    private EditorFrame adaptee;
    /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_mnuUnLocked_actionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuUnLocked_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_jMenuItem1_actionAdapter implements ActionListener {
    /**
     *
     */
    private EditorFrame adaptee;
    /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_jMenuItem1_actionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem1_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_mnuBackground_actionAdapter implements ActionListener {
    /**
     *
     */
    private EditorFrame adaptee;
    /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_mnuBackground_actionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuBackground_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_mnuForeground_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private EditorFrame adaptee;
    /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_mnuForeground_actionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
    adaptee.mnuForeground_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_mnuColor_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private EditorFrame adaptee;
    /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_mnuColor_actionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuColor_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_mnuFont_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private EditorFrame adaptee;
    /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_mnuFont_actionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuFont_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_jMenuFileExit_ActionAdapter implements ActionListener {
    /**
     * adaptee
     */
    EditorFrame adaptee;

    /**
     * EditorFrame_jMenuFileExit_ActionAdapter
     * @param adaptee EditorFrame
     */
    EditorFrame_jMenuFileExit_ActionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param actionEvent ActionEvent
     */
    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.jMenuFileExit_actionPerformed(actionEvent);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_mnuExit_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private EditorFrame adaptee;
    /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_mnuExit_actionAdapter(EditorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuExit_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
class EditorFrame_mnuOpen_actionAdapter implements ActionListener {
        /**
         * adaptee
         */
        private EditorFrame adaptee;
        /**
     *
     * @param adaptee EditorFrame
     */
    EditorFrame_mnuOpen_actionAdapter(EditorFrame adaptee) {
    this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.mnuOpen_actionPerformed(e);
    }
}
