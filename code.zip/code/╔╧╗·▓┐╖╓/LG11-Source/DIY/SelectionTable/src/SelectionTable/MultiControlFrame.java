package SelectionTable;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import java.awt.*;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.JComboBox;
import javax.swing.*;
import javax.swing.DefaultCellEditor;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class MultiControlFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * data
     */
    Object[][] data = new Object[][] {{"Tom", "Hanks", "",
                      new Integer(24), ""},
                      {"Ben", "John", " ", new Integer(25), ""}, {"Michael",
                      "Fred", "", new Integer(26), ""}, {"Steve", "Bell", "",
                      new Integer(27), ""}, {"Jim", "Lan", "", new Integer(29),
                      ""},
    };
    /**
     * column
     */
    Object[] column = new Object[] {"����", "����", "����", "����", "�Ƿ���ʵ"};
    /**
     * tblInformation
     */
    JTable tblInformation = new JTable(data, column);
    /**
     * tblHeader
     */
    JTableHeader tblHeader = tblInformation.getTableHeader();
    /**
     * skillsColumn
     */
    TableColumn skillsColumn = tblInformation.getColumnModel().getColumn(2);

    /**
     * cmbSkills
     */
    JComboBox cmbSkills = new JComboBox();
    /**
     * chkAvailable
     */
    JCheckBox chkAvailable = new JCheckBox("");
    /**
     * availColumn
     */
    TableColumn availColumn = tblInformation.getColumnModel().getColumn(4);
    /**
     * MultiControlFrame
     */
    public MultiControlFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(400, 300));
        setTitle("��������");
        tblInformation.setBounds(new Rectangle(6, 19, 307, 175));
        tblHeader.setBounds(new Rectangle(6, 0, 375, 20));
        contentPane.setFont(new java.awt.Font("", Font.PLAIN, 11));
        contentPane.add(tblHeader);
        contentPane.add(tblInformation);
        cmbSkills.addItem("Java");
        cmbSkills.addItem("Oracle");
        cmbSkills.addItem("Linux");
        cmbSkills.addItem("Unix");
        cmbSkills.addItem("C#");
        contentPane.add(cmbSkills);
        skillsColumn.setCellEditor(new DefaultCellEditor(cmbSkills));
        availColumn.setCellEditor(new DefaultCellEditor(chkAvailable));

    }
}
