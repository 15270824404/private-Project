package Table;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.*;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Frame1 extends JFrame {
    /**contentPane */
    JPanel contentPane;
    /**
     * data
     */
    Object[][] data = new Object[][] {{"1", "11", "A", "", "", "", "", ""},
                      {"2", "22", "", "B", "", "", "", ""}, {"3", "33", "", "",
                      "C", "", "", ""}, {"4", "44", "", "", "", "D", "", ""},
                      {"5", "55", "", "", "", "", "E", ""}, {"6", "66", "", "",
                      "", "", "", "F"}
    };
    /**
     * column
     */
    Object[] column = new Object[] {"�̶� 1", "�̶� 2", "a", "b", "c", "d", "e",
                      "f"};
    /**
     * tblDisplay
     */
    JTable tblDisplay = new JTable(data, column);
    /**
     * tblHeader
     */
    JTableHeader tblHeader = tblDisplay.getTableHeader();
    /**
     * Frame1
     */
    public Frame1() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(400, 150));
        setTitle("�̶����ȵ��б�");
        tblDisplay.setBackground(Color.lightGray);
        tblDisplay.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblDisplay.setColumnSelectionAllowed(true);
        tblDisplay.setGridColor(Color.black);
        tblDisplay.setBounds(new Rectangle(19, 23, 345, 99));
        tblHeader.setBackground(SystemColor.textHighlight);
        tblHeader.setEnabled(false);
        tblHeader.setForeground(Color.white);
        tblHeader.setToolTipText("");
        tblHeader.setBounds(new Rectangle(18, 4, 347, 20));
        contentPane.setBackground(Color.white);
        contentPane.add(tblDisplay);
        contentPane.add(tblHeader);
    }
}
