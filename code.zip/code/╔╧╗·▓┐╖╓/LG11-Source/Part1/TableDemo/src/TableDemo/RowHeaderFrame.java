package TableDemo;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.awt.*;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class RowHeaderFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * cells
     */
    Object[][] cells = {{"George", "Linux", new Integer(34)}, {"Bill", "Unix",
            new Integer(32)}, {"Sam", "Windows", new Integer(30)},
    };

    /**
     * colnames
     */
    String[] colnames = {"����", "�γ�", "����"};
    /**
     * jspTableScroll
     */
    JScrollPane jspTableScroll = new JScrollPane();
    /**
     * tblInformation
     */
    JTable tblInformation = new JTable(cells, colnames);
    /**
     * tblHeader
     */
    JTableHeader tblHeader = tblInformation.getTableHeader();

    /**
     * RowHeaderFrame
     */
    public RowHeaderFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(400, 300));
        setTitle("��");
        jspTableScroll.setBounds(new Rectangle(23, 25, 302, 237));
        tblInformation.setBackground(Color.cyan);
        tblInformation.setCellSelectionEnabled(true);
        tblHeader.setBackground(Color.pink);
        tblHeader.setForeground(Color.blue);

        contentPane.add(jspTableScroll);
        jspTableScroll.getViewport().add(tblHeader);
        jspTableScroll.getViewport().add(tblInformation);
    }
}
