package ComboboxTable;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.JTableHeader;
import javax.swing.table.*;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class JComboBoxTableFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;

    /**
     * data
     */
    Object[][] data = new Object[][] {{"����", ""}
    };
    /**
     * column
     */
    Object[] column = new Object[] {"�� A", "�� B"};

    /**
     * tblInformation
     */
    JTable tblInformation = new JTable(data, column);
    /**
     * tblHeader
     */
    JTableHeader tblHeader = tblInformation.getTableHeader();
    /**
     * ansColumn
     */
    TableColumn ansColumn = tblInformation.getColumnModel().getColumn(1);

    /**
     * cmbSelection
     */
    JComboBox cmbSelection = new JComboBox();

    /**
     * JComboBoxTableFrame
     */
    public JComboBoxTableFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(200, 150));
        setTitle("��������");
        tblInformation.setBounds(new Rectangle(-1, 18, 265, 159));
        tblHeader.setBounds(new Rectangle(0, 0, 267, 20));
        cmbSelection.setBounds(new Rectangle(131, 33, 116, 18));

        contentPane.add(tblHeader);
        contentPane.add(tblInformation);
        tblInformation.add(cmbSelection);

        cmbSelection.addItem("Java");
        cmbSelection.addItem("Oracle");

        cmbSelection.addItem("C#");
        cmbSelection.addItem("Linux");
        contentPane.add(cmbSelection);
        ansColumn.setCellEditor(new DefaultCellEditor(cmbSelection));

    }
}
