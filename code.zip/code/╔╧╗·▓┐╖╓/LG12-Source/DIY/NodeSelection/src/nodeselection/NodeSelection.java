package nodeselection;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTree;
import java.awt.*;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import javax.swing.tree.*;
import javax.swing.*;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class NodeSelection extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * treDisplay
     */
    JTree treDisplay = new JTree();
    /**
     * btnDelete
     */
    JButton btnDelete = new JButton();
    /**
     * btnExit
     */
    JButton btnExit = new JButton();
    /**
     * sports
     */
    DefaultMutableTreeNode sports;
    /**
     * food
     */
    DefaultMutableTreeNode food;
    /**
     * root
     */
    DefaultMutableTreeNode root;
    /**
     * mnuDisplay
     */
    JPopupMenu mnuDisplay = new JPopupMenu();
    /**
     * mnuEditable
     */
    JMenu mnuEditable = new JMenu();
    /**
     * mnuLocked
     */
    JMenuItem mnuLocked = new JMenuItem();
    /**
     * mnuUnLocked
     */
    JMenuItem mnuUnLocked = new JMenuItem();
    /**
     * mnuExit
     */
    JMenuItem mnuExit = new JMenuItem();
    /**
     * mnuDelete
     */
    JMenuItem mnuDelete = new JMenuItem();
    /**
     * NodeSelection
     */
    public NodeSelection() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        treDisplay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent event) {
                if (event.getModifiers() == Event.META_MASK) {
                    mnuDisplay.show(contentPane, event.getX(), event.getY());
                }
            }
        });
        setSize(new Dimension(300, 300));
        setTitle("�ڵ�ѡ��");
        treDisplay.setEnabled(false);
        treDisplay.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        treDisplay.setBounds(new Rectangle(41, 7, 213, 208));
        btnDelete.setBounds(new Rectangle(69, 226, 75, 36));
        //btnDelete.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnDelete.setText("ɾ��");
        btnDelete.addActionListener(
            new NodeSelection_btnDisplay_actionAdapter(this));
        btnExit.setBounds(new Rectangle(150, 226, 75, 36));
        //btnExit.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnExit.setText("�˳�");
        btnExit.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                btnExit_mouseClicked(e);
            }
        });
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnExit_actionPerformed(e);
            }
        });
        treDisplay.setEditable(false);
        mnuDisplay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                jPopupMenu1_mouseClicked(e);
            }
        });
        contentPane.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                contentPane_mouseClicked(e);
            }
        });
        mnuEditable.setText("�༭");
        mnuLocked.setText("����");
        mnuLocked.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mnuLocked_actionPerformed(e);
            }
        });
        mnuUnLocked.setText("����");
        mnuUnLocked.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mnuUnLocked_actionPerformed(e);
            }
        });
        mnuExit.setText("�˳�");
        mnuExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mnuExit_actionPerformed(e);
            }
        });
        mnuDelete.setText("ɾ��");
        mnuDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mnuDelete_actionPerformed(e);
            }
        });
        contentPane.add(treDisplay, null);
        contentPane.add(btnDelete);
        contentPane.add(btnExit);
        contentPane.add(mnuDisplay);
        mnuDisplay.add(mnuEditable);
        mnuDisplay.add(mnuDelete);
        mnuDisplay.add(mnuExit);
        mnuEditable.add(mnuLocked);
        mnuEditable.add(mnuUnLocked);
    }

    /**
     * showMenu
     * @param x int
     * @param y int
     */
    protected void showMenu(int x, int y) {
        JPopupMenu popup = new JPopupMenu();
        JMenuItem mi = new JMenuItem("Delete");
        TreePath path = treDisplay.getSelectionPath();
        Object node = path.getLastPathComponent();
        if (node == treDisplay.getModel().getRoot()) {
            mi.setEnabled(false);
        }
        popup.add(mi);
        contentPane.add(popup);
        popup.show(treDisplay, x, y);
    }

    /**
     * btnDisplay_actionPerformed
     * @param e ActionEvent
     */
    public void btnDisplay_actionPerformed(ActionEvent e) {
        DefaultMutableTreeNode node = new DefaultMutableTreeNode();
        DefaultTreeModel model = (DefaultTreeModel) (treDisplay.getModel());
        TreePath[] paths = treDisplay.getSelectionPaths();
        for (int i = 0; i < paths.length; i++) {
            node = (DefaultMutableTreeNode) (paths[i].getLastPathComponent());
            model.removeNodeFromParent(node);
        }
        JOptionPane.showMessageDialog(this, "Item Successfully Deleted",
                                      "Deleted", JOptionPane.ERROR_MESSAGE);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnExit_actionPerformed(ActionEvent e) {
        System.exit(0);
    }

    /**
     * btnAdd_actionPerformed
     * @param e ActionEvent
     */
    public void btnAdd_actionPerformed(ActionEvent e) {
        String str;
        String message;
        str = JOptionPane.showInputDialog("Please enter the node");
        DefaultMutableTreeNode child = new DefaultMutableTreeNode(str);
        //path = jTree1.getSelectionPaths();
        food.add(child);

        treDisplay.updateUI();

    }

    /**
     *
     * @param e MouseEvent
     */
    public void jPopupMenu1_mouseClicked(MouseEvent e) {

    }

    /**
     *
     * @param e MouseEvent
     */
    public void contentPane_mouseClicked(MouseEvent e) {

    }

    /**
     *
     * @param e MouseEvent
     */
    public void treDisplay_mousePressed(MouseEvent e) {

    }

    /**
     *
     * @param e MouseEvent
     */
    public void btnExit_mouseClicked(MouseEvent e) {

    }

    /**
     *
     * @param e ActionEvent
     */
    public void mnuExit_actionPerformed(ActionEvent e) {
        System.exit(0);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void mnuDelete_actionPerformed(ActionEvent e) {
        DefaultMutableTreeNode node = new DefaultMutableTreeNode();
        DefaultTreeModel model = (DefaultTreeModel) (treDisplay.getModel());
        TreePath[] paths = treDisplay.getSelectionPaths();
        for (int i = 0; i < paths.length; i++) {
            node = (DefaultMutableTreeNode) (paths[i].getLastPathComponent());
            model.removeNodeFromParent(node);
        }
        JOptionPane.showMessageDialog(this, "Item Successfully Deleted",
                                      "Deleted", JOptionPane.ERROR_MESSAGE);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void mnuUnLocked_actionPerformed(ActionEvent e) {
        btnDelete.setEnabled(true);
        mnuDelete.setEnabled(true);
        treDisplay.setEditable(true);
        treDisplay.setEnabled(true);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void mnuLocked_actionPerformed(ActionEvent e) {
        btnDelete.setEnabled(false);
        mnuDelete.setEnabled(false);
        treDisplay.setEditable(false);
        treDisplay.setEnabled(false);
    }

}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
class NodeSelection_btnDisplay_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private NodeSelection adaptee;
    /**
     *
     * @param adaptee NodeSelection
     */
    NodeSelection_btnDisplay_actionAdapter(NodeSelection adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {

        adaptee.btnDisplay_actionPerformed(e);
    }
}
