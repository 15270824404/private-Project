package nodeselection;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class NodeSelectionMain {
    /**
     * NodeSelectionMain
     */
    public NodeSelectionMain() {
        super();
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * main
     * @param args String[]
     */
    public static void main(String[] args) {
        NodeSelection obj = new NodeSelection();
        NodeSelectionMain nodeselectionmain = new NodeSelectionMain();
        obj.show();
    }

    /**
     * jbInit
     * @throws Exception e
     */
    private void jbInit() throws Exception {
    }
}
