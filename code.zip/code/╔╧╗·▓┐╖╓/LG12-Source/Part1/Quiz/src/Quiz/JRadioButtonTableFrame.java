package Quiz;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import java.awt.*;
import javax.swing.table.JTableHeader;
import javax.swing.JRadioButton;

import javax.swing.ButtonGroup;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class JRadioButtonTableFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     *data
     */
    Object[][] data = new Object[][] {{"������һ���ǳ�����", ""}, {"ȷ����Ч�� Date ����", ""},
    };
    /**
     *column
     */
    Object[] column = new Object[] {"����", "��"};
    /**
     *tblQuestion
     */
    JTable tblQuestion = new JTable(data, column);

    /**
     *jTableHeader1
     */
    JTableHeader jTableHeader1 = tblQuestion.getTableHeader();
    /**
     *rdo1A
     */
    JRadioButton rdo1A = new JRadioButton();
    /**
     *rdoVector
     */
    JRadioButton rdoVector = new JRadioButton();
    /**
     *rdoMath
     */
    JRadioButton rdoMath = new JRadioButton();
    /**
     *rdoTime
     */
    JRadioButton rdoTime = new JRadioButton();
    /**
     *btnGrp1
     */
    ButtonGroup btnGrp1 = new ButtonGroup();
    /**
     *btnGrp2
     */
    ButtonGroup btnGrp2 = new ButtonGroup();
    /**
     *titledBorder1
     */
    TitledBorder titledBorder1 = new TitledBorder("");
    /**
     *rdoSecond
     */
    JRadioButton rdoSecond = new JRadioButton();
    /**
     * JRadioButtonTableFrame
     */
    public JRadioButtonTableFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        setSize(new Dimension(400, 300));
        setTitle("����");
        tblQuestion.setEnabled(false);
        tblQuestion.setAlignmentX((float) 1.0);
        tblQuestion.setAlignmentY((float) 1.0);
        tblQuestion.setAutoscrolls(false);
        tblQuestion.setBorder(BorderFactory.createLineBorder(Color.black));
        tblQuestion.setOpaque(false);
        tblQuestion.setRequestFocusEnabled(false);
        tblQuestion.setVerifyInputWhenFocusTarget(false);
        tblQuestion.setAutoCreateColumnsFromModel(false);
        tblQuestion.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblQuestion.setRowHeight(50);
        tblQuestion.setRowSelectionAllowed(false);
        tblQuestion.setShowHorizontalLines(false);
        tblQuestion.setShowVerticalLines(false);
        tblQuestion.setBounds(new Rectangle(1, 18, 420, 110));
        jTableHeader1.setEnabled(false);
        jTableHeader1.setBorder(BorderFactory.createEtchedBorder());
        jTableHeader1.setRequestFocusEnabled(false);
        jTableHeader1.setReorderingAllowed(false);
        jTableHeader1.setResizingAllowed(false);
        jTableHeader1.setBounds(new Rectangle(0, 0, 400, 20));
        rdo1A.setAlignmentY((float) 0.0);
        rdo1A.setText("A");
        rdo1A.setBounds(new Rectangle(40, 144, 250, 61));
        rdo1A.addActionListener(
            new JRadioButtonTableFrame_jRadioButton1_actionAdapter(this));
        rdoVector.setAlignmentY((float) 0.0);
        rdoVector.setText("Vector");
        rdoVector.setBounds(new Rectangle(303, 30, 79, 33));
        rdoVector.addActionListener(
            new JRadioButtonTableFrame_jRadioButton2_actionAdapter(this));
        rdoMath.setAlignmentY((float) 0.0);
        rdoMath.setText("Math");
        rdoMath.setBounds(new Rectangle(219, 30, 80, 32));
        rdoMath.addActionListener(
            new JRadioButtonTableFrame_jRadioButton3_actionAdapter(this));
        rdoTime.setAlignmentY((float) 0.0);
        rdoTime.setText("getTime()");
        rdoTime.setBounds(new Rectangle(306, 76, 81, 35));
        rdoTime.addActionListener(
            new JRadioButtonTableFrame_jRadioButton4_actionAdapter(this));
        contentPane.setDoubleBuffered(false);
        contentPane.setLayout(null);
        rdoSecond.setText("getSecond()");
        rdoSecond.setBounds(new Rectangle(217, 75, 86, 34));
        rdoSecond.addActionListener(
            new JRadioButtonTableFrame_rdoSecond_actionAdapter(this));
        btnGrp1.add(rdoVector);
        btnGrp1.add(rdo1A);
        btnGrp1.add(rdoMath);

        btnGrp2.add(rdoTime);
        btnGrp2.add(rdoSecond);
        contentPane.add(jTableHeader1, null);
        jTableHeader1.add(rdo1A);
        contentPane.add(rdoMath, null);
        contentPane.add(rdoVector, null);
        contentPane.add(tblQuestion, null);
        contentPane.add(rdoTime, null);
        contentPane.add(rdoSecond);

        contentPane.add(tblQuestion, null);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void jRadioButton1_actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(this, "�����");
    }

    /**
     *
     * @param e ActionEvent
     */
    public void jRadioButton2_actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(this, "�����");
    }

    /**
     *
     * @param e ActionEvent
     */
    public void jRadioButton3_actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(this, "��ȷ��");
    }

    /**
     *
     * @param e ActionEvent
     */
    public void jRadioButton4_actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(this, "��ȷ��");
    }

    /**
     *
     * @param e ActionEvent
     */
    public void rdoSecond_actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(this, "�����");
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
class JRadioButtonTableFrame_rdoSecond_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private JRadioButtonTableFrame adaptee;
    /**
     *
     * @param adaptee JRadioButtonTableFrame
     */
    JRadioButtonTableFrame_rdoSecond_actionAdapter(JRadioButtonTableFrame
            adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.rdoSecond_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
class JRadioButtonTableFrame_jRadioButton4_actionAdapter implements
        ActionListener {
    /**
     * adaptee
     */
    private JRadioButtonTableFrame adaptee;
    /**
     *
     * @param adaptee JRadioButtonTableFrame
     */
    JRadioButtonTableFrame_jRadioButton4_actionAdapter(JRadioButtonTableFrame
            adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.jRadioButton4_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

class JRadioButtonTableFrame_jRadioButton3_actionAdapter implements
        ActionListener {
    /**
     * adaptee
     */
    private JRadioButtonTableFrame adaptee;
    /**
     *
     * @param adaptee JRadioButtonTableFrame
     */
    JRadioButtonTableFrame_jRadioButton3_actionAdapter(JRadioButtonTableFrame
            adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.jRadioButton3_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
class JRadioButtonTableFrame_jRadioButton2_actionAdapter implements
        ActionListener {
    /**
     * adaptee
     */
    private JRadioButtonTableFrame adaptee;
    /**
     *
     * @param adaptee JRadioButtonTableFrame
     */
    JRadioButtonTableFrame_jRadioButton2_actionAdapter(JRadioButtonTableFrame
            adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.jRadioButton2_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
class JRadioButtonTableFrame_jRadioButton1_actionAdapter implements
        ActionListener {
    /**
     * adaptee
     */
    private JRadioButtonTableFrame adaptee;
    /**
     *
     * @param adaptee JRadioButtonTableFrame
     */
    JRadioButtonTableFrame_jRadioButton1_actionAdapter(JRadioButtonTableFrame
            adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.jRadioButton1_actionPerformed(e);
    }
}
