package nodeselection;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTree;
import java.awt.*;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import javax.swing.tree.*;
import javax.swing.*;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class NodeSelection extends JFrame {
    /** contentPane*/
    JPanel contentPane;
    /**treDisplay */
    JTree treDisplay = new JTree();
    /**btnDelete */
    JButton btnDelete = new JButton();
    /**btnExit */
    JButton btnExit = new JButton();
    /**sports */
    DefaultMutableTreeNode sports;
    /** food*/
    DefaultMutableTreeNode food;
    /**root */
    DefaultMutableTreeNode root;

    /**
     *
     */
    public NodeSelection() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception  e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        treDisplay.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent event) {
                if (((event.getModifiers() & InputEvent.BUTTON2_MASK) != 0)
                    &&
                    (treDisplay.getSelectionCount() > 0)) {
                    showMenu(event.getX(), event.getY());
                }
            }
        });
        setSize(new Dimension(400, 300));
        setTitle("�ڵ�ѡ��");
        treDisplay.setFont(new java.awt.Font("", Font.PLAIN, 11));
        treDisplay.setBounds(new Rectangle(41, 7, 213, 208));
        btnDelete.setBounds(new Rectangle(69, 226, 75, 36));
        btnDelete.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnDelete.setText("ɾ��");
        btnDelete.addActionListener(
            new NodeSelection_btnDisplay_actionAdapter(this));
        btnExit.setBounds(new Rectangle(150, 226, 75, 36));
        btnExit.setFont(new java.awt.Font("", Font.PLAIN, 11));
        btnExit.setText("�˳�");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnExit_actionPerformed(e);
            }
        });
        contentPane.add(treDisplay, null);
        contentPane.add(btnDelete);
        contentPane.add(btnExit);
    }

    /**
     * showMenu
     * @param x int
     * @param y int
     */
    protected void showMenu(int x, int y) {
        JPopupMenu popup = new JPopupMenu();
        JMenuItem mi = new JMenuItem("ɾ��");
        TreePath path = treDisplay.getSelectionPath();
        Object node = path.getLastPathComponent();
        if (node == treDisplay.getModel().getRoot()) {
            mi.setEnabled(false);
        }
        popup.add(mi);
        contentPane.add(popup);
        popup.show(treDisplay, x, y);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnDisplay_actionPerformed(ActionEvent e) {
        DefaultMutableTreeNode node = new DefaultMutableTreeNode();
        DefaultTreeModel model = (DefaultTreeModel) (treDisplay.getModel());
        TreePath[] paths = treDisplay.getSelectionPaths();
        for (int i = 0; i < paths.length; i++) {
            node = (DefaultMutableTreeNode) (paths[i].getLastPathComponent());
            model.removeNodeFromParent(node);
        }
        JOptionPane.showMessageDialog(this, "�ѳɹ�ɾ���ڵ�", "��ɾ��",
                                      JOptionPane.ERROR_MESSAGE);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnExit_actionPerformed(ActionEvent e) {
        System.exit(0);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnAdd_actionPerformed(ActionEvent e) {
        String str;
        String message;
        str = JOptionPane.showInputDialog("������ڵ�");
        DefaultMutableTreeNode child = new DefaultMutableTreeNode(str);
        //path = jTree1.getSelectionPaths();
        food.add(child);

        treDisplay.updateUI();

    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
class NodeSelection_btnDisplay_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private NodeSelection adaptee;
    /**
     *
     * @param adaptee NodeSelection
     */
    NodeSelection_btnDisplay_actionAdapter(NodeSelection adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {

        adaptee.btnDisplay_actionPerformed(e);
    }
}
