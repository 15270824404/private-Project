/**
 * (c)��������APTECH
 * All Rights Reserved
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 * This class Adds, Modifies, searches and deletes record.
 * @version 1.0 15 June 2005
 * @author Michael
 */

class StudentDetails {

  /** Declaring a statement object.*/
  private Statement stmtObj;

  /** Declaring a string variable.*/
  private String strSql;

  /** Declaring a Connection object.*/
  private Connection con;

  /** Declaring a BufferedReader object.*/
  private BufferedReader bufferObj;

  /**
   *  Constructor. 
   */
  StudentDetails() {
    bufferObj = new BufferedReader(new InputStreamReader(System.in));
  }

  /**
   *  Method establishing connection. 
   */  
  void establishConnection() {
    try {

      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    }
    catch (ClassNotFoundException ce) {
      System.out.println(ce);
    }

    try {
      String url = "jdbc:odbc:test";
      con = DriverManager.getConnection(url, "sa", "sa");
      stmtObj = con.createStatement();
    }
    catch (SQLException ce) {
      System.out.println("Error... " + ce);
    }

  }

  /** 
   * Adding a record in the database. 
   */
  void addRecord() {

    try {

      System.out.print("\n������ѧ��: ");
      int roll = Integer.parseInt(bufferObj.readLine());

      System.out.print("\n������ѧ��������: ");
      String name = bufferObj.readLine();

      System.out.print("\n������γ�����: ");
      String course = bufferObj.readLine();

      strSql = "Insert into Student values('" + name;
      strSql = strSql + "', " + roll + ",'" + course + "')";

      stmtObj.executeUpdate(strSql);
      System.out.print("\n��¼�ѳɹ����� !");
      System.out.println();

    }
    catch (SQLException ioe) {
       System.out.println("���� :" + ioe);
    }
    catch (Exception e) {
      System.out.println(e);
    }
  }

  /** 
   * Modifying a record in the database. 
   */
  void modifyRecord() {

    try {

      System.out.print("\n ������Ҫ�޸�"
                       + " ��¼��ѧ��: ");
      int roll = Integer.parseInt(bufferObj.readLine());

      System.out.print("\n������Ҫ�޸ĵ�ѧ������: ");
      String name = bufferObj.readLine();

      System.out.print("\n������Ҫ�޸ĵĿγ�����: ");
      String course = bufferObj.readLine();

      strSql = "Update student set Name ='" + name;
      strSql = strSql + "' " + ",Course ='" + course;
      strSql = strSql + "' where RollNo =" + roll;

      stmtObj.executeUpdate(strSql);
      System.out.print("\n��¼�ѳɹ��޸� !");
      System.out.println();

    }
    catch (SQLException ioe) {
      System.out.println(ioe);
    }
    catch (Exception e) {
      System.out.println(e);
    }
  }

  /**
   * Deleting a record in the database. 
   */
  void deleteRecord() {

    try {

      System.out.print("\n������"
                       + " Ҫɾ����¼��ѧ��: ");
      int roll = Integer.parseInt(bufferObj.readLine());

      System.out.print("\n������Ҫɾ����ѧ������: ");
      String name = bufferObj.readLine();

      strSql = "Delete from student where rtrim(Name) like '" + name;
      strSql = strSql + "' and RollNo =" + roll;
      stmtObj.executeUpdate(strSql);
      System.out.print("\n��¼�ѳɹ�ɾ�� !");
      System.out.println();

    }
    catch (SQLException ioe) {
      System.out.println("ɾ��ʱ����...." + ioe);
    }
    catch (Exception e) {
      System.out.println("����....." + e);
    }
  }

  /** 
   * Searching a record in the database.
   */
  void searchRecord() {

    try {

      System.out.print("\n������"
                       + " Ҫ������¼��ѧ��: ");
      int roll = Integer.parseInt(bufferObj.readLine());

      System.out.print("\n������Ҫ������ѧ������: ");
      String name = bufferObj.readLine();

      strSql = "select * from student where Name like'" + name;
      strSql = strSql + "' and RollNo=" + roll;
      ResultSet rs = stmtObj.executeQuery(strSql);
      if (!rs.next()) {
        System.out.println("\n��¼δ�ҵ�");
      }
      else {
        System.out.print("\n���� : ");
        System.out.print(rs.getString(1) + "\t");
        System.out.print("\nѧ�� : ");
        System.out.print(rs.getInt(2) + "\t");
        System.out.print("\n�γ� : ");
        System.out.print(rs.getString(3) + "\n");
      }
    }
    catch (SQLException ioe) {
      System.out.println(ioe);
    }
    catch (Exception e) {
      System.out.println(e);
    }
  }

  /** Displaying a choice to the user.
   * @throws IOException object
   */
  public void menudisplay() throws IOException {

    char choice;

    while (true) {
      System.out.println();
      System.out.println("1.���Ӽ�¼");
      System.out.println("2.�޸ļ�¼");
      System.out.println("3.ɾ����¼");
      System.out.println("4.������¼");
      System.out.println("5.�˳�\n\n");
      System.out.print("����������ѡ��...: ");
      BufferedReader br = new BufferedReader(new
                                             InputStreamReader(System.in));
      choice = (char) br.read();

      switch (choice) {

        case '1':
          System.out.println("\n�������Ӽ�¼......");
          addRecord();
          break;
        case '2':
          System.out.println("\n�����޸ļ�¼......");
          modifyRecord();
          break;
        case '3':
          System.out.println("\n����ɾ����¼......");
          deleteRecord();
          break;
        case '4':
          System.out.println("\n����������¼......");
          searchRecord();
          break;
        case '5':
          System.exit(0);
          break;
        default:
          System.out.println("\n������һ����Ч����\n");
          break;
      }
    }
  }
}

/**
 * Test the StudentDetails class.
 * @version 1.0 20 May 2005
 * @author Michael
 */
class StudentDetailsTest {

  /** Constructor. */
  protected StudentDetailsTest() {
  }

  /**
   * This is the starting point of execution of any application.
   * @param args passed to the main method
   * @throws IOException object
   */

  public static void main(String[] args) throws IOException {

    StudentDetails studentObj = new StudentDetails();
    studentObj.establishConnection();
    studentObj.menudisplay();
  }
}
