package debugging;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
class debug {

    /**
     *
     * @param args String[]
     */
    public static void main(String[] args) {
        int []array = {2, 3, 6, 7, 4, 5, 9, 8};
        int i;
        for (i = 0; i <= 7; i++) {
            int cube = array[i] * array[i] * array[8];
            System.out.println(array[i] + "������" + "��" + cube);
        }
    }
}
