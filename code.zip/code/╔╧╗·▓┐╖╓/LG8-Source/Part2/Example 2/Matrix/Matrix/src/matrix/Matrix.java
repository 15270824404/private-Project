package matrix;

/**
 *
 * <p>Title: Matrix Debug</p>
 *
 * <p>Description: Program to debug a matrix program</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Aptech Limited</p>
 *
 * @author not attributable
 * @version 1.0
 */
class Matrix {

        /**
         *
         * @param args String[]
         */
        public static void main(String[] args) {
        int [][]arr;
        arr = new int[4][4];
        arr[0][0] = 1;
        arr[1][1] = 1;
        arr[2][2] = 1;
        arr[3][3] = 1;
        System.out.println(arr[0][0] + " " + arr[0][1] + " " + arr[0][2] + " "
                           + arr[0][3]);
        System.out.println(arr[1][0] + " " + arr[1][1] + " " + arr[1][2] + " "
                           + arr[1][3]);
        System.out.println(arr[2][0] + " " + arr[2][1] + " " + arr[2][2] + " "
                           + arr[2][3]);
        System.out.println(arr[3][0] + " " + arr[3][1] + " " + arr[3][2] + " "
                           + arr[3][3]);
    }
}
