package file_viewer;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.awt.Font;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class FileViewerFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * borderLayout1
     */
    BorderLayout borderLayout1 = new BorderLayout();
    /**
     * txaDisplay
     */
    JTextArea txaDisplay = new JTextArea();
    /**
     * btnClose
     */
    JButton btnClose = new JButton();
    /**
     * FileViewerFrame
     */
    public FileViewerFrame() {

        File files;
        BufferedReader in = null;
        // Read and display the file contents.  Since we're reading text, we
        // use a FileReader instead of a FileInputStream.
        try {
            jbInit();
            files = new File("Text.txt"); // Create a file object
            in = new BufferedReader(
                    new FileReader(files));
            txaDisplay.setText("�ļ���e: " + files.getName());
            txaDisplay.append("\r\n" + "��Ŀ¼: " + files.getParent());
            txaDisplay.append("\r\n" + "����޸�����: " + files.lastModified());
            txaDisplay.append("\r\n" + "����: " + files.length() + " �ֽ�");
            txaDisplay.append("\r\n" + "����·��: " + files.isAbsolute());
            txaDisplay.append("\r\n");

            int size = (int) files.length();
            System.out.println(size);
            String data = in.readLine();

            txaDisplay.append("\r\n" + "�ļ�����: ");
            while (data != null) {
                txaDisplay.append("\r\n" + data);
                data = in.readLine();

            } // Display chars in TextArea
            //this.setTitle("FileViewer: " + filename); // Set the window title
            setDefaultCloseOperation(EXIT_ON_CLOSE);
        }  catch (Exception e) {
            txaDisplay.setText(e.getClass().getName() + ": " + e.getMessage());
            //this.setTitle("FileViewer: " + filename + ": I/O Exception");
        }  finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
              e.printStackTrace();
            }
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setSize(new Dimension(400, 300));
        setTitle("�ļ��鿴��");
        txaDisplay.setFont(new java.awt.Font("����", Font.PLAIN, 12));
        txaDisplay.setText("");
        btnClose.setFont(new java.awt.Font("����", Font.PLAIN, 12));
        btnClose.setText("�ر�");
        btnClose.addActionListener(
            new FileViewerFrame_btnClose_actionAdapter(this));
        contentPane.add(txaDisplay, java.awt.BorderLayout.CENTER);
        contentPane.add(btnClose, java.awt.BorderLayout.SOUTH);
    }

    /**
     * btnClose_actionPerformed
     * @param e ActionEvent
     */
    public void btnClose_actionPerformed(ActionEvent e) {
        System.exit(0);
    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: </p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author Michael Clarke
 * @version 1.0
 */
class FileViewerFrame_btnClose_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private FileViewerFrame adaptee;
    /**
     *FileViewerFrame_btnClose_actionAdapter
     * @param adaptee FileViewerFrame
     */
    FileViewerFrame_btnClose_actionAdapter(FileViewerFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnClose_actionPerformed(e);
    }
}
