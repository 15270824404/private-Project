package calculator;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.Color;
import java.awt.Rectangle;

/**
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
public class CalculatorFrame extends JFrame {
    /**
     *contentPane
     */
    JPanel contentPane;
    /**
     *btnmultiply
     */
    JButton btnmultiply = new JButton();
    /**
     *btn6
     */
    JButton btn6 = new JButton();
    /**
     *btn3
     */
    JButton btn3 = new JButton();
    /**
     *btn2
     */
    JButton btn2 = new JButton();
    /**
     *btn8
     */
    JButton btn8 = new JButton();
    /**
     *btn5
     */
    JButton btn5 = new JButton();
    /**
     *btnplus
     */
    JButton btnplus = new JButton();
    /**
     *btn0
     */
    JButton btn0 = new JButton();
    /**
     *btn9
     */
    JButton btn9 = new JButton();
    /**
     * btnminus
     */
    JButton btnminus = new JButton();
    /**
     *txtresult
     */
    JTextField txtresult = new JTextField();
    /**
     *btnequal
     */
    JButton btnequal = new JButton();
    /**
     *btn1
     */
    JButton btn1 = new JButton();
    /**
     *btn4
     */
    JButton btn4 = new JButton();
    /**
     *btn7
     */
    JButton btn7 = new JButton();
    /**
     *btnclear
     */
    JButton btnclear = new JButton();
    /**
     *btndivide
     */
    JButton btndivide = new JButton();
    /**
     *flag
     */
    boolean flag = false;
    /**
     *operand1
     */
    String operand1;
    /**
     *operand2
     */
    String operand2;
    /**
     *result
     */
    double result;
    /**
     *action
     */
    String action;
    /**
     *CalculatorFrame
     */
    public CalculatorFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(250, 250));
        setTitle("������");

        btnmultiply.setBounds(new Rectangle(163, 107, 44, 30));
        btnmultiply.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnmultiply.setText("*");
        btnmultiply.setForeground(Color.red);
        btnmultiply.addActionListener(
            new CalculatorFrame_btnmultiply_actionAdapter(this));
        btn6.setBounds(new Rectangle(114, 107, 44, 30));
        btn6.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn6.setText("6");
        btn6.addActionListener(new CalculatorFrame_btn6_actionAdapter(this));
        btn3.setBounds(new Rectangle(114, 141, 44, 30));
        btn3.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn3.setText("3");
        btn3.addActionListener(new CalculatorFrame_btn3_actionAdapter(this));
        btn2.setBounds(new Rectangle(64, 141, 44, 30));
        btn2.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn2.setText("2");
        btn2.addActionListener(new CalculatorFrame_btn2_actionAdapter(this));
        btn8.setBounds(new Rectangle(64, 73, 44, 30));
        btn8.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn8.setText("8");
        btn8.addActionListener(new CalculatorFrame_btn8_actionAdapter(this));
        btn5.setBounds(new Rectangle(64, 107, 44, 30));
        btn5.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn5.setText("5");
        btn5.addActionListener(new CalculatorFrame_btn5_actionAdapter(this));
        btnplus.setBounds(new Rectangle(163, 173, 44, 30));
        btnplus.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnplus.setText("+");
        btnplus.setForeground(Color.red);
        btnplus.addActionListener(
            new CalculatorFrame_btnplus_actionAdapter(this));
        btn0.setBounds(new Rectangle(15, 175, 45, 30));
        btn0.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn0.setText("0");
        btn0.addActionListener(new CalculatorFrame_btn0_actionAdapter(this));
        btn9.setBounds(new Rectangle(114, 74, 44, 30));
        btn9.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn9.setText("9");
        btn9.addActionListener(new CalculatorFrame_btn9_actionAdapter(this));
        btnminus.setBounds(new Rectangle(163, 140, 44, 30));
        btnminus.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnminus.setText("-");
        btnminus.setForeground(Color.red);
        btnminus.addActionListener(
            new CalculatorFrame_btnminus_actionAdapter(this));
        txtresult.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        txtresult.setText("");
        txtresult.setHorizontalAlignment(JTextField.RIGHT);
        txtresult.setBounds(new Rectangle(14, 36, 194, 28));
        btnequal.setBounds(new Rectangle(114, 174, 44, 30));
        btnequal.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnequal.setText("=");
        btnequal.setForeground(Color.red);
        btnequal.addActionListener(
            new CalculatorFrame_btnequal_actionAdapter(this));
        btn1.setBounds(new Rectangle(15, 141, 44, 30));
        btn1.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn1.setText("1");
        btn1.addActionListener(new CalculatorFrame_btn1_actionAdapter(this));
        btn4.setBounds(new Rectangle(14, 108, 45, 30));
        btn4.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn4.setText("4");
        btn4.addActionListener(new CalculatorFrame_btn4_actionAdapter(this));
        btn7.setBounds(new Rectangle(15, 74, 44, 30));
        btn7.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btn7.setText("7");
        btn7.addActionListener(new CalculatorFrame_btn7_actionAdapter(this));
        btnclear.setBounds(new Rectangle(64, 175, 44, 30));
        btnclear.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btnclear.setText("C");
        btnclear.setForeground(Color.red);
        btnclear.addActionListener(
            new CalculatorFrame_btnclear_actionAdapter(this));
        btndivide.setBounds(new Rectangle(163, 73, 44, 30));
        btndivide.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        btndivide.setText("/");
        btndivide.setForeground(Color.red);
        btndivide.addActionListener(
            new CalculatorFrame_btndivide_actionAdapter(this));
        contentPane.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
        contentPane.add(txtresult, null);
        contentPane.add(btn8, null);
        contentPane.add(btn7, null);
        contentPane.add(btn9, null);
        contentPane.add(btn5, null);
        contentPane.add(btnmultiply, null);
        contentPane.add(btn1, null);
        contentPane.add(btn2, null);
        contentPane.add(btnminus, null);
        contentPane.add(btn0, null);
        contentPane.add(btndivide);
        contentPane.add(btn4, null);
        contentPane.add(btn3, null);
        contentPane.add(btnequal, null);
        contentPane.add(btnplus, null);
        contentPane.add(btn6, null);
        contentPane.add(btnclear, null);
        contentPane.add(btn4, null);

        contentPane.add(btndivide);
        contentPane.add(btn4, null);
    }

    /**
     * btn1_actionPerformed
     * @param e ActionEvent
     */
    public void btn1_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn1.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn1.getActionCommand());
        }

    }

    /**
     * btn2_actionPerformed
     * @param e ActionEvent
     */
    public void btn2_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn2.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn2.getActionCommand());
        }

    }

    /**
     * btn3_actionPerformed
     * @param e ActionEvent
     */
    public void btn3_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn3.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn3.getActionCommand());
        }

    }

    /**
     * btn4_actionPerformed
     * @param e ActionEvent
     */
    public void btn4_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn4.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn4.getActionCommand());
        }

    }

    /**
     * btn5_actionPerformed
     * @param e ActionEvent
     */
    public void btn5_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn5.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn5.getActionCommand());
        }
    }

    /**
     * btn6_actionPerformed
     * @param e ActionEvent
     */
    public void btn6_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn6.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn6.getActionCommand());
        }

    }

    /**
     * btn7_actionPerformed
     * @param e ActionEvent
     */
    public void btn7_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn7.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn7.getActionCommand());
        }
    }

    /**
     * btn8_actionPerformed
     * @param e ActionEvent
     */
    public void btn8_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn8.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn8.getActionCommand());

        }
    }

    /**
     * btn9_actionPerformed
     * @param e ActionEvent
     */
    public void btn9_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn9.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn9.getActionCommand());
        }
    }

    /**
     * btn0_actionPerformed
     * @param e ActionEvent
     */
    public void btn0_actionPerformed(ActionEvent e) {
        if (flag) {
            txtresult.setText(btn0.getActionCommand());
            flag = false;
        } else {
            txtresult.setText(txtresult.getText() + btn0.getActionCommand());
        }
    }

    /**
     * btnplus_actionPerformed
     * @param e ActionEvent
     */
    public void btnplus_actionPerformed(ActionEvent e) {
        operand1 = txtresult.getText();
        action = "plus";
        flag = true;
    }

    /**
     * btnequal_actionPerformed
     * @param e ActionEvent
     */
    public void btnequal_actionPerformed(ActionEvent e) {
        double digit1;
        double digit2;
        operand2 = txtresult.getText();
        if (!flag) {
            if (action.equals("divide")) {
                digit1 = Integer.parseInt(operand1);
                digit2 = Integer.parseInt(operand2);
                result = digit1 / digit2;
                txtresult.setText(new Double(result).toString());
                flag = true;
            } else if (action.equals("plus")) {
                digit1 = Double.parseDouble(operand1);
                digit2 = Double.parseDouble(operand2);
                result = digit1 + digit2;
                txtresult.setText("" + (int) result);
                flag = true;
            } else if (action.equals("multiply")) {
                digit1 = Double.parseDouble(operand1);
                digit2 = Double.parseDouble(operand2);
                result = digit1 * digit2;
                txtresult.setText("" + (int) result);
                flag = true;
            } else if (action.equals("minus")) {
                digit1 = Double.parseDouble(operand1);
                digit2 = Double.parseDouble(operand2);
                result = digit1 - digit2;
                txtresult.setText("" + (int) result);
                flag = true;
            }

        }
    }

    /**
     * btndivide_actionPerformed
     * @param e ActionEvent
     */
    public void btndivide_actionPerformed(ActionEvent e) {
        action = "divide";
        operand1 = txtresult.getText();
        txtresult.setText("");
        flag = true;
    }

    /**
     * btnclear_actionPerformed
     * @param e ActionEvent
     */
    public void btnclear_actionPerformed(ActionEvent e) {
        txtresult.setText("");
    }

    /**
     * btnminus_actionPerformed
     * @param e ActionEvent
     */
    public void btnminus_actionPerformed(ActionEvent e) {
        action = "minus";
        operand1 = txtresult.getText();
        txtresult.setText("");
        flag = true;
    }

    /**
     * btnmultiply_actionPerformed
     * @param e ActionEvent
     */
    public void btnmultiply_actionPerformed(ActionEvent e) {
        action = "multiply";
        operand1 = txtresult.getText();
        flag = true;
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btnminus_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     * CalculatorFrame_btnminus_actionAdapter
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btnminus_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnminus_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btndivide_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     * CalculatorFrame_btndivide_actionAdapter
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btndivide_actionAdapter(CalculatorFrame adaptee) {
        /**
         * adaptee
         */
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btndivide_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btnequal_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     * CalculatorFrame_btnequal_actionAdapter
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btnequal_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnequal_actionPerformed(e);
    }
}

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btnmultiply_actionAdapter implements ActionListener {
        /**
         * adaptee
         */
        private CalculatorFrame adaptee;
        /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btnmultiply_actionAdapter(CalculatorFrame adaptee) {
    this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
    adaptee.btnmultiply_actionPerformed(e);
    }
}

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btnclear_actionAdapter implements ActionListener {
        /**
         * adaptee
         */
        private CalculatorFrame adaptee;
        /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btnclear_actionAdapter(CalculatorFrame adaptee) {
    this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
    adaptee.btnclear_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btnplus_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btnplus_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnplus_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn0_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn0_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn0_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn9_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn9_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn9_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn8_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn8_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn8_actionPerformed(e);
    }
}


/**
 *
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn7_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn7_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn7_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn6_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn6_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn6_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: This class will demonstrate the swing components.</p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn5_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn5_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn5_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn4_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     * CalculatorFrame_btn4_actionAdapter
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn4_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn4_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn3_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     * CalculatorFrame_btn3_actionAdapter
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn3_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn3_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn2_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn2_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn2_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>
 *
 * <p>Description: This class will demonstrate the swing components.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael
 * @version 1.0
 */
class CalculatorFrame_btn1_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private CalculatorFrame adaptee;
    /**
     *
     * @param adaptee CalculatorFrame
     */
    CalculatorFrame_btn1_actionAdapter(CalculatorFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btn1_actionPerformed(e);
    }
}
