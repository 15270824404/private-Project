package multiplepanels;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.Color;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class MultiplePaenlsFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * pnlRed
     */
    JPanel pnlRed = new JPanel();
    /**
     * pnlBlue
     */
    JPanel pnlBlue = new JPanel();
    /**
     * btnRed
     */
    JButton btnRed = new JButton();
    /**
     * btnBlue
     */
    JButton btnBlue = new JButton();
    /**
     * borderLayout1
     */
    BorderLayout borderLayout1 = new BorderLayout();
    /**
     * jPanel1
     */
    JPanel jPanel1 = new JPanel();
    /**
     * jPanel2
     */
    JPanel jPanel2 = new JPanel();
    /**
     * borderLayout2
     */
    BorderLayout borderLayout2 = new BorderLayout();
    /**
     * pnlGreen
     */
    JPanel pnlGreen = new JPanel();
    /**
     * jPanel4
     */
    JPanel jPanel4 = new JPanel();
    /**
     * btnGreen
     */
    JButton btnGreen = new JButton();
    /**
     * pnlBlack
     */
    JPanel pnlBlack = new JPanel();
    /**
     * btnBlack
     */
    JButton btnBlack = new JButton();
    /**
     * MultiplePaenlsFrame
     */
    public MultiplePaenlsFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setSize(new Dimension(400, 300));
        setTitle("���");
        btnRed.setFont(new java.awt.Font("����", Font.PLAIN, 14));
        btnRed.setText("��ɫ");
        btnRed.addActionListener(
            new MultiplePaenlsFrame_btnRed_actionAdapter(this));
        btnBlue.setBounds(new Rectangle(95, 87, 64, 27));
        btnBlue.setFont(new java.awt.Font("����", Font.PLAIN, 14));
        btnBlue.setText("��ɫ");
        btnBlue.addActionListener(
            new MultiplePaenlsFrame_btnBlue_actionAdapter(this));
        jPanel2.setLayout(borderLayout2);
        btnGreen.setFont(new java.awt.Font("����", Font.PLAIN, 14));
        btnGreen.setText("��ɫ");
        btnGreen.addActionListener(
            new  MultiplePaenlsFrame_btnGreen_actionAdapter(this));
        btnBlack.setFont(new java.awt.Font("����", Font.PLAIN, 14));
        btnBlack.setText("��ɫ");
        btnBlack.addActionListener(
            new MultiplePaenlsFrame_btnWhite_actionAdapter(this));
        pnlBlue.setLayout(null);
        pnlBlue.add(pnlBlack);
        pnlBlack.add(btnBlack);
        contentPane.add(pnlRed, java.awt.BorderLayout.SOUTH);
        pnlRed.add(btnRed);
        pnlGreen.add(btnGreen);
        contentPane.add(pnlGreen, java.awt.BorderLayout.WEST);
        contentPane.add(pnlBlue, java.awt.BorderLayout.CENTER);
        pnlBlue.add(btnBlue);

        contentPane.add(pnlBlack, java.awt.BorderLayout.NORTH);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnRed_actionPerformed(ActionEvent e) {
        pnlRed.setBackground(Color.RED);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnBlue_actionPerformed(ActionEvent e) {
        pnlBlue.setBackground(Color.BLUE);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnGreen_actionPerformed(ActionEvent e) {
        pnlGreen.setBackground(Color.GREEN);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnWhite_actionPerformed(ActionEvent e) {
        pnlBlack.setBackground(Color.BLACK);
    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: </p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author not attributable
 * @version 1.0
 */
class MultiplePaenlsFrame_btnWhite_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private MultiplePaenlsFrame adaptee;
    /**
     *
     * @param adaptee MultiplePaenlsFrame
     */
    MultiplePaenlsFrame_btnWhite_actionAdapter(MultiplePaenlsFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnWhite_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: </p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author not attributable
 * @version 1.0
 */
class MultiplePaenlsFrame_btnGreen_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private MultiplePaenlsFrame adaptee;
    /**
     * MultiplePaenlsFrame_btnGreen_actionAdapter
     * @param adaptee MultiplePaenlsFrame
     */
    MultiplePaenlsFrame_btnGreen_actionAdapter(MultiplePaenlsFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnGreen_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: </p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author not attributable
 * @version 1.0
 */
class MultiplePaenlsFrame_btnBlue_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private MultiplePaenlsFrame adaptee;
    /**
     *
     * @param adaptee MultiplePaenlsFrame
     */
    MultiplePaenlsFrame_btnBlue_actionAdapter(MultiplePaenlsFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnBlue_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: </p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author not attributable
 * @version 1.0
 */
class MultiplePaenlsFrame_btnRed_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private MultiplePaenlsFrame adaptee;
    /**
     *
     * @param adaptee MultiplePaenlsFrame
     */
    MultiplePaenlsFrame_btnRed_actionAdapter(MultiplePaenlsFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnRed_actionPerformed(e);
    }
}
