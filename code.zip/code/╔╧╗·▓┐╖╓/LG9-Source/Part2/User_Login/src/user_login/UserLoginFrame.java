package user_login;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.Color;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michael Clarke
 * @version 1.0
 */
public class UserLoginFrame extends JFrame {
    /**
     * contentPane
     */
    JPanel contentPane;
    /**
     * txtUserName
     */
    JTextField txtUserName = new JTextField();
    /**
     * btnOk
     */
    JButton btnOk = new JButton();
    /**
     * lblUserName
     */
    JLabel lblUserName = new JLabel();
    /**
     * txtPassword
     */
    JTextField txtPassword = new JTextField();
    /**
     * btnCancel
     */
    JButton btnCancel = new JButton();
    /**
     * lblPassword
     */
    JLabel lblPassword = new JLabel();
    /**
     * lblresult
     */
    JLabel lblresult = new JLabel();
    /**
     * UserLoginFrame
     */
    public UserLoginFrame() {
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception e
     */
    private void jbInit() throws Exception {

        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(null);
        setSize(new Dimension(400, 250));
        setTitle("��½");
        txtUserName.setFont(new java.awt.Font("Serif", Font.PLAIN, 14));
        txtUserName.setBounds(new Rectangle(141, 56, 126, 25));
        txtUserName.addActionListener(
                new UserLoginFrame_txtUserName_actionAdapter(this));
        btnOk.setBounds(new Rectangle(140, 137, 63, 22));
        btnOk.setText("ȷ��");
        btnOk.addActionListener(
            new UserLoginFrame_jButton1_actionAdapter(this));
        lblUserName.setFont(new java.awt.Font("Serif", Font.PLAIN, 14));
        lblUserName.setText("�û�");
        lblUserName.setFont(new java.awt.Font("Serif", Font.PLAIN, 14));
        lblUserName.setBounds(new Rectangle(87, 47, 46, 49));
        txtPassword.setFont(new java.awt.Font("Serif", Font.PLAIN, 14));
        txtPassword.setBounds(new Rectangle(141, 96, 126, 23));
        btnCancel.setBounds(new Rectangle(207, 136, 62, 22));
        btnCancel.setFont(new java.awt.Font("Serif", Font.PLAIN, 14));
        btnCancel.setText("ȡ��");
        btnCancel.addActionListener(
                new UserLoginFrame_btnCancel_actionAdapter(this));
        lblPassword.setText("����");
        lblPassword.setFont(new java.awt.Font("Serif", Font.PLAIN, 14));
        lblPassword.setBounds(new Rectangle(88, 94, 35, 33));
        lblresult.setFont(new java.awt.Font("Serif", Font.PLAIN, 20));
        lblresult.setForeground(Color.red);
        lblresult.setText("");
        lblresult.setHorizontalAlignment(JLabel.CENTER);
        lblresult.setBounds(new Rectangle(37, 14, 327, 29));
        contentPane.add(txtUserName);
        contentPane.add(txtPassword);
        contentPane.add(lblUserName);
        contentPane.add(lblPassword);
        contentPane.add(btnCancel);
        contentPane.add(btnOk);
        contentPane.add(lblresult);
        contentPane.add(btnOk);
        btnOk.setFont(new java.awt.Font("Serif", Font.PLAIN, 14));
    }

    /**
     * btnOk_actionPerformed
     * @param e ActionEvent
     */
    public void btnOk_actionPerformed(ActionEvent e) {
        String user;
        String password;
        user = txtUserName.getText();
        password = txtPassword.getText();
        if (user.equals("admin") && password.equals("aptech")) {
            lblresult.setText("          ��֤ͨ����");
        } else {
            lblresult.setText("�Ƿ����û��������룡");
            txtUserName.setText("");
            txtPassword.setText("");
            txtUserName.setFocusable(true);
        }

    }

    /**
     *
     * @param e ActionEvent
     */
    public void btnCancel_actionPerformed(ActionEvent e) {
        System.exit(0);
    }

    /**
     *
     * @param e ActionEvent
     */
    public void txtUserName_actionPerformed(ActionEvent e) {

    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: </p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author not attributable
 * @version 1.0
 */
class UserLoginFrame_txtUserName_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private UserLoginFrame adaptee;
    /**
     * UserLoginFrame_txtUserName_actionAdapter
     * @param adaptee UserLoginFrame
     */
    UserLoginFrame_txtUserName_actionAdapter(UserLoginFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.txtUserName_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: </p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author not attributable
 * @version 1.0
 */
class UserLoginFrame_btnCancel_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private UserLoginFrame adaptee;
    /**
     * UserLoginFrame_btnCancel_actionAdapter
     * @param adaptee UserLoginFrame
     */
    UserLoginFrame_btnCancel_actionAdapter(UserLoginFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnCancel_actionPerformed(e);
    }
}


/**
 *
 * <p>Title: </p>  *
 * <p>Description: </p>  *
 * <p>Copyright: Copyright (c) 2005</p>  *
 * <p>Company: </p> *
 * @author not attributable
 * @version 1.0
 */
class UserLoginFrame_jButton1_actionAdapter implements ActionListener {
    /**
     * adaptee
     */
    private UserLoginFrame adaptee;
    /**
     * UserLoginFrame_jButton1_actionAdapter
     * @param adaptee UserLoginFrame
     */
    UserLoginFrame_jButton1_actionAdapter(UserLoginFrame adaptee) {
        this.adaptee = adaptee;
    }

    /**
     * actionPerformed
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        adaptee.btnOk_actionPerformed(e);
    }
}
