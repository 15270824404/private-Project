$(document).ready(show);
var year,month;
function show(){
	year = document.getElementById("year").value;
	month =  document.getElementById("month").value;
	if(year == ''){
		alert('请选择年份');
	}else if(month == ''){
		alert('请选择月份');
	}else
		$.getJSON("../statictics.do?commend=showPic&year="+year+"&month="+month,null,callback);
}

function callback(data){
	var objectType=eval(data);
	document.getElementById("img").src=objectType[0]["name"];
}

function get(){
	year = document.getElementById("year").value;
	month =  document.getElementById("month").value;
	if(year == ''){
		alert('请选择年份');
	}else if(month == ''){
		alert('请选择月份');
	}else{
		location="../statictics.do?commend=addInterview&year="+year+"&month="+month;
	}
}
