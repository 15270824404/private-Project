package com.info.dao;

import java.util.List;

import com.info.pojo.User;

public interface UserDao {
	public List<User> getUserAll();
	public List<User> getUserGroup(String group,String name);
	public User getUserById(int id);
	public List<String> getUserGroups();
	public User addUser(User user);
	public User updateUserById(User user);
	public void deleteUserById(int id);
	
}
