package com.info.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.info.dao.UserDao;
import com.info.pojo.User;
import com.info.util.DBUtil;

public class UserDao4MysqlImpl implements UserDao {

	public List<User> getUserAll() {
		// TODO Auto-generated method stub
		List<User> users = new ArrayList<User>();		
		User user = null;
			Connection conn=DBUtil.getConn();
			PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from UserInfo");
			ResultSet rs=null;
			try {				
				rs=DBUtil.getRs(pstmt);
				while(rs.next()){
					user=new User();
					user.setAddress(rs.getString("address"));
					user.setDateBirth(rs.getString("dateBirth"));
					user.setEmail(rs.getString("email"));
					user.setGroups(rs.getString("groups"));
					user.setId(rs.getInt("id"));
					user.setIdCard(rs.getString("idCard"));
					user.setName(rs.getString("name"));
					user.setNation(rs.getString("nation"));
					user.setOther(rs.getString("other"));
					user.setPhone(rs.getString("phone"));
					user.setSex(rs.getString("sex"));						
					users.add(user);					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				DBUtil.getClose(conn, pstmt, rs);
			}
			
			return users;
	}
	public List<String> getUserGroups() {
		// TODO Auto-generated method stub
		List<String> users = new ArrayList<String>();		
			Connection conn=DBUtil.getConn();
			PreparedStatement pstmt=DBUtil.getPstmt(conn, "select distinct groups from UserInfo;");
			ResultSet rs=null;
			try {				
				rs=DBUtil.getRs(pstmt);
				while(rs.next()){
					users.add(rs.getString("groups"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}finally {
				DBUtil.getClose(conn, pstmt, rs);
		}
return users;
}
				
	public List<User> getUserGroup(String group, String name) {
		List<User> users = new ArrayList<User>();
		User user = null;
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		try{
		if("".equals(group) && !"".equals(name)){
				pstmt = DBUtil.getPstmt(conn,"select * from UserInfo where name like ?");
				pstmt.setString(1,name);
		}else if(!"".equals(group) && "".equals(name)){
			pstmt = DBUtil.getPstmt(conn,"select * from UserInfo where groups=?");
			pstmt.setString(1,group);
			System.out.println(group);
		}else if("".equals(group) && "".equals(name)){
			pstmt = DBUtil.getPstmt(conn,"select * from UserInfo");
		}
		else{
			pstmt = DBUtil.getPstmt(conn,"select * from UserInfo where name like ? and groups=?");
			pstmt.setString(1,name);
			pstmt.setString(2,group);
		}
			//pstmt.setInt(1, user.getId());
		rs = DBUtil.getRs(pstmt);
		while(rs.next()){
			user=new User();
			user.setAddress(rs.getString("address"));
			user.setDateBirth(rs.getString("dateBirth"));
			user.setEmail(rs.getString("email"));
			user.setGroups(rs.getString("groups"));
			user.setId(rs.getInt("id"));
			user.setIdCard(rs.getString("idCard"));
			user.setName(rs.getString("name"));
			user.setNation(rs.getString("nation"));
			user.setOther(rs.getString("other"));
			user.setPhone(rs.getString("phone"));
			user.setSex(rs.getString("sex"));						
			users.add(user);					
		}			  
				} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				}finally {
						DBUtil.getClose(conn, pstmt, rs);
				}
		return users;
	}

	public User addUser(User user) {
		// TODO Auto-generated method stub		
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"insert into UserInfo values(null,?,?,?,?,?,?,?,?,?,?)");		
		try { 			
			 pstmt.setString(1,user.getName());
			 pstmt.setString(2, user.getSex());
			 pstmt.setString(3, user.getEmail());
			 pstmt.setString(4, user.getDateBirth());
			 pstmt.setString(5, user.getNation());
			 pstmt.setString(6, user.getAddress());
			 pstmt.setString(7, user.getPhone());
			 pstmt.setString(8, user.getIdCard());
			 pstmt.setString(9, user.getOther());
			 pstmt.setString(10, user.getGroups());
			  pstmt.executeUpdate();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally {
						DBUtil.getClose(conn, pstmt, null);
					}
		return user;
	}

	public User updateUserById(User user) {
		// TODO Auto-generated method stub		
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"update UserInfo set name=?,sex=?,email=?,dateBirth=?,nation=?,address=?,phone=?,idCard=?" +
				"other=?,groups=? where id=? ");		
		try { 			
			 pstmt.setString(1,user.getName());
			 pstmt.setString(2, user.getSex());
			 pstmt.setString(3, user.getEmail());
			 pstmt.setString(4, user.getDateBirth());
			 pstmt.setString(5, user.getNation());
			 pstmt.setString(6, user.getAddress());
			 pstmt.setString(7, user.getPhone());
			 pstmt.setString(8, user.getIdCard());
			 pstmt.setString(9, user.getOther());
			 pstmt.setString(10, user.getGroups());
			 pstmt.setInt(11, user.getId());
			  pstmt.executeUpdate();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally {
						DBUtil.getClose(conn, pstmt, null);
					}
		return user;
	}

	public void deleteUserById(int id) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"delete from UserInfo where id=?");
		try {
			pstmt.setInt(1,id);
			
	        pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
	}
	public User getUserById(int id) {				
		User user = null;
			Connection conn=DBUtil.getConn();
			PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from UserInfo where id=?");
			ResultSet rs=null;
			try {	
				pstmt.setInt(1, id);
				rs=DBUtil.getRs(pstmt);
				while(rs.next()){
					user=new User();
					user.setAddress(rs.getString("address"));
					user.setDateBirth(rs.getString("dateBirth"));
					user.setEmail(rs.getString("email"));
					user.setGroups(rs.getString("groups"));
					user.setId(rs.getInt("id"));
					user.setIdCard(rs.getString("idCard"));
					user.setName(rs.getString("name"));
					user.setNation(rs.getString("nation"));
					user.setOther(rs.getString("other"));
					user.setPhone(rs.getString("phone"));
					user.setSex(rs.getString("sex"));					
										
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				DBUtil.getClose(conn, pstmt, rs);
			}
			
			return user;
	}
	
}
