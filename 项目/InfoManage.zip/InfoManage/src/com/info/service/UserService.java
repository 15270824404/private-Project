package com.info.service;

import java.util.List;

import com.info.pojo.User;

public interface UserService {
	public List<User> showUserAll();
	public List<User> showUserGroup(String group,String name);
	public User showUserById(int id);
	public List<String> showUserGroups();
	public User insertUser(User user);
	public User alertUserById(User user);
	public void dropUserById(int id);
}
