package com.info.service.impl;

import java.util.List;

import com.info.dao.UserDao;
import com.info.dao.impl.UserDao4MysqlImpl;
import com.info.pojo.User;
import com.info.service.UserService;

public class UserServiceImpl implements UserService {
	private static UserService  userService =new UserServiceImpl(); //接口
    private UserDao userDao = new UserDao4MysqlImpl();    
    private UserServiceImpl(){}    
    public static UserService getInstance(){
		return userService;    	
    }

	public List<User> showUserAll() {
		// TODO Auto-generated method stub
		
		return userDao.getUserAll();
	}

	public List<User> showUserGroup(String group, String name) {
		// TODO Auto-generated method stub
		return userDao.getUserGroup(group, name);
	}

	public User insertUser(User user) {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}

	public User alertUserById(User user) {
		// TODO Auto-generated method stub
		return userDao.updateUserById(user);
	}

	public void dropUserById(int id) {
		// TODO Auto-generated method stub
		userDao.deleteUserById(id);
	}
	public List<String> showUserGroups() {
		// TODO Auto-generated method stub
		return userDao.getUserGroups();
	}
	public User showUserById(int id) {
		// TODO Auto-generated method stub
		return userDao.getUserById(id);
	}

}
