package com.info.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.info.pojo.User;
import com.info.service.impl.UserServiceImpl;

public class DeleteUserServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
           int id  = Integer.parseInt(request.getParameter("id"));
           UserServiceImpl.getInstance().dropUserById(id);
           List<User> users = UserServiceImpl.getInstance().showUserAll();	
			List<String> strs = UserServiceImpl.getInstance().showUserGroups();
			request.setAttribute("users", users);
			request.setAttribute("strs", strs);	
           request.getRequestDispatcher("getUser.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
