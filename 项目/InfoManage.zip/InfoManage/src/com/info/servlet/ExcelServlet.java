package com.info.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.info.pojo.User;
import com.info.service.impl.UserServiceImpl;

public class ExcelServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		User user = UserServiceImpl.getInstance().showUserById(id);
		HSSFWorkbook workBook = new HSSFWorkbook(); 
		//新建一个空工作簿
		HSSFSheet sheet1 = workBook.createSheet();
		
		//创建工作单元 1 2
		HSSFRow row1 = sheet1.createRow(0);				
		HSSFRow row2 = sheet1.createRow(1);	
	    //创建一行	
		HSSFCell cell00 = row1.createCell(0); 
		HSSFCell cell01 = row1.createCell(1); 
		HSSFCell cell02 = row1.createCell(2);
		HSSFCell cell03 = row1.createCell(3);
		HSSFCell cell04 = row1.createCell(4);
		HSSFCell cell05 = row1.createCell(5);
		HSSFCell cell06 = row1.createCell(6);
		HSSFCell cell07 = row1.createCell(7);
		HSSFCell cell08 = row1.createCell(8);
		
		HSSFCell cell10 = row2.createCell(0); 
		HSSFCell cell11 = row2.createCell(1); 
		HSSFCell cell12 = row2.createCell(2);
		HSSFCell cell13 = row2.createCell(3);
		HSSFCell cell14 = row2.createCell(4);
		HSSFCell cell15 = row2.createCell(5);
		HSSFCell cell16 = row2.createCell(6);
		HSSFCell cell17 = row2.createCell(7);
		HSSFCell cell18 = row2.createCell(8);
		//创建一格
		
		cell00.setCellValue("群组");
		cell01.setCellValue("姓名");
		cell02.setCellValue("性别");
		cell03.setCellValue("民族");
		cell04.setCellValue("籍贯");
		cell05.setCellValue("出生日期");
		cell06.setCellValue("手机号码");
		cell07.setCellValue("身份证");
		cell08.setCellValue("备注");
		

		cell10.setCellValue(user.getGroups());
		cell11.setCellValue(user.getName());
		cell12.setCellValue(user.getSex());
		cell13.setCellValue(user.getNation());
		cell14.setCellValue(user.getAddress());
		cell15.setCellValue(user.getDateBirth());
		cell16.setCellValue(user.getPhone());
		cell17.setCellValue(user.getIdCard());
		cell18.setCellValue(user.getOther());	
						
		FileOutputStream fos = null; 
		try {//FileOutputStream创建文件存储文件
			File file = new File("D:\\a.xls");
			if(file.exists()){
				file.delete();
			}
			fos = new FileOutputStream("D:\\a.xls");
			workBook.write(fos);//将流写入进去
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				fos.flush();
				fos.close();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
		request.getRequestDispatcher("getUser.jsp").forward(request, response);
		}

}
