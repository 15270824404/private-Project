package com.info.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.info.pojo.User;
import com.info.service.impl.UserServiceImpl;

public class UpdateUserByUserServlet extends HttpServlet {


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String group = request.getParameter("groups");
		String name = request.getParameter("name");
		String nation = request.getParameter("nation");
		String sex = request.getParameter("sex");		
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String dateBirth = request.getParameter("dateBirth");
		String idCard = request.getParameter("idCard");
		String address = request.getParameter("address");
		String other = request.getParameter("other");
		User user = new User();
		user.setAddress(address);
		user.setDateBirth(dateBirth);
		user.setEmail(email);
		user.setIdCard(idCard);
		user.setName(name);
		user.setNation(nation);
		user.setOther(other);
		user.setPhone(phone);
		user.setSex(sex);		
		user.setGroups(group);		
		UserServiceImpl.getInstance().alertUserById(user);		
		request.setAttribute("user", user);
		List<String> strs = UserServiceImpl.getInstance().showUserGroups();
		request.setAttribute("strs", strs);	
		 request.getRequestDispatcher("updateUser.jsp").forward(request, response);
	}

}
