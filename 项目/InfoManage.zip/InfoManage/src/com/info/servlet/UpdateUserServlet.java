package com.info.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.info.pojo.User;
import com.info.service.impl.UserServiceImpl;

public class UpdateUserServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			int id = Integer.parseInt(request.getParameter("id"));
		    User user = UserServiceImpl.getInstance().showUserById(id);
		    request.setAttribute("user", user);
		    request.getRequestDispatcher("updateUser.jsp").forward(request, response);
	}

}
