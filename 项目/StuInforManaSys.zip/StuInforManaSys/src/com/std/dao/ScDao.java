package com.std.dao;

import java.util.List;

import com.std.pojo.Sc;

public interface ScDao {
	public List<Sc> getScById(String tirm,String std_id);
	public  List<Sc> getScByStd(String tirm,String std_colleage,String std_professional,int std_class);
	public void upScInfoByStd_id(String std_id, String cname, String required, String grade,
			int ccedit, String cgrade,String ccgrade);
	public Sc SaveScInfoByStd_id(String trim,String std_id, String cname, String required, String grade,
			int ccedit, String cgrade,String ccgrade);
}
