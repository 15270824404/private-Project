package com.std.dao;

//import com.std.pojo.Manager;
import java.util.List;

import com.std.pojo.Std;

public interface StdDao {
	public Std Login(String username, String password);
	public Std findStdByStd_id(String Std_id);
	public void upOwdByStd_id(String std_id,String newPwd1);
	public void upStdInfoByStd_id(String std_id,String std_phone,String std_email,String std_idCard,String td_homePhone,String std_parent,String std_familyDetailedAddress);
	public List<Std> getStdById(String std_colleage, String std_professional,int std_class);
	public Std upStdByStd(Std std);
	public Std saveByStd(Std std); 
	public void removeStd(String std_id);
}
