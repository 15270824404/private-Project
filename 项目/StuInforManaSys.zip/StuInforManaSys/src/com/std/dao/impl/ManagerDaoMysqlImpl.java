package com.std.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.std.dao.ManagerDao;
import com.std.excption.PasswordErrorException;
import com.std.excption.UserfreezingException;
import com.std.excption.UsernameNotFoundException;
import com.std.pojo.Manager;
import com.std.util.DBUtil;

public class ManagerDaoMysqlImpl implements ManagerDao {
	
	

	
	
	public Manager Login(String username, String password) {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConn();
	      PreparedStatement pstmt = DBUtil.getPstmt(conn, "select password from t_manager where name=?");
	      ResultSet rs = null;       
	      try {
	         pstmt.setString(1, username);
	         rs =  DBUtil.getRs(pstmt);
	         if(rs.next()){
					if(!password.equals(rs.getString(1))){
						throw new PasswordErrorException();
					}
				}else{
					throw new UsernameNotFoundException();
				}
	         } catch (SQLException e) {
	   // TODO Auto-generated catch block
	     e.printStackTrace();
	     }finally{
	     DBUtil.getClose(conn, pstmt, rs);
	}
	      return this.findManager(username, password);
	}
	public Manager findManager(String username,String password) {
		Manager manager=null;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_manager where name=? and password=?");
		ResultSet rs=null;
		try {
			pstmt.setString(1,username);
			pstmt.setString(2,password);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				manager=new Manager();
				manager.setPassword(rs.getString("password"));
				manager.setName(rs.getString("name"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return manager;
	}   


}
