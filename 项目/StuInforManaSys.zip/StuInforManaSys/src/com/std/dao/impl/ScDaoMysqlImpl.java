package com.std.dao.impl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.std.dao.ScDao;
import com.std.dao.StdDao;
import com.std.pojo.Sc;
import com.std.pojo.Std;
import com.std.util.DBUtil;

public class ScDaoMysqlImpl implements ScDao {
	private static StdDao stdDao = new StdDaoMysqlImpl();

	public List<Sc> getScById(String tirm, String std_id) {
		// TODO Auto-generated method stub	
		List<Sc> scs = new ArrayList<Sc>();		
		Sc sc = null;
			Connection conn=DBUtil.getConn();
			PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_sc where term=? and std_id=?");
			ResultSet rs=null;
			try {
				pstmt.setString(1,tirm);
				pstmt.setString(2,std_id);
				rs=DBUtil.getRs(pstmt);
				while(rs.next()){
					sc = new Sc();					
					sc.setCcedit(rs.getInt("ccedit"));
					sc.setCcgrade(rs.getString("ccgrade"));
					sc.setCgrade(rs.getString("cgrade"));
					sc.setCname(rs.getString("cname"));
					sc.setGrade(rs.getString("grade"));
					sc.setId(rs.getInt("id"));
					sc.setRequired(rs.getString("required"));
					sc.setStd(stdDao.findStdByStd_id(std_id));
					sc.setTerm(rs.getString("term"));
					scs.add(sc);					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return scs;
		}
	
	public  List<Sc> getScByStd(String tirm,String std_colleage,String std_professional,int std_class) {
		// TODO Auto-generated method stub	
		List<Sc> scs = new ArrayList<Sc>();		
		Sc sc = null;
			Connection conn=DBUtil.getConn();
			List<Std> stds = stdDao.getStdById(std_colleage, std_professional, std_class);
//			List<Std> stds = stdDao.getStdById("软件学院", "软件工程", 1);
			for (Iterator<Std> iter = stds.iterator(); iter.hasNext();) {
				Std std = (Std) iter.next();
				PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_sc where term=? and std_id=?");
				ResultSet rs=null;
				try {
					pstmt.setString(1,tirm);
					pstmt.setString(2,std.getStd_id());
					rs=DBUtil.getRs(pstmt);
					while(rs.next()){
						sc = new Sc();					
						sc.setCcedit(rs.getInt("ccedit"));
						sc.setCcgrade(rs.getString("ccgrade"));
						sc.setCgrade(rs.getString("cgrade"));
						sc.setCname(rs.getString("cname"));
						sc.setGrade(rs.getString("grade"));
						sc.setId(rs.getInt("id"));
						sc.setRequired(rs.getString("required"));
						sc.setStd(stdDao.findStdByStd_id(std.getStd_id()));
						sc.setTerm(rs.getString("term"));
						scs.add(sc);					
					}} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}	
			return scs;
		}
	public void upScInfoByStd_id(String std_id, String cname, String required, String grade,
			int ccedit, String cgrade,String ccgrade) {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_sc set required=?,ccedit=?,grade=?,cgrade=?,ccgrade=? where std_id=? and cname=?");
		try {
			pstmt.setString(1, cname);
			pstmt.setString(2, required);
			pstmt.setInt(3, ccedit);
			pstmt.setString(4, grade);
			pstmt.setString(5, cgrade);
			pstmt.setString(6, ccgrade);
			pstmt.setString(7, std_id);
			pstmt.executeUpdate();	
//			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt,null);
		}
	}
		
		
		public Sc SaveScInfoByStd_id(String trim,String std_id, String cname, String required, String grade,
				int ccedit, String cgrade,String ccgrade) {
			// TODO Auto-generated method stub
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"insert into t_sc value(null,?,?,?,?,?,?,?,?)");
			try {
				pstmt.setString(1, trim);
				pstmt.setString(2, cname);
				pstmt.setString(3, required);
				pstmt.setInt(4, ccedit);
				pstmt.setString(5, grade);
				pstmt.setString(6, cgrade);
				pstmt.setString(7, ccgrade);
				pstmt.setString(8, std_id);
				pstmt.executeUpdate();	
//				pstmt.execute();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt,null);
			}
			Sc sc = new Sc();
			sc.setCcedit(ccedit);
			sc.setCcgrade(ccgrade);
			sc.setCgrade(cgrade);
			sc.setCname(cname);
			sc.setGrade(grade);
			sc.setRequired(required);
			sc.setTerm(trim);
			sc.setStd(stdDao.findStdByStd_id(std_id));
			return sc;
	}
}
//	public static void main(String[] args) {
//		List<Sc> scs = ScDaoMysqlImpl.getScByStd("","");
////		for (Iterator<Sc> iter = scs.iterator(); iter.hasNext();) {
////			Sc std = (Sc) iter.next();
////			if()
////			System.out.println(std.getStd().getStd_name()+"     "+ std.getCname());
////		}
//		List<Object> list = new ArrayList<Object>();
//		for (int i=0,listSize=scs.size() ; i<listSize ; i++){
//			//循环体
//			scs.get(0);
//			System.out.println(scs.get(i).getStd().getStd_id());
//			if(scs.get(i).getStd().getStd_id().equals(scs.get(i+1).getStd().getStd_id())){
//				list.add(e)
//			}
//			}
//	}
		


