package com.std.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.std.dao.StdDao;
import com.std.excption.PasswordErrorException;
import com.std.excption.UsernameNotFoundException;
import com.std.pojo.Manager;
import com.std.pojo.Sc;
import com.std.pojo.Std;
import com.std.util.DBUtil;

public class StdDaoMysqlImpl implements StdDao {
	public Std Login(String username, String password) {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConn();
	      PreparedStatement pstmt = DBUtil.getPstmt(conn, "select std_pwd from t_stuInfo where std_id=?");
	      ResultSet rs = null;       
	      try {
	         pstmt.setString(1, username);
	         rs =  DBUtil.getRs(pstmt);
	         if(rs.next()){
					if(!password.equals(rs.getString(1))){
						throw new PasswordErrorException();
					}
				}else{
					throw new UsernameNotFoundException();
				}
	         } catch (SQLException e) {
	   // TODO Auto-generated catch block
	     e.printStackTrace();
	     }finally{
	     DBUtil.getClose(conn, pstmt, rs);
	}
	      return this.findStdByStd_id(username);
	}
	public Std findStdByStd_id(String std_id) {
		Std std=null;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_stuInfo where std_id=?");
		ResultSet rs=null;
		try {
			pstmt.setString(1,std_id);
//			pstmt.setString(2,password);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				std=new Std();
				std.setStd_pwd(rs.getString("std_pwd"));
				std.setStd_id(rs.getString("std_id"));
				std.setStd_address(rs.getString("std_address"));
				std.setStd_bankAccount(rs.getString("std_bankAccount"));
				std.setStd_class(rs.getInt("std_class"));
				std.setStd_colleage(rs.getString("std_colleage"));
				std.setStd_computerLevel(rs.getString("std_computerLevel"));
				std.setStd_date(rs.getString("std_date"));
				std.setStd_dateBirth(rs.getString("std_dateBirth"));
				std.setStd_eduBg(rs.getString("std_eduBg"));				
				std.setStd_eduSys(rs.getString("std_eduSys"));
				std.setStd_email(rs.getString("std_email"));
				std.setStd_englishLevel(rs.getString("std_englishLevel"));
				std.setStd_familyDetailedAddress(rs.getString("std_familyDetailedAddress"));
				std.setStd_homePhone(rs.getString("std_homePhone"));
				std.setStd_idCard(rs.getString("std_idCard"));
				std.setStd_nation(rs.getString("std_nation"));
				std.setStd_other(rs.getString("std_other"));
				std.setStd_parent(rs.getString("std_parent"));
				std.setStd_phone(rs.getString("std_phone"));
				std.setStd_photo(rs.getString("std_photo"));
				std.setStd_policSta(rs.getString("std_policSta"));
				std.setStd_professional(rs.getString("std_professional"));
				std.setStd_sex(rs.getString("std_sex"));
				std.setStd_name(rs.getString("std_name"));				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return std;
	}
	public void upOwdByStd_id(String std_id,String newPwd) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_stuInfo set std_pwd=? where std_id=?");			
		
		try {
			pstmt.setString(2, std_id);
			pstmt.setString(1, newPwd);
			pstmt.executeUpdate();	
//			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt,null);
		}

	}
	public void upStdInfoByStd_id(String std_id, String std_phone,
			String std_email, String std_idCard, String std_homePhone,
			String std_parent, String std_familyDetailedAddress) {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_stuInfo set std_phone=?,std_email=?,std_idCard=?,std_homePhone=?,std_parent=?,std_familyDetailedAddress=? where std_id=?");
		try {
			pstmt.setString(1, std_phone);
			pstmt.setString(2, std_email);
			pstmt.setString(3, std_idCard);
			pstmt.setString(4, std_homePhone);
			pstmt.setString(5, std_parent);
			pstmt.setString(6, std_familyDetailedAddress);
			pstmt.setString(7, std_id);
			pstmt.executeUpdate();	
//			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt,null);
		}
	}
	
	public List<Std> getStdById(String std_colleage, String std_professional,int std_class) {
		// TODO Auto-generated method stub	
		List<Std> stds = new ArrayList<Std>();		
		Std std = null;
			Connection conn=DBUtil.getConn();
			PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_stuInfo where std_colleage=? and std_professional=? and std_class=?");
			ResultSet rs=null;
			try {
				pstmt.setString(1,std_colleage);
				pstmt.setString(2,std_professional);
				pstmt.setInt(3,std_class);
				rs=DBUtil.getRs(pstmt);
				while(rs.next()){
					std=new Std();
					std.setStd_pwd(rs.getString("std_pwd"));
					std.setStd_id(rs.getString("std_id"));
					std.setStd_address(rs.getString("std_address"));
					std.setStd_bankAccount(rs.getString("std_bankAccount"));
					std.setStd_class(rs.getInt("std_class"));
					std.setStd_colleage(rs.getString("std_colleage"));
					std.setStd_computerLevel(rs.getString("std_computerLevel"));
					std.setStd_date(rs.getString("std_date"));
					std.setStd_dateBirth(rs.getString("std_dateBirth"));
					std.setStd_eduBg(rs.getString("std_eduBg"));				
					std.setStd_eduSys(rs.getString("std_eduSys"));
					std.setStd_email(rs.getString("std_email"));
					std.setStd_englishLevel(rs.getString("std_englishLevel"));
					std.setStd_familyDetailedAddress(rs.getString("std_familyDetailedAddress"));
					std.setStd_homePhone(rs.getString("std_homePhone"));
					std.setStd_idCard(rs.getString("std_idCard"));
					std.setStd_nation(rs.getString("std_nation"));
					std.setStd_other(rs.getString("std_other"));
					std.setStd_parent(rs.getString("std_parent"));
					std.setStd_phone(rs.getString("std_phone"));
					std.setStd_photo(rs.getString("std_photo"));
					std.setStd_policSta(rs.getString("std_policSta"));
					std.setStd_professional(rs.getString("std_professional"));
					std.setStd_sex(rs.getString("std_sex"));
					std.setStd_name(rs.getString("std_name"));			
					stds.add(std);					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return stds;
		}
	public Std upStdByStd(Std std) {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_stuInfo set std_name=?,std_sex=?, std_photo=?,std_email=?," +
				"std_dateBirth=?, std_nation=?, std_policSta=?, std_address=?,  std_colleage=?,std_professional=?,  " +
				"std_class=?,std_bankAccount=?,std_eduBg=?,std_eduSys=?,std_englishLevel=?,std_phone=?,std_idCard=?," +
				"std_familyDetailedAddress=?,std_homePhone=?,std_parent=?,std_date=? where std_id=?");			
		
		try {
			pstmt.setString(1, std.getStd_name());
			pstmt.setString(2, std.getStd_sex());
			pstmt.setString(3, std.getStd_photo());
			pstmt.setString(4, std.getStd_email());
			pstmt.setString(5, std.getStd_dateBirth());
			pstmt.setString(6, std.getStd_nation());
			pstmt.setString(7, std.getStd_policSta());
			pstmt.setString(8, std.getStd_address());
			pstmt.setString(9, std.getStd_colleage());
			pstmt.setString(10, std.getStd_professional());
			pstmt.setInt(11, std.getStd_class());
			pstmt.setString(12, std.getStd_bankAccount());
			pstmt.setString(13, std.getStd_eduBg());
			pstmt.setString(14, std.getStd_eduSys());
			pstmt.setString(15, std.getStd_englishLevel());
			pstmt.setString(16, std.getStd_phone());
			pstmt.setString(17, std.getStd_idCard());
			pstmt.setString(18, std.getStd_familyDetailedAddress());
			pstmt.setString(19, std.getStd_homePhone());
			pstmt.setString(20, std.getStd_parent());
			pstmt.setString(21, std.getStd_date());

			pstmt.setString(22, std.getStd_id());
			pstmt.executeUpdate();	
//			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt,null);
		}
		return std;
	}
	public Std saveByStd(Std std) {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"insert into t_stuInfo value(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		try { 
			//pstmt.setInt(1, user.getId());
			pstmt.setString(1,std.getStd_id());
			pstmt.setString(2,std.getStd_pwd());
			pstmt.setString(3,std.getStd_name());
			pstmt.setString(4,std.getStd_sex());
			pstmt.setString(5,std.getStd_photo());
			pstmt.setString(6,std.getStd_email());				
			pstmt.setString(7,std.getStd_dateBirth());
		
			pstmt.setString(8,std.getStd_nation());
			pstmt.setString(9,std.getStd_policSta());
			pstmt.setString(10,std.getStd_address());
			pstmt.setString(11,std.getStd_colleage());
			pstmt.setString(12,std.getStd_professional());
			pstmt.setInt(13,std.getStd_class());
			pstmt.setString(14,std.getStd_bankAccount());
			pstmt.setString(15,std.getStd_eduBg());
			pstmt.setString(16,std.getStd_eduSys());
			pstmt.setString(17,std.getStd_englishLevel());
			pstmt.setString(18,std.getStd_computerLevel());
			pstmt.setString(19,std.getStd_phone());
			pstmt.setString(20,std.getStd_idCard());
			pstmt.setString(21,std.getStd_familyDetailedAddress());
			pstmt.setString(22,std.getStd_homePhone());
			pstmt.setString(23, std.getStd_parent());
			pstmt.setString(24,std.getStd_date());
			pstmt.setString(25,std.getStd_other());		    
		    pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.getClose(conn, pstmt, null);
		}
		return std;
	}
	public void removeStd(String std_id) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"delete from t_stuInfo where std_id=?");
		try {
			pstmt.setString(1,std_id);
			
	        pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
		
	}
	
}