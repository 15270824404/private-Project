package com.std.excption;

public class PasswordErrorException extends RuntimeException {

}
