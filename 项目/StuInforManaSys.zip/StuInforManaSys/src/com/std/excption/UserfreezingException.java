package com.std.excption;

public class UserfreezingException extends RuntimeException {

}
