package com.std.excption;

public class UsernameNotFoundException extends RuntimeException {

}
