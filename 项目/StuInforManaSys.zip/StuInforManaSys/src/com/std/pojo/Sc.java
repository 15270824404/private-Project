package com.std.pojo;

public class Sc {
	  private int id;
	  private String term;//#学期 1201 12年第一个学期
	  private String cname;//课程名
	  private String required;
	  private int ccedit;//#学分
	  private String grade;//成绩
	  private String cgrade; //补考成绩
	  private String ccgrade;//清考成绩
//	  private List<Std> stds = new Sc();
	  private Std std;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getRequired() {
		return required;
	}
	public void setRequired(String required) {
		this.required = required;
	}
	public int getCcedit() {
		return ccedit;
	}
	public void setCcedit(int ccedit) {
		this.ccedit = ccedit;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getCgrade() {
		return cgrade;
	}
	public void setCgrade(String cgrade) {
		this.cgrade = cgrade;
	}
	public String getCcgrade() {
		return ccgrade;
	}
	public void setCcgrade(String ccgrade) {
		this.ccgrade = ccgrade;
	}
	public Std getStd() {
		return std;
	}
	public void setStd(Std std) {
		this.std = std;
	}
	  
}
