package com.std.pojo;

import java.io.Serializable;

public class Std implements Serializable{
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	  private String std_id;//学号
	  private String std_pwd ;
	  private String std_name;
	  private String std_sex;
	  private String std_photo ;
	  private String std_email;
	  private String std_dateBirth;
	  private String std_nation;
	  private String std_policSta;
	  private String std_address ;
	  private String std_colleage ;
	  private String std_professional ;//#专业
	  private int std_class ;//#班级
	  private String std_bankAccount;//#银行账号  
	  private String std_eduBg;//#学历
	  private String std_eduSys;//学制
	  private String std_englishLevel;//英语等级
	  private String std_computerLevel;//计算机等级
	  private String std_phone ;//手机号码
	  private String std_idCard ;//#身份证
	  private String std_familyDetailedAddress;//家庭通讯详细地址
	  private String std_homePhone ;//#家庭联系电话
	  private String std_parent ;//父母
	  private String std_date ;//入学时间 
	  private String std_other ;//其他评价
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStd_id() {
		return std_id;
	}
	public void setStd_id(String std_id) {
		this.std_id = std_id;
	}
	public String getStd_pwd() {
		return std_pwd;
	}
	public void setStd_pwd(String std_pwd) {
		this.std_pwd = std_pwd;
	}
	public String getStd_name() {
		return std_name;
	}
	public void setStd_name(String std_name) {
		this.std_name = std_name;
	}
	public String getStd_sex() {
		return std_sex;
	}
	public void setStd_sex(String std_sex) {
		this.std_sex = std_sex;
	}
	public String getStd_photo() {
		return std_photo;
	}
	public void setStd_photo(String std_photo) {
		this.std_photo = std_photo;
	}
	public String getStd_email() {
		return std_email;
	}
	public void setStd_email(String std_email) {
		this.std_email = std_email;
	}
	public String getStd_dateBirth() {
		return std_dateBirth;
	}
	public void setStd_dateBirth(String std_dateBirth) {
		this.std_dateBirth = std_dateBirth;
	}
	public String getStd_nation() {
		return std_nation;
	}
	public void setStd_nation(String std_nation) {
		this.std_nation = std_nation;
	}
	public String getStd_policSta() {
		return std_policSta;
	}
	public void setStd_policSta(String std_policSta) {
		this.std_policSta = std_policSta;
	}
	public String getStd_address() {
		return std_address;
	}
	public void setStd_address(String std_address) {
		this.std_address = std_address;
	}
	public String getStd_colleage() {
		return std_colleage;
	}
	public void setStd_colleage(String std_colleage) {
		this.std_colleage = std_colleage;
	}
	public String getStd_professional() {
		return std_professional;
	}
	public void setStd_professional(String std_professional) {
		this.std_professional = std_professional;
	}
	public int getStd_class() {
		return std_class;
	}
	public void setStd_class(int std_class) {
		this.std_class = std_class;
	}
	public String getStd_bankAccount() {
		return std_bankAccount;
	}
	public void setStd_bankAccount(String std_bankAccount) {
		this.std_bankAccount = std_bankAccount;
	}
	public String getStd_eduBg() {
		return std_eduBg;
	}
	public void setStd_eduBg(String std_eduBg) {
		this.std_eduBg = std_eduBg;
	}
	public String getStd_eduSys() {
		return std_eduSys;
	}
	public void setStd_eduSys(String std_eduSys) {
		this.std_eduSys = std_eduSys;
	}
	public String getStd_englishLevel() {
		return std_englishLevel;
	}
	public void setStd_englishLevel(String std_englishLevel) {
		this.std_englishLevel = std_englishLevel;
	}
	public String getStd_computerLevel() {
		return std_computerLevel;
	}
	public void setStd_computerLevel(String std_computerLevel) {
		this.std_computerLevel = std_computerLevel;
	}
	public String getStd_phone() {
		return std_phone;
	}
	public void setStd_phone(String std_phone) {
		this.std_phone = std_phone;
	}
	public String getStd_idCard() {
		return std_idCard;
	}
	public void setStd_idCard(String std_idCard) {
		this.std_idCard = std_idCard;
	}
	public String getStd_familyDetailedAddress() {
		return std_familyDetailedAddress;
	}
	public void setStd_familyDetailedAddress(String std_familyDetailedAddress) {
		this.std_familyDetailedAddress = std_familyDetailedAddress;
	}
	public String getStd_homePhone() {
		return std_homePhone;
	}
	public void setStd_homePhone(String std_homePhone) {
		this.std_homePhone = std_homePhone;
	}
	public String getStd_parent() {
		return std_parent;
	}
	public void setStd_parent(String std_parent) {
		this.std_parent = std_parent;
	}
	public String getStd_date() {
		return std_date;
	}
	public void setStd_date(String std_date) {
		this.std_date = std_date;
	}
	public String getStd_other() {
		return std_other;
	}
	public void setStd_other(String std_other) {
		this.std_other = std_other;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
