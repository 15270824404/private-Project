package com.std.server;

import com.std.pojo.Manager;

public interface ManagerServer {
//	public List<User> getUser(Page page);//��̨
//	public   int  getUserAcount();
//		public User getUserByUsername(String username);
//				
//		public User getUserById(int id);

	    public Manager Login(String username, String password);
//	    public User getUserByUidUname(int uid ,String username);
//			
//	    void saveUser(String username, String email,String password, String address, String postcode, String phone,String realname,String province, String city, String area);
//
//		public void removeUser(int id,String username,String email,String password,String address,String postcode, String phone,String userexp,
//						String realname,String locks,int grade,String province,String city,String area);
//		public void updaUserPassword(String username,String password);
//		public void updaUser(int id , String address, String postcode, String phone,String realname,String province, String city, String area);
//		public void updaUserLocks(int uid ,String locks);

}
