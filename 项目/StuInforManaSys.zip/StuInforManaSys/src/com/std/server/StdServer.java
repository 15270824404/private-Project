package com.std.server;

import java.util.List;

import com.std.pojo.Std;

public interface StdServer {
	public Std Login(String username, String password);
	public Std ShowStdByStd_id(String std_id, String password) ;
	public void upStdPwdBuStr_id(String std_id,String oldPwd);
	public void upStdInfoByStd_id(String std_id, String std_phone,
			String std_email, String std_idCard, String td_homePhone,
			String std_parent, String std_familyDetailedAddress);
	public List<Std> getStdById(String std_colleage, String std_professional,int std_class);
	public Std upStdByStd(Std std);
	public Std saveByStd(Std std);
	public void detStd(String std_id);
}
