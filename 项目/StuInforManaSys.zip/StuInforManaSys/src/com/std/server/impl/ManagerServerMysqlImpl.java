package com.std.server.impl;

import com.std.dao.ManagerDao;
import com.std.dao.impl.ManagerDaoMysqlImpl;
import com.std.pojo.Manager;
import com.std.server.ManagerServer;

public class ManagerServerMysqlImpl implements ManagerServer {
	private static ManagerServer  mangerservice =new ManagerServerMysqlImpl(); //接口
    private ManagerDao mangerDao = new ManagerDaoMysqlImpl();    
    private ManagerServerMysqlImpl(){}    
    public static ManagerServer getInstance(){
		return mangerservice;    	
    }
      
	public Manager Login(String username, String password) {
    	return mangerDao.Login(username, password);    	
	}
//	public List<User> getUser(Page page) {
//		// TODO Auto-generated method stub
//		return userDao.findUser(page);
//	}
//
//	public User getUserByUsername(String username) {
//		// TODO Auto-generated method stub
//		return userDao.findUserByUsername(username);
//	}
//
//	public User getUserById(int id) {
//		// TODO Auto-generated method stub
//		return userDao.findUserById(id);
//	}
//
//	public void saveUser(String username, String email,String password, String address, String postcode, String phone,String realname,String province, String city, String area) {
//		// TODO Auto-generated method stub
//		userDao.addUser(username, email, password, address, postcode, phone, realname, province, city, area);
//	}
//
//
//	public void removeUser(int id, String username, String email,
//			String password, String address, String postcode, String phone,
//			String userexp, String realname, String locks, int grade,
//			String province, String city, String area) {
//		
//	}
//	public void updaUserPassword(String username, String password) {
//		// TODO Auto-generated method stub
//		userDao.updateUserPassword(username, password);
//	}
//	public void updaUser(int id, String address, String postcode, String phone,
//			String realname, String province, String city, String area) {
//		// TODO Auto-generated method stub
//		userDao.updateUser(id, address, postcode, phone, realname, province, city, area);
//	}
//	public void updaUserLocks(int uid ,String locks){
//		userDao.updateUserLocks(uid, locks);
//	}
//	public User getUserByUidUname(int uid, String username) {
//		// TODO Auto-generated method stub
//		return userDao.findUserByUidUname(uid, username);
//	}
//	public int getUserAcount() {
//		// TODO Auto-generated method stub
//		return userDao.getUserAcount();
//	}
}
