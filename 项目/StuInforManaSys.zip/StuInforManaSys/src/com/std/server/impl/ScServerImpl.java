package com.std.server.impl;

import java.util.List;

import com.std.dao.impl.ScDaoMysqlImpl;

import com.std.pojo.Sc;
import com.std.server.ScServer;

public class ScServerImpl implements ScServer {
	private static ScServer  scServer =new ScServerImpl(); //接口
    private com.std.dao.ScDao scDao = new ScDaoMysqlImpl();    
    private ScServerImpl(){}    
    public static ScServer getInstance(){
		return scServer;    	
    }
	public List<Sc> getScById(String tirm, String std_id) {
		// TODO Auto-generated method stub
		return scDao.getScById(tirm, std_id);
	}
	public List<Sc> getScByStd(String tirm, String std_colleage,
			String std_professional, int std_class) {
		// TODO Auto-generated method stub
		return scDao.getScByStd(tirm, std_colleage, std_professional, std_class);
	}
	public void upScInfoByStd_id(String std_id, String cname, String required,
			String grade, int ccedit, String cgrade, String ccgrade) {
		// TODO Auto-generated method stub
		 scDao.upScInfoByStd_id(std_id, cname, required, grade, ccedit, cgrade, ccgrade);
	}
	public Sc SaveScInfoByStd_id(String trim, String std_id, String cname,
			String required, String grade, int ccedit, String cgrade,
			String ccgrade) {
		// TODO Auto-generated method stub
		return scDao.SaveScInfoByStd_id(trim, std_id, cname, required, grade, ccedit, cgrade, ccgrade);
	}
}
