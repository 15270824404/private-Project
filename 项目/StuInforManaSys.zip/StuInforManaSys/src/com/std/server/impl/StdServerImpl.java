package com.std.server.impl;

import java.util.List;

import com.std.dao.StdDao;
import com.std.dao.impl.StdDaoMysqlImpl;
import com.std.pojo.Std;
import com.std.server.StdServer;

public class StdServerImpl implements StdServer {
	private static StdServer  stdService =new StdServerImpl(); //接口
    private StdDao stdDao = new StdDaoMysqlImpl();    
    private StdServerImpl(){}    
    public static StdServer getInstance(){
		return stdService;    	
    }
      
	public Std Login(String username, String password) {
    	return stdDao.Login(username, password);    	
	}
	public Std ShowStdByStd_id(String std_id, String password) {
    	return stdDao.findStdByStd_id(std_id);  	
	}
	public void upStdPwdBuStr_id(String std_id, String newPwd) {
		// TODO Auto-generated method stub
		stdDao.upOwdByStd_id(std_id,newPwd);
	}
	public void upStdInfoByStd_id(String std_id, String std_phone,
			String std_email, String std_idCard, String td_homePhone,
			String std_parent, String std_familyDetailedAddress) {
		// TODO Auto-generated method stub
		stdDao.upStdInfoByStd_id(std_id, std_phone, std_email, std_idCard, td_homePhone, std_parent, std_familyDetailedAddress);
	}
	public List<Std> getStdById(String std_colleage, String std_professional,
			int std_class) {
		// TODO Auto-generated method stub
		return stdDao.getStdById(std_colleage, std_professional, std_class);
	}
	public Std upStdByStd(Std std) {
		// TODO Auto-generated method stub
		return stdDao.upStdByStd(std);
	}
	public Std saveByStd(Std std) {
		return stdDao.saveByStd(std);
	}
	public void detStd(String std_id) {
		// TODO Auto-generated method stub
		stdDao.removeStd(std_id);
	}
}
