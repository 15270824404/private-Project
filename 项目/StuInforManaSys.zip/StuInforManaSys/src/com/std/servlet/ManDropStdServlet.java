package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.server.impl.StdServerImpl;

public class ManDropStdServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		/manDropStd.do
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String std_id = request.getParameter("std_id");
		StdServerImpl.getInstance().detStd(std_id);
		request.setAttribute("msg", "删除成功！");
		request.getRequestDispatcher("mans_index.jsp").forward(request, response);
	}

}
