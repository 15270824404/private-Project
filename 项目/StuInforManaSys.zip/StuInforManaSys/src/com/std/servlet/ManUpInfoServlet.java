package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.pojo.Std;
import com.std.server.impl.StdServerImpl;

public class ManUpInfoServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		/manUpInfo.do
		Std std = new Std();
		String std_name = request.getParameter("std_name");
		String std_sex = request.getParameter("std_sex");
		String std_photo = request.getParameter("std_photo");
		String std_email = request.getParameter("std_email");
		String std_dateBirth = request.getParameter("std_dateBirth");
		String std_nation = request.getParameter("std_nation");
		String std_policSta = request.getParameter("std_policSta");
		String std_address = request.getParameter("std_address");
		String std_colleage = request.getParameter("std_colleage");
		String std_professional = request.getParameter("std_professional");
		int std_class = Integer.parseInt(request.getParameter("std_class"));
		String std_bankAccount = request.getParameter("std_bankAccount");
		String std_eduBg = request.getParameter("std_eduBg");
		String std_eduSys = request.getParameter("std_eduSys");
		String std_englishLevel = request.getParameter("std_englishLevel");
		String std_phone = request.getParameter("std_phone");
		String std_idCard = request.getParameter("std_idCard");
		String std_familyDetailedAddress = request.getParameter("std_familyDetailedAddress");
		String std_homePhone = request.getParameter("std_homePhone");
		String std_parent = request.getParameter("std_parent");
		String std_date = request.getParameter("std_date");
		String std_id = request.getParameter("std_id");
		
        std.setStd_address(std_address);
        std.setStd_bankAccount(std_bankAccount);
        std.setStd_class(std_class);
        std.setStd_colleage(std_colleage);
        std.setStd_date(std_date);
        std.setStd_dateBirth(std_dateBirth);
        std.setStd_eduSys(std_eduSys);
        std.setStd_eduBg(std_eduBg);
        std.setStd_email(std_email);
        std.setStd_englishLevel(std_englishLevel);
        std.setStd_familyDetailedAddress(std_familyDetailedAddress);
        std.setStd_homePhone(std_homePhone);
        std.setStd_idCard(std_idCard);
        std.setStd_id(std_id);
        std.setStd_name(std_name);
        std.setStd_nation(std_nation);
        std.setStd_parent(std_parent);
        std.setStd_phone(std_phone);
        std.setStd_policSta(std_policSta);
        std.setStd_photo(std_photo);
        std.setStd_professional(std_professional);
        std.setStd_sex(std_sex);
		
		Std std1 = StdServerImpl.getInstance().upStdByStd(std);
		request.setAttribute("std", std1);
		request.getRequestDispatcher("man_upStdInfo.jsp").forward(request, response);
	}

}
