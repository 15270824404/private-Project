package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.excption.PasswordErrorException;
import com.std.excption.UsernameNotFoundException;
import com.std.pojo.Manager;
import com.std.pojo.Std;
import com.std.server.impl.ManagerServerMysqlImpl;
import com.std.server.impl.StdServerImpl;

public class ManagerLoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username=request.getParameter("username");
       	String password=request.getParameter("password");
       	String str = request.getParameter("select");
       	String path=null;
       	String msg="用户["+username+"]登录成功！";
       	Manager manager=null;
       	Std std = null;
       if("2".equals(str)){
       	try{
       		manager=ManagerServerMysqlImpl.getInstance().Login(username, password);
       	    path="mans_index.jsp";
       	 request.getSession().setAttribute("manager", manager);
       	}catch(UsernameNotFoundException e){
       		path="./login.jsp";
       		msg="用户["+username+"]找不到，请重新登录！";
//  		    e.printStackTrace();
       	}catch(PasswordErrorException e){
       		path="./login.jsp";
       		msg="密码错误，请重新登录！";
// 		    e.printStackTrace();
       	} 
       	}else{
       		try{
           		std =StdServerImpl.getInstance().Login(username, password);
           	    path="index.jsp";
           	 request.getSession().setAttribute("std", std);
           	}catch(UsernameNotFoundException e){
           		path="./login.jsp";
           		msg="用户["+username+"]找不到，请重新登录！";
//      		    e.printStackTrace();
           	}catch(PasswordErrorException e){
           		path="./login.jsp";
           		msg="密码错误，请重新登录！";
//     		    e.printStackTrace();
           	} 
       	}
       //request.setAttribute("path", path);
 	   request.setAttribute("msg", msg);
// 	   request.setAttribute("path", path);
 	   request.getRequestDispatcher(path).forward(request, response);
	}

}
