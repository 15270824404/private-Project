package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.pojo.Sc;
import com.std.server.impl.ScServerImpl;

public class MangetScServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		/mangetSc.do
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String tirm = request.getParameter("tirm");
		String std_colleage = request.getParameter("std_colleage");
		String std_professional = request.getParameter("std_professional");		
		int std_class = Integer.parseInt(request.getParameter("std_class"));
        List<Sc> scs = ScServerImpl.getInstance().getScByStd(tirm, std_colleage, std_professional, std_class);
        request.setAttribute("scs", scs);
        request.getRequestDispatcher("man_getStdScore.jsp").forward(request, response);
	}

}
