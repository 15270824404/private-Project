package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.pojo.Sc;
import com.std.server.impl.ScServerImpl;

public class SavaScServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		scDao
		String trim = request.getParameter("tirm");
		String std_id = request.getParameter("std_id");
		String cname = request.getParameter("cname");
		String required = request.getParameter("required");
		String grade = request.getParameter("grade");
		int ccedit = 0;
		if(!"".equals(request.getParameter("ccedit")) && !(request.getParameter("ccedit")==null) ){
		    ccedit = Integer.parseInt(request.getParameter("ccedit"));
		}
		String cgrade = request.getParameter("cgrade");
		String ccgrade = request.getParameter("ccgrade");
		
		Sc sc  = ScServerImpl.getInstance().SaveScInfoByStd_id(trim, std_id, cname, required, grade, ccedit, cgrade, ccgrade);
		request.setAttribute("sc", sc);
		request.getRequestDispatcher("man_getStdScore.jsp").forward(request, response);
	}

}
