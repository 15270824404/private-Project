package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.pojo.Sc;
import com.std.server.impl.ScServerImpl;

public class ScGetBySidServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		/scGetBySid.do
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String tirm = request.getParameter("term");
		String std_id = request.getParameter("std_id");
		
		List<Sc> scs  =  ScServerImpl.getInstance().getScById(tirm, std_id);
		request.setAttribute("scs", scs);
		request.getRequestDispatcher("std_score.jsp").forward(request, response);
	}

}
