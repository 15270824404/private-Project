package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.server.impl.ScServerImpl;

public class ScUpServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		/scUp.do
		String std_id = request.getParameter("std_id");
		String cname = request.getParameter("cname");
		String required = request.getParameter("required");
		String grade = request.getParameter("grade");
		int ccedit = 0;
		if(!"".equals(request.getParameter("ccedit")) && !(request.getParameter("ccedit")==null) ){
		    ccedit = Integer.parseInt(request.getParameter("ccedit"));
		}
		String cgrade = request.getParameter("cgrade");
		String ccgrade = request.getParameter("ccgrade");
		ScServerImpl.getInstance().upScInfoByStd_id(std_id, cname, required, grade, ccedit, cgrade, ccgrade);
		request.getRequestDispatcher("man_getStdScore.jsp").forward(request, response);
	}

}
