package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.pojo.Std;
import com.std.server.impl.StdServerImpl;

public class StdGetBasicInfoServlet extends HttpServlet {

		public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String std_id=request.getParameter("std_id");
       	String password=request.getParameter("pwd");
        Std std = StdServerImpl.getInstance().ShowStdByStd_id(std_id, password);
        request.setAttribute("std", std);
  	   request.getRequestDispatcher("std_basicInfo.jsp").forward(request, response);        
           
	}

}
