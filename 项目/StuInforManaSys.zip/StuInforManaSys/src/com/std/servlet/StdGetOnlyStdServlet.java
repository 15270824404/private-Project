package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.pojo.Std;
import com.std.server.impl.StdServerImpl;

public class StdGetOnlyStdServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String std_id = request.getParameter("std_id");
		System.out.println(std_id);
		int i = Integer.parseInt(request.getParameter("i"));
	    Std std = StdServerImpl.getInstance().ShowStdByStd_id(std_id, null);
	    request.setAttribute("std", std);
	    System.out.println(std);
	    if(i==1){
	    	request.getRequestDispatcher("man_getStdInfo_Only.jsp").forward(request, response);
	    }else{
	    	request.getRequestDispatcher("man_upStdInfo.jsp").forward(request, response);
	    }
	}

}
