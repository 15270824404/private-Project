package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.pojo.Std;
import com.std.server.impl.StdServerImpl;

public class StdUpInfoServlet extends HttpServlet {

		public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//			/stdUpInfo.do
			this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String std_id=request.getParameter("std_id");
		String std_phone=request.getParameter("std_phone");
		String std_email=request.getParameter("std_email");
		String std_idCard=request.getParameter("std_idCard");
		String std_homePhone=request.getParameter("std_homePhone");
		String std_parent=request.getParameter("std_parent");
		String std_familyDetailedAddress=request.getParameter("std_familyDetailedAddress");
        StdServerImpl.getInstance().upStdInfoByStd_id(std_id, std_phone, std_email, std_idCard, std_homePhone, std_parent, std_familyDetailedAddress);
        Std std = StdServerImpl.getInstance().ShowStdByStd_id(std_id, null);
        request.setAttribute("msg", "修改成功");
        request.getSession().setAttribute("std", std);
   	    request.getRequestDispatcher("std_upInfo.jsp").forward(request, response);
   	    
	}

}
