package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.excption.PasswordErrorException;
import com.std.excption.UsernameNotFoundException;
import com.std.server.impl.StdServerImpl;

public class StdUpPwdServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		/stdUpPwd.do
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String std_id=request.getParameter("std_id");
		String oldPwd=request.getParameter("oldPwd");
		System.out.println(oldPwd);
		String newPwd=request.getParameter("newPwd");
       	String newPwd1=request.getParameter("newPwd1");
       	String msg = null;

       	if(!"".endsWith(newPwd) && newPwd != null){
       		if(newPwd.equals(newPwd1)){
       			try{
               		StdServerImpl.getInstance().Login(std_id, oldPwd);   
               		StdServerImpl.getInstance().upStdPwdBuStr_id(std_id,newPwd);
                    msg="密码修改成功";
               	}
       			catch(PasswordErrorException e){

               		msg="密码错误，请重新操作！";
//         		    e.printStackTrace();
               	}        			
       		}
       	}else{
       		msg="两次输入的密码不相同或为空";
       	}
       	request.setAttribute("msg", msg);
  	   request.getRequestDispatcher("std_upPws.jsp").forward(request, response);
	}

}
