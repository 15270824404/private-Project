package com.std.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.std.pojo.Std;
import com.std.server.impl.StdServerImpl;

public class StdsGetByServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String std_colleage = request.getParameter("std_colleage");
		String std_professional = request.getParameter("std_professional");
		int  std_class = Integer.parseInt(request.getParameter("std_class"));
        List<Std> stds = StdServerImpl.getInstance().getStdById(std_colleage, std_professional, std_class);
        request.setAttribute("stds", stds);
        request.getRequestDispatcher("man_getStdInfo.jsp").forward(request, response);
        
	}

}
