function forward(path){
	window.setTimeout("location='"+path+"'", 3000);
}