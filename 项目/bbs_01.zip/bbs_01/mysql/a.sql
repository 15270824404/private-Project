select * from t_board;
select * from t_user;
select * from t_article;
select * from test;
create table test(
id int auto_increment,
username varchar(12),
primary key(id)
)ENGINE=innoDB default charset=utf8;
insert into test values(null,'体育');
select * from test;

insert into t_board values(null,'java','study is a kind of happy');
insert into t_board values(null,'体育','I like sport');
insert into t_board values(null,'C++','love is a kind of happy');

insert into t_user values(null,'admin','12345',0,now(),'I love shaotingting');
insert into t_user values(null,'万竟','12345',0,now(),'I love shaotingting');

insert into t_article values(null,'板块一里面的主帖一','哦耶！',now(),1,1,0);
insert into t_article values(null,'万竟','好人',now(),1,1,1);
insert into t_article values(null,'版块二里面的主贴一','呵呵',now(),2,1,0);
insert into t_article values(null,'版块一里面的主贴二','嘿嘿',now(),1,1,0);

create table t_board(
  id int auto_increment,
  name varchar(20),
  exp varchar(100),
  primary key(id)
)ENGINE=innoDB default charset=utf8;
 

create table t_user(
   id int auto_increment,
   username varchar(20),
   password varchar(12),
   point int,
   pdate Date,
   exp varchar(100),
   primary key(id)
)ENGINE=innoDB default charset=utf8;

create table t_article(
  id int auto_increment,
  title varchar(20),
  content text,
  pdate Date,
  bid int,
  uid int,
  pid int,
  foreign key(bid) references t_board(id),
  foreign key(uid) references t_user(id),
  primary key(id)
)ENGINE=innoDB default charset=utf8;
drop table t_article;
drop table t_user;
drop table t_board;
create table t_user(
   id int auto_increment,
   username varchar(12),
   password varchar(6),
   primary key(id)
);
