package com.bbs.dao;

import java.util.List;

import com.bbs.pojo.Article;
import com.bbs.pojo.Page;

public interface ArticleDao {
   public List<Article> getArticlesByBid(int bid,Page page);
   public Article findParentArticleById(int id,Page page);
   public List<Article> findChildrenArticleByPid(int pid,Page page);
   public void saveArticle(Article article,int pid,int uid,int bid);
}
