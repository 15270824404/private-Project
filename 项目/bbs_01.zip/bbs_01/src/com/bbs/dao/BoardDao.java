package com.bbs.dao;

import java.util.List;

import com.bbs.pojo.Board;
import com.bbs.pojo.Page;

public interface BoardDao {
    public  List<Board> getBoards(Page page);
    public Board findBoardById(int id);
    
}
