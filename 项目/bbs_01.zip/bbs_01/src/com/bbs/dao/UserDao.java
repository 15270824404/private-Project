package com.bbs.dao;

import com.bbs.pojo.User;

public interface UserDao {
   public User getUserById(int id);
   public User findUserByUsername(String username);
}
