package com.bbs.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bbs.dao.ArticleDao;
import com.bbs.pojo.Article;
import com.bbs.pojo.Page;
import com.bbs.util.DBUtil;
import com.sun.org.apache.bcel.internal.generic.GETSTATIC;

public class ArticleDao4MySqlImpl implements ArticleDao {
	public  int  getArticleAcount(int bid,int i){
	   	 int count = 0;
	   	 Connection conn = DBUtil.getConn();
	   	PreparedStatement pstmt = null;
	   	 if(i == 0){
	   		pstmt = DBUtil.getPstmt(conn, "select count(*) from t_article where bid=? and pid=0");
	   	 }else if(i == 1){	   	
	   	 pstmt=DBUtil.getPstmt(conn, "select * from t_article where pid=?");
	   	 }
	   	 ResultSet rs = null;
	   	 try {
	   		pstmt.setInt(1, bid);
				rs = pstmt.executeQuery();
				 while(rs.next()){
		    		 count = rs.getInt(1);
		    	 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.close(conn, pstmt, rs);
			}    	 
	   	 return count;
	    }
	public List<Article> getArticlesByBid(int bid,Page page) {
		List<Article> articles=new ArrayList<Article>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_article where bid=? and pid=0 limit ?,?");
		ResultSet rs = null; 
	   	 page.setTotalPage(getArticleAcount(bid,0));
	        page.setCurrentPage(page.getCurrentPage());
			 page.setEndPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);		
	   	 try {
	   		pstmt.setInt(1, bid);
	   		pstmt.setInt(2, (page.getCurrentPage()-1)*page.getMaxResult());
	   		pstmt.setInt(3, page.getMaxResult());			
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				Article article=new Article();
				article.setId(rs.getInt("id"));
				article.setTitle(rs.getString("title"));
				article.setContent(rs.getString("content"));
				article.setUser(new UserDao4MySqlImpl().getUserById(rs.getInt("uid")));
				article.setBoard(new BoardDao4MySqlImpl().findBoardById(rs.getInt("bid")));
				article.setParent(null);
				article.setPdate(rs.getTimestamp("pdate"));
				articles.add(article);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return articles;
	}

	public List<Article> findChildrenArticleByPid(int pid,Page page) {
		List<Article> articles=new ArrayList<Article>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_article where pid=? limit ?,?");
		ResultSet rs = null; 
	   	 page.setTotalPage(getArticleAcount(pid,1));
	        page.setCurrentPage(page.getCurrentPage());
			 page.setEndPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);		
	   	 try {
	   		pstmt.setInt(1, pid);
	   		pstmt.setInt(2, (page.getCurrentPage()-1)*page.getMaxResult());
	   		pstmt.setInt(3, page.getMaxResult());			
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				Article article=new Article();
				article.setId(rs.getInt("id"));
				article.setTitle(rs.getString("title"));
				article.setContent(rs.getString("content"));
				article.setBoard(new BoardDao4MySqlImpl().findBoardById(rs.getInt("bid")));
				article.setUser(new UserDao4MySqlImpl().getUserById(rs.getInt("uid")));
				//article.setParent(parent);
				article.setChildren(null);
				article.setPdate(rs.getTimestamp("pdate"));
				articles.add(article);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return articles;
	}
	
	public Article findParentArticleById(int id,Page page) {
		Article article=null;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_article where id=?");
		ResultSet rs = null; 
//	   	 page.setTotalPage(getArticleAcount(id,2));
//	        page.setCurrentPage(page.getCurrentPage());
//			 page.setEndPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);		
	   	 try {
	   		pstmt.setInt(1, id);
//	   		pstmt.setInt(2, (page.getCurrentPage()-1)*page.getMaxResult());
//	   		pstmt.setInt(3, page.getMaxResult());			
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				article=new Article();
				article.setId(rs.getInt("id"));
				article.setTitle(rs.getString("title"));
				article.setContent(rs.getString("content"));
				article.setUser(new UserDao4MySqlImpl().getUserById(rs.getInt("uid")) );
				article.setBoard(new BoardDao4MySqlImpl().findBoardById(rs.getInt("bid")));
				article.setParent(null);
				article.setChildren(this.findChildrenArticleByPid(id,page));
				article.setPdate(rs.getTimestamp("pdate"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return article;
	}

	public void saveArticle(Article article, int pid, int uid, int bid) {
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "insert into t_article values(null,?,?,now(),?,?,?)");
		try {
			pstmt.setString(1,article.getTitle());
			pstmt.setString(2, article.getContent());
			pstmt.setInt(3, bid);
			pstmt.setInt(4, uid);
			pstmt.setInt(5, pid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
