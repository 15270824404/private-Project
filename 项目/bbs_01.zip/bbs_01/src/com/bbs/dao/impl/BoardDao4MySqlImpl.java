package com.bbs.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bbs.dao.BoardDao;
import com.bbs.pojo.Board;
import com.bbs.pojo.Page;
import com.bbs.util.DBUtil;

public class BoardDao4MySqlImpl implements BoardDao {
	public  int  getBoardAcount(){
   	 int count = 0;
   	 Connection conn = DBUtil.getConn();
   	 PreparedStatement pstmt = DBUtil.getPstmt(conn, "select count(*) from t_board");
   	 ResultSet rs = null;
   	 try {
			rs = pstmt.executeQuery();
			 while(rs.next()){
	    		 count = rs.getInt(1);
	    	 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(conn, pstmt, rs);
		}    	 
   	 return count;
    }

	public Board findBoardById(int id) {
		Board board=new Board();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_board where id=?");
		ResultSet rs=null;
		try {
			pstmt.setInt(1, id);
			rs=DBUtil.getRs(pstmt);
			if(rs.next()){
				board.setId(rs.getInt("id"));
				board.setName(rs.getString("name"));
				board.setExp(rs.getString("exp"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return board;
	}

	public List<Board> getBoards(Page page) {
		List<Board> boards=new ArrayList<Board>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_board limit ?,? ");
		ResultSet rs = null; 
   	 page.setTotalPage(getBoardAcount());
        page.setCurrentPage(page.getCurrentPage());
		 page.setEndPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);		
   	 try {
   		pstmt.setInt(1, (page.getCurrentPage()-1)*page.getMaxResult());
   		pstmt.setInt(2, page.getMaxResult());
			rs =  DBUtil.getRs(pstmt);
			while(rs.next()){
				Board board=new Board();
				board.setId(rs.getInt("id"));
				board.setName(rs.getString("name"));
				board.setExp(rs.getString("exp"));
				boards.add(board);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return boards;
	}

}
