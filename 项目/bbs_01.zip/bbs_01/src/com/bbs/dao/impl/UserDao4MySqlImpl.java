package com.bbs.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bbs.dao.UserDao;
import com.bbs.exception.PasswordErrorException;
import com.bbs.exception.UserNotFoundException;
import com.bbs.pojo.User;
import com.bbs.util.DBUtil;

public class UserDao4MySqlImpl implements UserDao {

	public User getUserById(int id) {
		User user=null;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_user where id=?");
		ResultSet rs=null;
		try {
			pstmt.setInt(1,id);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				user=new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setPoint(rs.getInt("point"));
				user.setPdate(rs.getTimestamp("pdate"));
				user.setExp(rs.getString("exp"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	public User findUserByUsername(String username) {
		User user=null;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_user where username=?");
		ResultSet rs=null;
		try {
			pstmt.setString(1,username);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				user=new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setPoint(rs.getInt("point"));
				user.setPdate(rs.getTimestamp("pdate"));
				user.setExp(rs.getString("exp"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

}
