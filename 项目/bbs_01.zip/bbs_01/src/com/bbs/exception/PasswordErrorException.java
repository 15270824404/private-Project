package com.bbs.exception;

public class PasswordErrorException extends RuntimeException {

}
