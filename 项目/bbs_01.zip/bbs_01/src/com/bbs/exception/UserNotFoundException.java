package com.bbs.exception;

public class UserNotFoundException extends RuntimeException {

}
