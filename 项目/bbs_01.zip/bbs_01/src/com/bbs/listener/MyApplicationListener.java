package com.bbs.listener;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class MyApplicationListener implements ServletContextListener {

	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub

	}

	public void contextInitialized(ServletContextEvent event) {
		List<String> onlinePerson=new ArrayList<String>();
		ServletContext application=event.getServletContext();
        application.setAttribute("onlinePerson", onlinePerson);
        
	}

}
