package com.bbs.pojo;

import java.util.Date;
import java.util.List;

public class Article {
	 private int id;
	 private String title;
	 private String content;
	 private Date pdate;
	 private Board board;
	 private User user;
	 private Article parent;
	 private List<Article> children;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getPdate() {
		return pdate;
	}
	public void setPdate(Date pdate) {
		this.pdate = pdate;
	}
	public Board getBoard() {
		return board;
	}
	public void setBoard(Board board) {
		this.board = board;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Article getParent() {
		return parent;
	}
	public void setParent(Article parent) {
		this.parent = parent;
	}
	public List<Article> getChildren() {
		return children;
	}
	public void setChildren(List<Article> children) {
		this.children = children;
	}
	 
}
