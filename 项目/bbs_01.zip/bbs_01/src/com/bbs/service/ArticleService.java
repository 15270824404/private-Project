package com.bbs.service;

import java.util.List;

import com.bbs.pojo.Article;
import com.bbs.pojo.Page;

public interface ArticleService {
  public List<Article> showArticlesByBid(int bid,Page page);
  public Article showArticleById(int id,Page page);
  public void addArticle(Article article,int bid,int uid,int pid);
}
