package com.bbs.service;

import java.util.List;

import com.bbs.pojo.Board;
import com.bbs.pojo.Page;

public interface BoardService {
   public List<Board> showBoards(Page page);
}
