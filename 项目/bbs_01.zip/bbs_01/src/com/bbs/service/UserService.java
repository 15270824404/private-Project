package com.bbs.service;

import com.bbs.pojo.User;

public interface UserService {
  public User Login(String username,String password);
}
