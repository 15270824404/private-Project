package com.bbs.service.impl;

import java.util.List;

import com.bbs.dao.ArticleDao;
import com.bbs.dao.impl.ArticleDao4MySqlImpl;
import com.bbs.pojo.Article;
import com.bbs.pojo.Page;
import com.bbs.service.ArticleService;

public class ArticleServiceImpl implements ArticleService {
    private  ArticleServiceImpl(){}
    private static ArticleDao articleDao=new ArticleDao4MySqlImpl();
    private static ArticleServiceImpl articleService=new ArticleServiceImpl();
    public static ArticleServiceImpl getInstance(){
    	return articleService;
    }
	public List<Article> showArticlesByBid(int bid,Page page) {
		
		return articleDao.getArticlesByBid(bid,page);
	}
	public Article showArticleById(int id,Page page) {
		// TODO Auto-generated method stub
		return articleDao.findParentArticleById(id,page);
	}
	public void addArticle(Article article, int bid, int uid, int pid) {
		// TODO Auto-generated method stub
		articleDao.saveArticle(article, pid, uid, bid);
	}

}
