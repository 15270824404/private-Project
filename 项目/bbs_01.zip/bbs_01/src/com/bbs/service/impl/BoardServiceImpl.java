package com.bbs.service.impl;

import java.util.List;

import com.bbs.dao.BoardDao;
import com.bbs.dao.impl.BoardDao4MySqlImpl;
import com.bbs.pojo.Board;
import com.bbs.pojo.Page;
import com.bbs.service.BoardService;

public class BoardServiceImpl implements BoardService {
	private BoardServiceImpl(){}
	
    private static BoardDao boardDao=new BoardDao4MySqlImpl();
    private static BoardServiceImpl boardService=new BoardServiceImpl();
    public static BoardServiceImpl getInstance(){
    	return boardService;
    }   
	public List<Board> showBoards(Page page) {
		
		return boardDao.getBoards(page);
	}

}
