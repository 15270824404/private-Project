package com.bbs.service.impl;

import com.bbs.dao.UserDao;
import com.bbs.dao.impl.UserDao4MySqlImpl;
import com.bbs.exception.PasswordErrorException;
import com.bbs.exception.UserNotFoundException;
import com.bbs.pojo.User;
import com.bbs.service.UserService;

public class UserServiceImpl implements UserService {
   private  UserServiceImpl(){}
   private static UserDao userDao=new UserDao4MySqlImpl();
   private static UserServiceImpl userService=new UserServiceImpl();
   public static UserServiceImpl getInstance(){
	   return userService;
   }
   public User Login(String username, String password) {
	 User user=userDao.findUserByUsername(username);
	 if(user==null){
		 throw new UserNotFoundException();
	 }
	 if(!password.equals(user.getPassword())){
		 throw new PasswordErrorException();
	 }
	 return user;
   }
   
}
