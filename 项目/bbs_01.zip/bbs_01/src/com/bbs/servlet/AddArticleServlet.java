package com.bbs.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bbs.pojo.Article;
import com.bbs.service.impl.ArticleServiceImpl;

public class AddArticleServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
       Article article=(Article)request.getAttribute("article");
       int bid=Integer.parseInt(request.getParameter("bid"));
       int uid=Integer.parseInt(request.getParameter("uid"));
       int pid=Integer.parseInt(request.getParameter("pid"));
      
       String path=null;
       String msg=null;
       if(pid==0){
    	   path="./showArticle4Board.do?id="+bid;
    	   request.setAttribute("msg", "版块增加成功");
    	   request.setAttribute("path", path);
       }else{
    	   path="./showArticle.do?id="+pid;
    	   request.setAttribute("msg", "回复成功");
    	   request.setAttribute("path", path);
       }
       ArticleServiceImpl.getInstance().addArticle(article, bid, uid, pid);
       request.getRequestDispatcher("./msg.jsp").forward(request, response);
	}

}
