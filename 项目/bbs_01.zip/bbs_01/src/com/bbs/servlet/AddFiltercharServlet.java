package com.bbs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bbs.filter.AddArticleFilter;

public class AddFiltercharServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
        String str=request.getParameter("filterchar");
        String strs[]=str.split(",");
        List<String> filterchar=AddArticleFilter.FILTER_CHAR;
        for(int i=0;i<strs.length;i++){
        	filterchar.add(strs[i]);
        }
        filterchar=filterchar;
        response.sendRedirect("./admin/filterchar.jsp");
	}

}
