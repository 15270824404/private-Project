package com.bbs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bbs.exception.PasswordErrorException;
import com.bbs.exception.UserNotFoundException;
import com.bbs.pojo.User;
import com.bbs.service.impl.UserServiceImpl;

public class LoginServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	    String username=request.getParameter("username");
	    String password=request.getParameter("password");
	    String path="./index.jsp";
	    String msg="用户["+username+"]登录成功";
	    User user=null;
	    try{
	    user=UserServiceImpl.getInstance().Login(username, password);
	    String onlinePersonName=(String) request.getSession().getAttribute("onlinePersonName");
	    List<String> onlinePerson=(List<String>)this.getServletContext().getAttribute("onlinePerson");
	    onlinePerson.remove(onlinePersonName);
	    onlinePerson.add(user.getUsername());
	    this.getServletContext().setAttribute("onlinePerson", onlinePerson);
	    }catch(UserNotFoundException e){
		  path="./Login.jsp";
		  msg="找不到该["+username+"]用户，请重写";
		   e.printStackTrace();
	   }catch(PasswordErrorException e){
		   path="./Login.jsp";
		   msg="密码错误";
		   e.printStackTrace();
	   }
	   request.setAttribute("path", path);
	   request.setAttribute("msg", msg);
	   request.getSession().setAttribute("user", user);
	   request.getRequestDispatcher("./msg.jsp").forward(request, response);
	}

}
