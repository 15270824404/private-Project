package com.bbs.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bbs.pojo.Article;
import com.bbs.pojo.Page;
import com.bbs.service.impl.ArticleServiceImpl;

public class ShowArticle4BoardServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Page page = new Page();
		page.setCurrentPage(1);
		if(request.getParameter("currentPage") != null){
        page.setCurrentPage(Integer.parseInt(request.getParameter("currentPage")));
		}
       int bid=Integer.parseInt(request.getParameter("id"));
       List<Article> articles=ArticleServiceImpl.getInstance().showArticlesByBid(bid,page);
       request.setAttribute("articles", articles);
       request.setAttribute("page", page);
       request.setAttribute("id", bid);
       
       request.getRequestDispatcher("./thread.jsp?bid="+bid).forward(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
