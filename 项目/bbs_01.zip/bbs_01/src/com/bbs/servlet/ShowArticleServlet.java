package com.bbs.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bbs.dao.impl.ArticleDao4MySqlImpl;
import com.bbs.pojo.Article;
import com.bbs.pojo.Page;
import com.bbs.service.impl.ArticleServiceImpl;

public class ShowArticleServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Page page = new Page();
		page.setCurrentPage(1);
		if(request.getParameter("currentPage") != null){
        page.setCurrentPage(Integer.parseInt(request.getParameter("currentPage")));
		}
		int id=Integer.parseInt(request.getParameter("id"));
		Article article= ArticleServiceImpl.getInstance().showArticleById(id,page);
		request.setAttribute("article", article);
		request.setAttribute("page", page);
		request.setAttribute("id", id);
		request.getRequestDispatcher("./article.jsp").forward(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
