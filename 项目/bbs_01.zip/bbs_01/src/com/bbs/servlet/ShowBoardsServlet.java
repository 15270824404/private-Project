package com.bbs.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bbs.pojo.Board;
import com.bbs.pojo.Page;
import com.bbs.service.impl.BoardServiceImpl;

public class ShowBoardsServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Page page = new Page();
		page.setCurrentPage(1);
		if(request.getParameter("currentPage") != null){
        page.setCurrentPage(Integer.parseInt(request.getParameter("currentPage")));
		}
		List<Board> boards= BoardServiceImpl.getInstance().showBoards(page);
		request.setAttribute("boards", boards);
		request.setAttribute("page", page);
		request.getRequestDispatcher("./index.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        this.doGet(request, response);
		
	}

}
