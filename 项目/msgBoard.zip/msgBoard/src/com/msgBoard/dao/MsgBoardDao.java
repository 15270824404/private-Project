package com.msgBoard.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.msgBoard.pojo.Msg;
import com.msgBoard.pojo.Page;

public interface MsgBoardDao {
	public  void saveMsg(Msg msg);
	public  List<Msg> getMsg(HttpServletRequest request, HttpServletResponse response,Page page);
	 public  List<Msg> updateMsg(int id,int state);
	 public void deleteMsg(int id);
}
