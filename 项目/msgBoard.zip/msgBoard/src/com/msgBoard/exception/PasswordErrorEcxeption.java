package com.msgBoard.exception;

public class PasswordErrorEcxeption extends RuntimeException {

}
