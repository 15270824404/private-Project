package com.msgBoard.exception;

public class UsernameNotFormException extends RuntimeException {

}
