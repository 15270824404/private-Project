package com.msgBoard.pojo;

import java.util.Date;

public class Msg {
	private int  id;
    private String username;
    private String title;
    private String email;
    private String address;
    private int phtot  ;
    private String iqcq ;
    private String mypage;
    private String content;
    private Date Mdate ;
    private int state;
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPhtot() {
		return phtot;
	}
	public void setPhtot(int phtot) {
		this.phtot = phtot;
	}
	public String getIqcq() {
		return iqcq;
	}
	public void setIqcq(String iqcq) {
		this.iqcq = iqcq;
	}
	public String getMypage() {
		return mypage;
	}
	public void setMypage(String mypage) {
		this.mypage = mypage;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getMdate() {
		return Mdate;
	}
	public void setMdate(Date mdate) {
		Mdate = mdate;
	} 
}
