package com.msgBoard.pojo;

public class Page {
	private int maxResult = 5;
	private int currentPage;
	private int totalPage;
	private int endPage;
	
	public int getMaxResult() {
		return maxResult;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalResult) {
		this.totalPage = totalResult;
	}
	public int getEndPage() {
		return endPage;
	}
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
}
