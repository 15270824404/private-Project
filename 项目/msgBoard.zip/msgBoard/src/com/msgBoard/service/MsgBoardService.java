package com.msgBoard.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.msgBoard.pojo.Msg;
import com.msgBoard.pojo.Page;

public interface MsgBoardService {
	public  void addMsg(Msg msg);
	public  List<Msg> showMsg(HttpServletRequest request, HttpServletResponse response,Page page);
	 public  List<Msg> updateMsg(int id,int state);
	 public void removeMsg(int id);
}
