package com.msgBoard.service.impl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.msgBoard.dao.MsgBoardDao;
import com.msgBoard.dao.impl.MsgBoardDao4MySqlImpl;
import com.msgBoard.pojo.Msg;
import com.msgBoard.pojo.Page;
import com.msgBoard.service.MsgBoardService;

public class MsgBoardServiceImpl implements MsgBoardService{
	private  MsgBoardServiceImpl(){}; 
	private static MsgBoardService msgBoardService = new MsgBoardServiceImpl();
	public static MsgBoardService getStance(){
		return msgBoardService;
	}
    private MsgBoardDao msgBoardDao = new MsgBoardDao4MySqlImpl();
	public void addMsg(Msg msg) {
		// TODO Auto-generated method stub
		msgBoardDao.saveMsg(msg);
	}

	public List<Msg> showMsg(HttpServletRequest request,
			HttpServletResponse response,Page page) {
		// TODO Auto-generated method stub
		return msgBoardDao.getMsg(request, response,page);
	}

	public List<Msg> updateMsg(int id, int state) {
		// TODO Auto-generated method stub
		return msgBoardDao.updateMsg(id, state);
	}

	public void removeMsg(int id) {
		// TODO Auto-generated method stub
		msgBoardDao.deleteMsg(id);
	}

}
