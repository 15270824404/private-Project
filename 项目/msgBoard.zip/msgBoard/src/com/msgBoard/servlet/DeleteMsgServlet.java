package com.msgBoard.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.msgBoard.service.impl.MsgBoardServiceImpl;

public class DeleteMsgServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try{
		    int id = Integer.parseInt(request.getParameter("id"));
		    MsgBoardServiceImpl.getStance().removeMsg(id);
		    request.setAttribute("msg","删除成功 ！");
		    request.setAttribute("path","./index.jsp");
		    }catch (Exception e){
		    e.printStackTrace();
		    request.setAttribute("msg","删除错误 ！ ");
		    request.setAttribute("path","./index.jsp");
		    }
		    request.getRequestDispatcher("./msg.jsp").forward(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
      this.doGet(request, response);
	}

}
