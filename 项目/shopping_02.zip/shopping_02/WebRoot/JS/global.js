$(document).ready(a);		
	function a(){		
		$.getJSON("showTypes.do?tid=0",null,function(data){
			for(var n=0;n<data.length;n++){
				var objPtion = $("<option>");
				objPtion.html(data[n]["name"]);	
			    objPtion.val(data[n]["id"]);
				objPtion.appendTo($("#ptype"));

			}
		});
	}
	
function monthChange1(){
		var objY1 =$("#year1");
		
		var year = objY1.val();
		var objM1 = $("#month1");
		var month = objM1.val();
		var objD1 = $("#day1");
		objD1.empty();
		var day =31;
		if (month==4||month == 6||month == 9||month == 11){
			day = 30;
		}
		if (year /4 == 0 && month ==2){
			day =29;
		}else if(year/4 !=0 && month==2){
			day =28;
		}
		for (var i =1;i<=day;i=i+1){
			var objO1 = $("<option>");
			objO1.val(i);
			objO1.html(i);	
			objD1.append(objO1);
		}
		
	}


function monthChange2(){
		var objY2 =$("#year2");	
		var year = objY2.val();
		var objM2 = $("#month2");
		var month = objM2.val();
		var objD2 = $("#day2");
		objD2.empty();
		var day =31;
		if (month==4||month == 6||month == 9||month == 11){
			day = 30;
		}
		if (year /4 == 0 && month ==2){
			day =29;
		}else if(year/4 !=0 && month==2){
			day =28;
		}
		for (var i =1;i<=day;i=i+1){
			var objO2 = $("<option>");
			objO2.val(i);
			objO2.html(i);	
			objD2.append(objO2);
		}
		
	}
