function confirm(pid,uid){
	$.extend($.messager.defaults,{  
	    ok:"确定",  
	    cancel:"取消"  
	});  
            if(uid == 0){     			
            		$.messager.alert('提示框','你没有登录!');
            }else{
			$.messager.confirm('提示框', '你是否需要收藏该产品?', function(r){
				if (r){
					//location.href = "addFavDetail.do?pid="+pid+"&uid="+uid;
					$.get("checkFavDetail.do?pid="+pid+"&uid="+uid, null, function(data){
						if(data == 0){
							$.messager.alert('提示框','你已经收藏了!');
						}else{
							location.href = "addFavDetail.do?pid="+pid+"&uid="+uid;
						}
					} 
				);
				}
			});
		}
}

function confirm1(pid){
	$.extend($.messager.defaults,{  
	    ok:"确定",  
	    cancel:"取消"  
	});  
			$.messager.confirm('提示框', '确认添加到你的购物车嘛？', function(r){
				if (r){
					//location.href = "addFavDetail.do?pid="+pid+"&uid="+uid;
					$.get("checkCarExt.do?pid="+pid, null, function(data){
						if(data == 0){
							$.messager.alert('提示框','      此商品已经存在购物车！');
						}else{
							//location.href = "addCar.do?pid="+pid;
							$.get("addCar.do?pid="+pid, null, function(data){
								if(data == 1){
									$.messager.alert('提示框','    添加进您的购物车中 ！');
							}
						});
					} 
					});
				}
			});
}



//验证码
function Captch(id){
    return document.getElementById(id);
 }

 /**刷新iframe**/
 function refreshCode(){
     window.frames["codeFrame"].location.reload();
 }
 //3秒钟跳转
 function forword(){
		setInterval("a()",1000);
	}
	function a(){
			var path = document.getElementById("path").innerHTML;
			var times = document.getElementById("time");
			var time = times.innerHTML;
			times.innerHTML = time-1;
			if(time == 1){
				clearInterval();
				location = path;
			}
	}