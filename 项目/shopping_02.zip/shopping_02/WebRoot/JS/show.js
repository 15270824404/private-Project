$(document).ready(function() {
	$.get("./showTypes.do?tid=0", null, function(data) {
		var objdata = eval(data);
		var objTree = $("#addtree");
		for ( var i = 0; i < objdata.length; i++) {
			var id = objdata[i]["id"];
			var objdiv = $("<div style=\" cursor: pointer;color:#006666;font-weight :800\" onclick=\"showChildren("+id+")\" >");
			objdiv.addClass("ptype"+id);
			objdiv.html(objdata[i]["name"]);
			objdiv.appendTo(objTree);
			chilType(id);
		}
	});
});

function chilType(id) {
	$.get("./showTypes.do?tid=" + id, null, function(data) {
		var objd = eval(data);
		var objchil = $(".ptype"+id);
		for ( var i = 0; i < objd.length; i++) {
			var tid = objd[i]["id"];
			var obj_div = $("<div style=\" cursor: pointer;display: none;color:highlight;font-weight :300 \"  onclick=\"showGoods("+tid+")\" >");
			obj_div.addClass("ctype" + id);		
			obj_div.html(objd[i]["name"]);		
			obj_div.appendTo(objchil);
			
		}
	});
}
function showChildren(id){
	 $(".ctype"+id).slideToggle(300);
}

function showGoods(tid){

	window.location = ("showProductByType.do?id="+tid);
}

function show(){
	$(".win").slideDown(3000); 
}
