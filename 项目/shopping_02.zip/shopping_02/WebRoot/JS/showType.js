$(document).ready(regLoad);

function regLoad(){

	c(0);c(1);
	$("#supertype").change(b);	
}
function b(){
	$("#typeID").empty();
	var tid = $(this).val();
	c(tid);
}
function c(tid){
	var objTid;
	if(tid == 0){
		objTid = "#supertype";		
	}else{
		objTid = "#typeID";
		}	
	$.getJSON("./showTypes.do?tid=" + tid, null, function(data) {
		for(var n=0;n<data.length;n++){
			var objPtion = $("<option>");
			objPtion.html(data[n]["name"]);		
			objPtion.val(data[n]["id"]);
			objPtion.appendTo($(objTid));
			}
	} ); 

}

function showWinForAddGood(value){
	var id = value.id;
	//var cpage = value.currentPage;
	$("#wind").slideDown("slow");
	$("#wind").css("display","block");
	var objHidden1 = $("#hiddenID");
	//var objHidden1 = $("hiddenCPAGE");
	objHidden1.val(id);
}

function closeWin(){
    
    $("#wind").css("display","none");
}
