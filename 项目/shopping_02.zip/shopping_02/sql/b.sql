create database ourHr;
 shopping;
use shopping;

use test;
#用户表
select * from t_user;
create table t_user(
   id int auto_increment,
   username varchar(12),#名字
   email varchar(22),#邮箱
   password varchar(12),#密码
   address varchar(12),#地址
   postcode varchar(12),#邮编
   phone varchar(12),#电话
   userexp varchar(100),#用户
   realname varchar(12),#真实名字
   locks varchar(12),#冻结不冻结 冻结  locked  |没冻结 用 nolock
   grade int,#等级
   province varchar(12),
   city varchar(12),
   area varchar(12),
   udate TimeStamp,#新加 注册时间，等管理员界面需要
   primary key(id)
);
select * from t_user;
select password,locks from t_user;
drop table t_user;
insert into t_user values(null,'admin','1181169734@qq.com','12345','江苏省徐州','333100',+
'15270825521','做我自己','林欣','nolock',1,'江苏省','徐州市','阳都',now());
insert into t_user values(null,'tom','11698775654@qq.com','12345','江西鄱阳','457587',+
'18885464241','湖城是我家','林欣','nolock',1,'江西省','上饶市','鄱阳',now());
insert into t_user values(null,'jack','7867454@qq.com','12345','江苏省徐州','45244',+
'15621345212','BOD java 教育','林欣','nolock',1,'江西省','南昌市','青山湖区',now());
insert into t_user values(null,'sum','458757787@qq.com','12345','江西华东交通大学','45750',+
'18564317521','','林欣','locked',1,'江西省','南昌市','青山湖区',now());
select * from t_user;
#商品类别表 
create table t_type(
  id int auto_increment,#分类的id
  name varchar(15),  #分类的名称
  exp varchar(100), #子类的描述
  tid int,          #该类的大类id
  primary key(id)
);
drop table t_type;
select * from t_type;
#大类区
insert into t_type values(null,'食品烟酒','欢迎光临BOD电子商城!',0);
insert into t_type values(null,'健康美容','欢迎光临BOD电子商城!',0);
insert into t_type values(null,'家居日用','欢迎光临BOD电子商城!',0);
insert into t_type values(null,'家电通讯','欢迎光临BOD电子商城!',0);
insert into t_type values(null,'服装鞋帽','欢迎光临BOD电子商城!',0);
insert into t_type values(null,'IT数码','欢迎光临BOD电子商城!',0);
select * from t_type;
#tid=1
insert into t_type values(null,'素食区','好质量，好服务!',1);
insert into t_type values(null,'熟食区','好质量，好服务!',1);
insert into t_type values(null,'香烟区','好质量，好服务!',1);
insert into t_type values(null,'酒水区','好质量，好服务!',1);

#tid=2
insert into t_type values(null,'护肤区','好质量，好服务!',2);
insert into t_type values(null,'彩妆区','好质量，好服务!',2);
insert into t_type values(null,'美发区','好质量，好服务!',2);
insert into t_type values(null,'香水区','好质量，好服务!',2);
insert into t_type values(null,'瘦身区','好质量，好服务!',2);


#tid=3
insert into t_type values(null,'洗涤用品','好质量，好服务!',3);

#tid=4
insert into t_type values(null,'电视区','好质量，好服务!',4);
insert into t_type values(null,'冰箱区','好质量，好服务!',4);
insert into t_type values(null,'电话区','好质量，好服务!',4);
insert into t_type values(null,'手机区','好质量，好服务!',4);

#tid=5
insert into t_type values(null,'女装区','好质量，好服务!',5);
insert into t_type values(null,'男装区','好质量，好服务!',5);
insert into t_type values(null,'童装区','好质量，好服务!',5);
insert into t_type values(null,'鞋帽区','好质量，好服务!',5);


#tid=6
insert into t_type values(null,'数码相机区','好质量，好服务!',6);
insert into t_type values(null,'摄影器材','好质量，好服务!',6);
insert into t_type values(null,'摄像器材','好质量，好服务!',6);
insert into t_type values(null,'MP3/MP4','好质量，好服务!',6);
insert into t_type values(null,'U盘/移动硬盘','好质量，好服务!',6);
select * from t_type;
create table t_product(#产品
id int auto_increment,#产品编号
pname varchar(15),#产品名称
isbargain int,#是否特价 特价为0  其余为1
price float,#商场价格
marketprice float,#市场价格
pcount int,#产品数量
isprefered int,#是否隐藏  隐藏为0  其余为1
pexp varchar(100),#产品描述
pic varchar(30),#产品图片
pdate TimeStamp,
pdiscount float,#产品折扣
tid int,#产品类别
mistid int ,#小类产品类型            '需要增加一个字段才能区分这大类与小类'
primary key(id),
foreign key(tid) references t_type(id),
foreign key(mistid) references t_type(id)
);
select * from t_product  where isprefered=1 and  pname like? and tid=?
select * from t_product where isprefered=1 and pdate>'2012-09-27 20:59:28.0' ;
select * from t_product  where  pname like '%%'  and tid=1 ;
select * from t_product where isprefered=1 and isbargain=0;
drop table t_product;
select * from t_product;
insert into t_product values(null,'小天使电视',0,2380.0,3210.0,150,1,'小天使带给你高清享受','images/goods/fdg0012.jpg',now(),100.0,4,17);
insert into t_product values(null,'三星彩电',0,3500.0,4021.0,100,1,'三星给你最优质的品质','images/goods/fdg0013.jpg',now(),100.0,4,17);
insert into t_product values(null,'新新人类电视',1,4580.0,5210.0,150,1,'给你最新的感受','images/goods/fdg0005.jpg',now(),67.0,4,17);
insert into t_product values(null,'三维电视',0,7800.0,10000.0,150,1,'超薄显示屏，立体感强','images/goods/fdg0004.jpg',now(),70.0,4,17);
insert into t_product values(null,'同创电视',1,2310.0,3210.0,150,1,'低价高配置','images/goods/fdg0006.jpg',now(),46.0,4,17);

insert into t_product values(null,'明可数码相机',0,1120.0,1810.0,150,1,'低价高配置','images/goods/123457.jpg',now(),78.0,6,25);

insert into t_product values(null,'海尔节能冰箱',0,10000.0,12000.0,160,1,'给你想不到的品质','images/goods/fdg0015.jpg',now(),92.0,4,18);
insert into t_product values(null,'百里香蛋卷',0,12.0,20.0,1000,1,'法式蛋卷','images/goods/123456.jpg',now(),100.0,1,7);
insert into t_product values(null,'52/38度四特酒',1,2310.0,3210.0,150,1,'低价高配置','images/goods/fdg0006.jpg',now(),69.0,4,10);
insert into t_product values(null,'索肤特洗面奶',1,666.0,888.0.0,500,1,'低价高配置','images/goods/fdg0006.jpg',now(),46.0,3,16);

create table t_comment(#评论(comment)
	id int auto_increment,
	addtime TimeStamp,#评论时间
	content varchar(200),#评论内容
	pid int,#评论产品
	uid int,#评论用户
	primary key(id),
	foreign key(pid) references t_product(id),
	foreign key(uid) references t_user(id)
);
drop table t_comment;
create table t_cart(#购物车
  id int auto_increment,
  cdate TimeStamp,#购物车的产生的时间
  pid int,#产品id
  uid int,#用户id
  primary key(id),
  foreign key(pid) references t_product(id),
  foreign key(uid) references t_user(id)
);
drop table t_cart;
create table t_favorites(#收藏
	id int auto_increment,
	padte TimeStamp,
	pid int,
	uid int,
	PRIMARY KEY(id),
	foreign key(uid) references t_user(id),
	foreign key(pid) references t_product(id)
);
select pid from t_favorites where uid=1;
select * from t_favorites;
drop table t_favorites;
use test;
show tables;
 #公告表 没有主外键联系
create table t_notice(
  id int auto_increment,#公告id
  title varchar(50),  #公告标题
  content text, #公告内容
  fdate TimeStamp,    #发布时间
  sdate TimeStamp,  #失效时间
  primary key(id)
);
drop table t_notice;
insert into t_notice values(null,'圣诞购物有奖活动！','凡在shopping商城购物满200元的顾客，就可免费领取窝夫小子精美甜品1份。','2012-12-24 21:10:23','2012-01-01 21:10:23');
insert into t_notice values(null,'机会不容错过，快快行动吧！','光棍节,为回馈淘友感谢各位亲们的支持,特此促销.买一送一','2012-11-7 12:20:23','2012-01-17 2:10:03');
insert into t_notice values(null,'人生感悟','哪里会有人喜欢孤独，不过是不喜欢失望。','2012-11-1 12-23-11','2012-11-30 23:10:23');
insert into t_notice values(null,'全场六折','请点击下面链接','2012-10-25 11:10:42','2012-10-30 13:12:12');
insert into t_notice values(null,'十一疯狂shopping','十一，感谢各位亲们的支持,特此促销.买一送一','2012-10-1 12:12:23','2012-10-30 5:23:45');
#insert into t_notice values(null,'十一三清山三天游免费抽奖','请抽去','2012-11-1','2012-11-30');
select * from t_notice;
         
#管理员
create table t_manager(#管理员
id int auto_increment,
username varchar(12),#管理员名字
password varchar(12),#密码
primary key(id)
);
select * from t_manager;
show tables;

insert into t_manager values(null,'admin','12345');


create table t_order(#订单
 id int auto_increment,#订单编号
 texp varchar(100),#订单状态
 uid int ,#用户编号
 isbill varchar(4),#是否开发票
 paytype varchar(30),#付款方式
 content text,#备注
 sendtype varchar(100),#送货方式
 odate TimeStamp,#下单时间
 state int,
 primary key(id),#主键
 foreign key(uid) references t_user(id)
);
insert into t_order values(null,'新订单',1,'是','邮政付款','请在上班时间送到!','普通邮寄',now(),1);
insert into t_order values(null,'已配送',2,'无','邮政付款','请在上班时间送到!','普通邮寄',now(),0);
insert into t_order values(null,'新订单',3,'是','邮政付款','请在上班时间送到!','普通邮寄',now(),1);
insert into t_order values(null,'已配送',1,'是','邮政付款','请在上班时间送到!','普通邮寄',now(),0);
insert into t_order values(null,'新订单',1,'是','邮政付款','请在上班时间送到!','普通邮寄',now(),1);
insert into t_order values(null,'新订单',1,'是','邮政付款','请在上班时间送到!','普通邮寄',now(),1);


select * from t_order where texp like '新订单';
select * from t_order id=1; 
select * from t_order;
drop table t_order;
select * from t_order.frm;
select id from t_order where odate =(select max(odate) from t_order);
select id from t_order where id=(select max(id) from t_order);
create table t_detail(
    id int auto_increment,#编号，与订单表里的编号对应
    pid int,
    oid int,
    num int,
    primary key(id),
    foreign key(oid) references t_order(id),
    foreign key(pid) references t_product(id)
);
drop table t_detail;
insert into t_detail values(null,1,1,1);
insert into t_detail values(null,2,1,2);
insert into t_detail values(null,3,2,1);
insert into t_detail values(null,4,2,3);
insert into t_detail values(null,4,3,1);
insert into t_detail values(null,5,4,3);
insert into t_detail values(null,6,5,3);
select  distinct pid from t_detail;
select * from t_detail;
select pid from t_detail;
select count(num) from t_detail where pid=9;
select num from t_detail where pid = 1;
select distinct pid,sum(num) from t_detail where distinct(pid) group by pid desc;
select distinct pid,num from t_detail where pid,num order by num ;
select sum(num) as sumvalue from t_detail where pid=(select pid from t_detail);

select sum(num) from t_detail where num =(select num from t_detail where pid=8);
select id, name from table group by name
select count(*) distinct pid from t_detail
