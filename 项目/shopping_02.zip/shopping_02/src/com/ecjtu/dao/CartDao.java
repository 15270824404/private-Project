package com.ecjtu.dao;

public interface CartDao {

}
