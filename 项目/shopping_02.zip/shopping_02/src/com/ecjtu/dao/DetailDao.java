package com.ecjtu.dao;

import java.util.List;

import com.ecjtu.pojo.Detail;

public interface DetailDao {
  public List<Detail> findDetailByOid(int oid);
  public double findSumPrice(int oid);
  public boolean addDetail(int pid,int oid,int num);
  public List<Detail> findDetail();
}
