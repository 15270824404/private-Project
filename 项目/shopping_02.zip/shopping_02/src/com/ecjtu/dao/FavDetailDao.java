package com.ecjtu.dao;

import java.util.List;

import com.ecjtu.pojo.FavDetail;

public interface FavDetailDao {
	public List<FavDetail> findFavDetail(int uid);
	public void addfavDetailByUPid(int uid,int pid);
	public int findFavDetailByPid(int uid,int pid);
}
