package com.ecjtu.dao;

import com.ecjtu.pojo.Manager;

public interface ManagerDao {
   public Manager findManager(String username);
}
