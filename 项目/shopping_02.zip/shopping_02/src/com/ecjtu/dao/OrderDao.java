package com.ecjtu.dao;

import java.util.List;

import com.ecjtu.pojo.Order;
import com.ecjtu.pojo.Page;

public interface OrderDao {
  public List<Order> findOrders();
  public Order findOrder(int id);
  public List<Order> findOrdersByPage(Page page);
  public void renew(int id);
  public int findCount();
  public int  addOrder(int uid,String isbill,String paytype,String content,String sendtype);
  public List<Order> findOrdersByUid(int uid);
}
