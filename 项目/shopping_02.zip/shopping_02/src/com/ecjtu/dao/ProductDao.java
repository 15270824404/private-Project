package com.ecjtu.dao;

import java.util.List;

import com.ecjtu.pojo.Page;
import com.ecjtu.pojo.Product;

public interface ProductDao {
  public List<Product> findProductDaoAll();
 //查询是否特价
  public List<Product> findProductDaoIsbargainAll(Page page);
//查询个别的特价
  public Product findProductDaoIsbargainOnly(int id);
//查询最新的产品
  public List<Product> findProductDaoIsprefered(Page page);//我的新品有问题
//查询以id来查询到产品的数量
  public int findProductDaoAcount(int id);
  //查询id得到产品
  public Product findProductById(int id);
//以小类id查询产品的	  
  public List<Product> findProductDao(int tid);
  //以小类id和pname来模糊查询数据：
  public List<Product> findProductDaoPname(Page page,int tid,String pname);
//增加产品的中全部数据
  public void addProductDaoAll(Product product);

//修改产品的全部内容
  public void  updateProductDaoAll(int id,String pname,int isbargain,double price,double marketprice,int pcount ,
	      String pexp ,String pic,double pdiscount ,int tid,int mistid);
  //修改其中是否特价
  public void updateProductDaoIs(int isprefered,int id);
//修改产品的数据
  public boolean updateProductDaoCounnt(int id,int pcount);
  public void updateProductDaoAllCounnt(int id,int pcount);
  
  public List<Product> findProductById1(int id);

}
