package com.ecjtu.dao;

import java.util.List;

import com.ecjtu.pojo.Type;

public interface TypeDao {

   public List<Type> findTypesByTid(int tid);

   public void addTypes(Type type,int tid);

   public void removeTypes(int id);

   public void updateTypes(int id,String name,String exp);

   public void removeCtypes(int tid);

   public Type findTypeById(int id);
   
   public Type findChildrenTypesByTid(int tid);
	//遍历大类和小类，通过一个id查找出大类和小类。
 
  public Type findParentTypesByTid(int tid);
}
