package com.ecjtu.dao;

import java.util.List;

import com.ecjtu.pojo.Page;
import com.ecjtu.pojo.User;

public interface UserDao {
public List<User> findUser(Page page);
public   int  getUserAcount();
	public User findUserByUsername(String username);//��½
		
	public User findUserById(int id);
	
    public void Login(String username, String password);
    public User findUserByUidUname(int uid ,String username);
			
    public void addUser(String username, String email,String password, String address, String postcode, String phone,String realname,String province, String city, String area);

	
	public void updateUserPassword(String username,String password);
	public void updateUser(int id , String address, String postcode, String phone,String realname,String province, String city, String area);
	public void updateUserLocks(int uid ,String locks);
	
}
