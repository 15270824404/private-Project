package com.ecjtu.dao.impl;

public class CartDao4MySqlImpl {

}
