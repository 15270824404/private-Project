package com.ecjtu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.ecjtu.dao.CommentDao;
import com.ecjtu.pojo.Comment;
import com.ecjtu.pojo.Product;
import com.ecjtu.pojo.Type;
import com.ecjtu.util.DBUtil;

public class CommentDao4MySqlImpl implements CommentDao {
	
	public List<Comment> findComments() {
		List<Comment> comment = new ArrayList<Comment>();
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_comment");
		ResultSet rs = null;
		Comment comments = null;
		try {
			
			rs =  DBUtil.getRs(pstmt);
			while(rs.next()){
				comments = new Comment();
				comments.setId(rs.getInt(1));
				comments.setAddtime(rs.getTimestamp(2));
				comments.setContent(rs.getString(3));
				
				comments.setProduct(new ProductDao4MySqlImpl().findProductById(rs.getInt(4)));
				comments.setUser(new UserDao4MySqlImpl().findUserById(rs.getInt(5)));
				comment.add(comments);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt, rs);
		return comment;
	}

	public void addComment(Comment comm,int pid,int uid) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"insert into t_comment values(null,?,?,?,?)");
		try {
		    pstmt.setTimestamp(1,comm.getAddtime());
			pstmt.setString(2,comm.getContent());
			pstmt.setInt(3, pid);
			pstmt.setInt(4, uid);
	        pstmt.executeUpdate(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
		
	}

}
