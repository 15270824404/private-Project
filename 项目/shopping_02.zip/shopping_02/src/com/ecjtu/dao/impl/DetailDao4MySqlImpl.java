package com.ecjtu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ecjtu.dao.DetailDao;
import com.ecjtu.dao.ProductDao;
import com.ecjtu.factory.ProductDaoFactory;
import com.ecjtu.pojo.Detail;
import com.ecjtu.util.DBUtil;

public class DetailDao4MySqlImpl implements DetailDao {
	private static ProductDao productDao;
	static {
		productDao = ProductDaoFactory.getInstance();	
		
	}

	public List<Detail> findDetailByOid(int oid) {
		List<Detail> details=new ArrayList<Detail>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_detail where oid=?");
		ResultSet rs=null;
		try {
			pstmt.setInt(1, oid);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				Detail detail=new Detail();
				detail.setNum(rs.getInt("num"));
				detail.setProduct(productDao.findProductById1(rs.getInt("pid")));
				details.add(detail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return details;
	}

	public double findSumPrice(int oid) {
		double sumPrice=0.0;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_detail where oid=?");
		ResultSet rs=null;
		try {
			pstmt.setInt(1,oid);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				sumPrice+=(productDao.findProductById1(rs.getInt("pid")).get(0).getPrice())*rs.getInt("num");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println(sumPrice);
		return sumPrice;
	}
	
	public boolean addDetail(int pid,int oid,int num){
		boolean bool =  productDao.updateProductDaoCounnt(pid, num);
		if(bool){
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "insert into  t_detail values(null,?,?,?)");
		ResultSet rs=null;
		try {
			pstmt.setInt(1,pid);
			pstmt.setInt(2, oid);
            pstmt.setInt(3, num);
            pstmt.executeUpdate();           		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		}
		return bool;
	}
	public List<Detail> findDetail() {
		List<Detail> details=new ArrayList<Detail>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select *, sum(num) n from t_detail group by pid order by n desc  limit ?,? ");
		ResultSet rs=null;
		try {
			pstmt.setInt(1, 0);
			pstmt.setInt(2, 10);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				Detail detail=new Detail();
//				detail.setNum(rs.getInt("num"));
				detail.setNum(rs.getInt("n"));
//				detail.setProduct(productDao.findProductById1(rs.getInt(1)));
				detail.setProduct1(productDao.findProductById(rs.getInt("pid")));
				details.add(detail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return details;
	}
}


