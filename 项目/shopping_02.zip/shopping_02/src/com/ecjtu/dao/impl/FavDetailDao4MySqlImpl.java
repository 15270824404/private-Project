package com.ecjtu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ecjtu.dao.FavDetailDao;
import com.ecjtu.dao.ProductDao;
import com.ecjtu.dao.UserDao;
import com.ecjtu.factory.ProductDaoFactory;
import com.ecjtu.factory.UserDaoFactory;
import com.ecjtu.pojo.FavDetail;
import com.ecjtu.util.DBUtil;



public class FavDetailDao4MySqlImpl implements FavDetailDao {
	  private static ProductDao productDao ;
	  private static UserDao userDao;
	  static {
		  productDao = ProductDaoFactory.getInstance();
		  userDao = UserDaoFactory.getInstance();
	  }
     
       
       public List<FavDetail> findFavDetail(int uid){
    	   List<FavDetail> list = new ArrayList<FavDetail>();
    	   FavDetail  favDetail = null;
    	   Connection conn = DBUtil.getConn();
    	   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_favorites where uid=?");
    	   ResultSet rs = null; 
    	   try {    		   
   			pstmt.setInt(1, uid);
   		    rs = DBUtil.getRs(pstmt);
   		    while(rs.next()){
   		    	favDetail = new FavDetail();
   		    	favDetail.setId(rs.getInt(1));
   		    	favDetail.setPdate(rs.getTimestamp(2));
   		    	favDetail.setProduct(productDao.findProductById(rs.getInt(3)));
   		    	favDetail.setUser(userDao.findUserById(uid));
//   		    	System.out.println(favDetail.getProduct().getPrice());
   		    	list.add(favDetail);
   		    	
   		    }			
   		} catch (SQLException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}finally{
   			DBUtil.getClose(conn, pstmt, null);
   		}
    	   return list;
    	   
       }
       public int findFavDetailByPid(int uid,int pid){
    	   Connection conn = DBUtil.getConn();
    	   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select pid from t_favorites where uid=?");
    	   ResultSet rs = null;   
    	   try {    		   
   			pstmt.setInt(1, uid);
   		    rs = DBUtil.getRs(pstmt);
   		    while(rs.next()){
   		    	if(rs.getInt(1) == pid){			
   		    		return 0;   		    		
   		    	}   		    		    	
   		    }		
   		} catch (SQLException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}finally{
   			DBUtil.getClose(conn, pstmt, null);
   		}    	   
    	   return 1;
       }
       
       public void addfavDetailByUPid(int uid,int pid){
    	   FavDetail  favDetail = null;
    	   Connection conn = DBUtil.getConn();
    	   PreparedStatement pstmt = DBUtil.getPstmt(conn, "insert into  t_favorites values(null,now(),?,?)");    	   
    	   try {
			pstmt.setInt(1, pid);
			pstmt.setInt(2, uid);
		    pstmt.executeUpdate();	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, null);
		}
       }
}
