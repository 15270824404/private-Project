package com.ecjtu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ecjtu.dao.ManagerDao;
import com.ecjtu.pojo.Manager;
import com.ecjtu.util.DBUtil;

public class ManagerDao4MySql implements ManagerDao {

	public Manager findManager(String username) {
		Manager manager=null;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_manager where username=?");
		ResultSet rs=null;
		try {
			pstmt.setString(1,username);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				manager=new Manager();
				manager.setPassword(rs.getString("password"));
				manager.setUsername(rs.getString("username"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return manager;
	}

}
