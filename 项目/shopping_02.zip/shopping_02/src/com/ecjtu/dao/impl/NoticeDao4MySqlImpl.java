package com.ecjtu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.ecjtu.dao.NoticeDao;
import com.ecjtu.pojo.Notice;
import com.ecjtu.pojo.Page;
import com.ecjtu.util.DBUtil;

public class NoticeDao4MySqlImpl implements NoticeDao {
	
	public List<Notice> findNoticesForTitle(Page page) {
		List<Notice> notices = new ArrayList<Notice>();
		Connection conn = DBUtil.getConn();
		ResultSet rs = null;
		Notice notice = null;
		 PreparedStatement pstmt = null;
		if(page == null){			
		 pstmt = DBUtil.getPstmt(conn,"select * from t_notice");					
		}else{		
	     pstmt = DBUtil.getPstmt(conn,"select * from t_notice limit ?,?");		
		 page.setTotalPage(getNoticeAcount());
         page.setCurrentPage(page.getCurrentPage());
 		 page.setTotalPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);
			try {
				pstmt.setInt(1, (page.getCurrentPage()-1)*page.getMaxResult());
				pstmt.setInt(2, page.getMaxResult());	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}   				 
		}try {				
			 rs =DBUtil.getRs(pstmt);
			 while(rs.next()){
				 notice = new Notice(); 
				 notice.setId(rs.getInt(1));
				 notice.setTitle(rs.getString(2));
				 notice.setContent(rs.getString(3));
				 notice.setFdate(rs.getString(4));
				 notice.setSdate(rs.getString(5));
				 notices.add(notice);	 
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return notices;
	}
	public   int  getNoticeAcount(){
   	 int count = 0;
   	 Connection conn = DBUtil.getConn();
   	 PreparedStatement pstmt = DBUtil.getPstmt(conn, "select count(*) from t_notice");
   	 ResultSet rs = null;
   	 try {
			rs = pstmt.executeQuery();
			 while(rs.next()){
	    		 count = rs.getInt(1);
	    	 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}    	  
   	 
   	 return count;
    }

	public Notice findNotice(int id) {
		Notice notice = null;
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_notice where id=?");
		ResultSet rs = null;
		try {
			
			pstmt.setInt(1,id);
			 rs =DBUtil.getRs(pstmt);
			 while(rs.next()){
				 notice = new Notice(); 
				 notice.setId(rs.getInt(1));
				 notice.setTitle(rs.getString(2));
				 notice.setContent(rs.getString(3));
				 notice.setFdate(rs.getString(4));
				 notice.setSdate(rs.getString(5));
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt, rs);
		return notice;
	}

	public void addNotice(Notice notice) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"insert into t_notice values(null,?,?,?,?)");
		try {
			pstmt.setString(1, notice.getTitle());
			pstmt.setString(2, notice.getContent());
			pstmt.setString(3, notice.getFdate());
			pstmt.setString(4,notice.getSdate());
	        pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
	
		
	}

	public void removeTypes(int id) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"delete from t_notice where id=?");
		try {
			pstmt.setInt(1,id);
			
	        pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
		
	}

	public void updateTypes(int id, String title, String content,
			String fdate, String sdate) {

		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_notice set title=?,content=?,fdate=?,sdate=? where id=?");
		try {
			
			 pstmt.setString(1, title);		      
		     pstmt.setString(2, content);
		     pstmt.setString(3, fdate);
		     pstmt.setString(4, sdate);
		     pstmt.setInt(5,id);
	         pstmt.executeUpdate();
	        
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		DBUtil.getClose(conn, pstmt,null);
	}	
}
