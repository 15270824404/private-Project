package com.ecjtu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ecjtu.dao.DetailDao;
import com.ecjtu.dao.OrderDao;
import com.ecjtu.dao.ProductDao;
import com.ecjtu.dao.UserDao;
import com.ecjtu.factory.DetailFactoty;
import com.ecjtu.factory.ProductDaoFactory;
import com.ecjtu.factory.UserDaoFactory;
import com.ecjtu.pojo.Order;
import com.ecjtu.pojo.Page;
import com.ecjtu.util.DBUtil;

public class OrderDao4MySqlImpl implements OrderDao {
      private static DetailDao detailDao;
	  private static UserDao userDao;
	  static {		
		  detailDao = DetailFactoty.getInstance();
		  userDao = UserDaoFactory.getInstance();
	  }

	public List<Order> findOrders() {
		List<Order> orders=new ArrayList<Order>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_order");
		ResultSet rs=null;
		try {
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				Order order=new Order();
				order.setId(rs.getInt("id"));
				order.setSumPrice(detailDao.findSumPrice(rs.getInt("id")));
				order.setOdate(rs.getTimestamp("odate"));
				order.setDetail(detailDao.findDetailByOid(rs.getInt("id")));
				order.setTexp(rs.getString("texp"));
				order.setUser( userDao.findUserById(rs.getInt("uid")));
				order.setState(rs.getInt("state"));
				orders.add(order);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orders;
	}
	public List<Order> findOrdersByUid(int uid) {
		List<Order> orders=new ArrayList<Order>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_order where uid=?");
		ResultSet rs=null;
		try {
			pstmt.setInt(1, uid);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				Order order=new Order();
				order.setId(rs.getInt("id"));
				order.setSumPrice(detailDao.findSumPrice(rs.getInt("id")));
				order.setOdate(rs.getTimestamp("odate"));
				order.setDetail(detailDao.findDetailByOid(rs.getInt("id")));
				order.setTexp(rs.getString("texp"));
				order.setUser( userDao.findUserById(rs.getInt("uid")));
				order.setState(rs.getInt("state"));
				orders.add(order);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orders;
	}

	public Order findOrder(int id) {
		Order order=new Order();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_order where id=?");
		ResultSet rs=null;
		try {
			pstmt.setInt(1,id);
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				order.setId(rs.getInt("id"));
				order.setSumPrice(detailDao.findSumPrice(rs.getInt("id")));
				order.setTexp(rs.getString("texp"));
				order.setUser(userDao.findUserById(rs.getInt("uid")));
				order.setIsbill(rs.getString("isbill"));
				order.setPaytype(rs.getString("paytype"));
				order.setContent(rs.getString("content"));
				order.setSendtype(rs.getString("sendtype"));
				order.setOdate(rs.getTimestamp("odate"));
				order.setDetail(detailDao.findDetailByOid(rs.getInt("id")));
			    order.setState(rs.getInt("state"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return order;
	}

	public void renew(int id) {
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "delete from t_order where id=?");
		try {
			pstmt.setInt(1,id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public int findCount() {
		int count=0;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select count(*) from t_order");
		ResultSet rs=DBUtil.getRs(pstmt);
		try {
			while(rs.next()){
				count=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public List<Order> findOrdersByPage(Page page) {
		List<Order> orders=new ArrayList<Order>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_order limit ?,?");
		ResultSet rs=null;
		page.setCurrentPage(page.getCurrentPage());
		page.setTotalResult(findCount());
		page.setTotalPage(page.getTotalResult()%page.getMaxResult()==0?page.getTotalResult()/page.getMaxResult():page.getTotalResult()/page.getMaxResult()+1);
		try {
			pstmt.setInt(1,(page.getCurrentPage()-1)*page.getMaxResult());
			pstmt.setInt(2, page.getMaxResult());
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				Order order=new Order();
				order.setId(rs.getInt("id"));
				order.setSumPrice(detailDao.findSumPrice(rs.getInt("id")));
				order.setOdate(rs.getTimestamp("odate"));
				order.setDetail(detailDao.findDetailByOid(rs.getInt("id")));
				order.setTexp(rs.getString("texp"));
				order.setUser(userDao.findUserById(rs.getInt("uid")));
				order.setState(rs.getInt("state"));
				orders.add(order);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orders;
	}
	public List<Order> findOrdersById(Page page,int id,String texp) {
		List<Order> orders=new ArrayList<Order>();
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		page.setCurrentPage(page.getCurrentPage());
		page.setTotalResult(findCount());
		page.setTotalPage(page.getTotalResult()%page.getMaxResult()==0?page.getTotalResult()/page.getMaxResult():page.getTotalResult()/page.getMaxResult()+1);
		
		if(id > 0){
		 pstmt=DBUtil.getPstmt(conn, "select * from t_order where id=? limit ?,?");
		 try {
			pstmt.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}else{
			pstmt=DBUtil.getPstmt(conn, "select * from t_order where texp=? limit ?,?");
			try {
				pstmt.setString(1, texp);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			
			pstmt.setInt(2,(page.getCurrentPage()-1)*page.getMaxResult());
			pstmt.setInt(3, page.getMaxResult());
			rs=DBUtil.getRs(pstmt);
			while(rs.next()){
				Order order=new Order();
				order.setId(rs.getInt("id"));
				order.setSumPrice(detailDao.findSumPrice(rs.getInt("id")));
				order.setOdate(rs.getTimestamp("odate"));
				order.setDetail(detailDao.findDetailByOid(rs.getInt("id")));
				order.setTexp(rs.getString("texp"));
				order.setUser(userDao.findUserById(rs.getInt("uid")));
				order.setState(rs.getInt("state"));
				orders.add(order);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orders;
	}
	public int  addOrder(int uid,String isbill,String paytype,String content,String sendtype) {
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "insert into t_order values(null,'新订单',?,?,?,?,?,now(),1)");
//		PreparedStatement pstmt1 =DBUtil.getPstmt(conn, "select id from t_order ");
		
		try {
			pstmt.setInt(1, uid);
			pstmt.setString(2, isbill);
			pstmt.setString(3, paytype);
			pstmt.setString(4, content);
			pstmt.setString(5, sendtype);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return findNewOrderId();
	}
	public int findNewOrderId(){
		int id = 0;
		Connection conn=DBUtil.getConn();
		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select id from t_order where id=(select max(id) from t_order)");
		ResultSet rs=DBUtil.getRs(pstmt);
		try {
			while(rs.next()){
				id=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		return id;
	}
}
