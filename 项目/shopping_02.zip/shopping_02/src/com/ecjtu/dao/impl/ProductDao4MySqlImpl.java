package com.ecjtu.dao.impl;

import com.ecjtu.dao.ProductDao;
import com.ecjtu.dao.TypeDao;
import com.ecjtu.factory.TypeFactory;
import com.ecjtu.pojo.Page;
import com.ecjtu.pojo.Product;
import com.ecjtu.pojo.Type;
import com.ecjtu.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProductDao4MySqlImpl implements ProductDao {
	private static TypeDao typeDao;
	static {
		typeDao = TypeFactory.getInstance();	
		
	}
	    //查询所有产品
	public List<Product> findProductDaoAll(){
		   List<Product> products = new ArrayList<Product>();
		   Connection conn = DBUtil.getConn();
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_product where isprefered=1");
		   ResultSet rs = null;
		   
		   try {			  
			rs = DBUtil.getRs(pstmt);
			while(rs.next()){
				Product product = new Product();
				product.setId(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setIsbargain(rs.getInt(3));
				product.setPrice(rs.getDouble(4));
				product.setMarketprice(rs.getDouble(5));
				product.setPcount(rs.getInt(6));
				product.setIsprefered(rs.getInt(7));
				product.setPexp(rs.getString(8));
				product.setPic(rs.getString(9));
				product.setPdate(rs.getTimestamp(10));
				product.setPdiscount(rs.getDouble(11));
				product.setParent(null);
				product.setChildren(null);
				products.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		   return products;
	   }
	public   int  getProductAcount(String pname,int tid,int mistid){
   	 int count = 0;
   	 Connection conn = DBUtil.getConn();
   	PreparedStatement pstmt = null;
   	 if(mistid == 0){
   		pstmt = DBUtil.getPstmt(conn, "select count(*) from t_product where isprefered=1  and  pname like? and tid=? ");
   		try{
   	   		if(pname != null){
   			   pstmt.setString(1, "%"+pname+"%");
   			   }else{
   				   pstmt.setString(1, "%%");  
   			   }			   
   			   pstmt.setInt(2, tid);
   			 
   	   	    } catch (SQLException e) {
   				// TODO Auto-generated catch block
   				e.printStackTrace();
   			}
   	 }else{
   		pstmt = DBUtil.getPstmt(conn, "select count(*) from t_product where isprefered=1  and  pname like? and tid=? and mistid=?");
   	    try{
   		if(pname != null){
		   pstmt.setString(1, "%"+pname+"%");
		   }else{
			   pstmt.setString(1, "%%");  
		   }			   
		   pstmt.setInt(2, tid);
		   pstmt.setInt(3, mistid);
   	    } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   	 }   	 
   	 ResultSet rs = null;
   	 try {   		     
			rs = pstmt.executeQuery();
			 while(rs.next()){
	    		 count = rs.getInt(1);
	    	 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}    	  
   	 
   	 return count;
    }
	public   int  getProductAcount1(int i){
	   	 int count = 0;
	   	 Connection conn = DBUtil.getConn();
	   	PreparedStatement pstmt = null;
	   	 if(i==0){
	   	    pstmt = DBUtil.getPstmt(conn, "select count(*) from t_product where isprefered=1");
	   	 }else{
	   		pstmt = DBUtil.getPstmt(conn, "select count(*) from t_product where isprefered=1 and isbargain=0 "); 
	   	 }
	   	 ResultSet rs = null;
	   	 try {	   		      
				rs = pstmt.executeQuery();
				 while(rs.next()){
		    		 count = rs.getInt(1);
		    	 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}     
	   	 
	   	 return count;
	    }
	public Product findProductById(int id){	
		Product product = null;
		   Connection conn = DBUtil.getConn();
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_product where  isprefered=1 and id=?");
		   ResultSet rs = null;
		   
		   try {
			   pstmt.setInt(1, id);
			rs = DBUtil.getRs(pstmt);
			while(rs.next()){
				product = new Product();
				product.setId(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setIsbargain(rs.getInt(3));
				product.setPrice(rs.getDouble(4));
				product.setMarketprice(rs.getDouble(5));
				product.setPcount(rs.getInt(6));
				product.setIsprefered(rs.getInt(7));
				product.setPexp(rs.getString(8));
				product.setPic(rs.getString(9));
				product.setPdate(rs.getTimestamp(10));
				product.setPdiscount(rs.getDouble(11));
				product.setParent(typeDao.findParentTypesByTid(rs.getInt(12)));
				product.setChildren(typeDao.findChildrenTypesByTid(rs.getInt(13)));		
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		   return product;
	   }
	   //以id来查询是否特价
	   public List<Product> findProductDaoIsbargainAll(Page page){
		   List<Product> products = new ArrayList<Product>();
		   Connection conn = DBUtil.getConn();
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_product where isprefered=1 and isbargain=0 limit ?,?");
		   ResultSet rs = null;		  
		   page.setTotalPage(getProductAcount1(1));
	         page.setCurrentPage(page.getCurrentPage());
	 		 page.setTotalPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);	
	 		
		   try {
			   pstmt.setInt(1, (page.getCurrentPage()-1)*page.getMaxResult());
	    	   pstmt.setInt(2, page.getMaxResult());
			rs = DBUtil.getRs(pstmt);
			while(rs.next()){
				Product product = new Product();
				product.setId(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setIsbargain(rs.getInt(3));
				product.setPrice(rs.getDouble(4));
				product.setMarketprice(rs.getDouble(5));
				product.setPcount(rs.getInt(6));
				product.setIsprefered(rs.getInt(7));
				product.setPexp(rs.getString(8));
				product.setPic(rs.getString(9));
				product.setPdate(rs.getTimestamp(10));
				product.setPdiscount(rs.getDouble(11));
				product.setParent(null);
				product.setChildren(null);
				products.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		   return products;
	   }
	   //查询个别的特价
	   public Product findProductDaoIsbargainOnly(int id){
		   Product product = null;
		   Connection conn = DBUtil.getConn();
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_product where isprefered=1 and isbargain=0 and id=?");
		   ResultSet rs = null;
		   try {
			   pstmt.setInt(1,id);
			rs = DBUtil.getRs(pstmt);
			while(rs.next()){
				 product = new Product();
				product.setId(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setIsbargain(rs.getInt(3));
				product.setPrice(rs.getDouble(4));
				product.setMarketprice(rs.getDouble(5));
				product.setPcount(rs.getInt(6));
				product.setIsprefered(rs.getInt(7));
				product.setPexp(rs.getString(8));
				product.setPic(rs.getString(9));
				product.setPdate(rs.getTimestamp(10));
				product.setPdiscount(rs.getDouble(11));
				product.setParent(null);
				product.setChildren(null);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		   return product;
	   }
	   //查询最新的产品，会员
	   public List<Product> findProductDaoIsprefered(Page page){
		   List<Product> products = new ArrayList<Product>();
		   Connection conn = DBUtil.getConn();
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_product where isprefered=1 and pdate>'2012-09-27 20:59:28.0' limit ?,? ");
		   ResultSet rs = null;
		     page.setTotalPage(getProductAcount1(0));
	         page.setCurrentPage(page.getCurrentPage());
	 		 page.setTotalPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);	
	 		
		   try {
			   pstmt.setInt(1, (page.getCurrentPage()-1)*page.getMaxResult());
	    	   pstmt.setInt(2, page.getMaxResult());
			rs = DBUtil.getRs(pstmt);
			while(rs.next()){
				Product product = new Product();
				product.setId(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setIsbargain(rs.getInt(3));
				product.setPrice(rs.getDouble(4));
				product.setMarketprice(rs.getDouble(5));
				product.setPcount(rs.getInt(6));
				product.setIsprefered(rs.getInt(7));
				product.setPexp(rs.getString(8));
				product.setPic(rs.getString(9));
				product.setPdate(rs.getTimestamp(10));
				product.setPdiscount(rs.getDouble(11));
				product.setParent(null);
				product.setChildren(null);
				products.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		   return products;
	   }
	   //查询以id来查询到产品的数量，会员
	   public int findProductDaoAcount(int id){
		   Connection conn = DBUtil.getConn();
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select pcount from t_product where isprefered=1 and id=?");
		   ResultSet rs = null;		
		   int pcount = 0 ;
			try {
				pstmt.setInt(1, id);
				rs = DBUtil.getRs(pstmt);
				while(rs.next()){
				     pcount = rs.getInt(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}
	       return  pcount;
	   }
	   //以小类tid查询产品的，会员  
	   public List<Product> findProductDao(int tid ){
		   List<Product> products = new ArrayList<Product>();
		   Connection conn = DBUtil.getConn();
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_product where isprefered=1 and mistid=?");
		   ResultSet rs = null;
		   try {  
			   pstmt.setInt(1, tid);
			rs = DBUtil.getRs(pstmt);
			while(rs.next()){
				Product product = new Product();
				product.setId(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setIsbargain(rs.getInt(3));
				product.setPrice(rs.getDouble(4));
				product.setMarketprice(rs.getDouble(5));
				product.setPcount(rs.getInt(6));
				product.setIsprefered(rs.getInt(7));
				product.setPexp(rs.getString(8));
				product.setPic(rs.getString(9));
				product.setPdate(rs.getTimestamp(10));
				product.setPdiscount(rs.getDouble(11));
				product.setParent(typeDao.findParentTypesByTid(rs.getInt(12)));
				product.setChildren(typeDao.findChildrenTypesByTid(tid));
				products.add(product);	
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		   return products;
	   }
	   //以大类id和pname来模糊查询数据：会员
	   public List<Product> findProductDaoPname(Page page,int tid,String pname){
		   List<Product> products = new ArrayList<Product>();
		   Connection conn = DBUtil.getConn();		  
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_product  where isprefered=1 and  pname like? and tid=?");
		    
		   Product product = null;
		   ResultSet rs = null;
		   try {
			   if(pname != null){
			   pstmt.setString(1, "%"+pname+"%");
			   }else{
				   pstmt.setString(1, "%%");  
			   }			   
			   pstmt.setInt(2, tid);
			   rs = DBUtil.getRs(pstmt);
			while(rs.next()){
				product = new Product();
				product.setId(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setIsbargain(rs.getInt(3));
				product.setPrice(rs.getDouble(4));
				product.setMarketprice(rs.getDouble(5));
				product.setPcount(rs.getInt(6));
				product.setIsprefered(rs.getInt(7));
				product.setPexp(rs.getString(8));
				product.setPic(rs.getString(9));
				product.setPdate(rs.getTimestamp(10));
				product.setPdiscount(rs.getDouble(11));
				product.setParent(typeDao.findParentTypesByTid(tid));
				product.setChildren(typeDao.findChildrenTypesByTid(rs.getInt(13)));				
				products.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		   return products;
	   }
	   public List<Product> findProductDaoPname1(Page page,int tid,String pname,int mistid){
		   List<Product> products = new ArrayList<Product>();
		   Connection conn = DBUtil.getConn();		  
		   PreparedStatement pstmt = DBUtil.getPstmt(conn, "select * from t_product  where isprefered=1 and  pname like? and tid=? and mistid=? limit ?,?");
		   page.setTotalPage(getProductAcount(pname,tid,mistid));
	         page.setCurrentPage(page.getCurrentPage());
	 		 page.setTotalPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);	
	 		Product product = null;
		   ResultSet rs = null;
		   try {
			   if(pname != null){
			   pstmt.setString(1, "%"+pname+"%");
			   }else{
				   pstmt.setString(1, "%%");  
			   }			   
			   pstmt.setInt(2, tid);
			   pstmt.setInt(3, mistid);
			   pstmt.setInt(4, (page.getCurrentPage()-1)*page.getMaxResult());
	    	   pstmt.setInt(5, page.getMaxResult());
			   rs = DBUtil.getRs(pstmt);
			while(rs.next()){
				product = new Product();
				product.setId(rs.getInt(1));
				product.setPname(rs.getString(2));
				product.setIsbargain(rs.getInt(3));
				product.setPrice(rs.getDouble(4));
				product.setMarketprice(rs.getDouble(5));
				product.setPcount(rs.getInt(6));
				product.setIsprefered(rs.getInt(7));
				product.setPexp(rs.getString(8));
				product.setPic(rs.getString(9));
				product.setPdate(rs.getTimestamp(10));
				product.setPdiscount(rs.getDouble(11));
				product.setParent(typeDao.findParentTypesByTid(tid));
				product.setChildren(typeDao.findChildrenTypesByTid(rs.getInt(13)));				
				products.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, rs);
		}
		   return products;
	   }
	   
	  //增加产品的中全部数据，管理员
      public void addProductDaoAll(Product product){
    	  Connection conn = DBUtil.getConn();
    	  PreparedStatement  pstmt = DBUtil.getPstmt(conn,"insert into t_product values(null,?,?,?,?,?,1,?,?,now(),?,?,?)");
    	  try {
    		  pstmt.setString(1,product.getPname());
    		  pstmt.setInt(2, product.getIsbargain());
    		  pstmt.setDouble(3, product.getPrice());
    		  pstmt.setDouble(4,product.getMarketprice());
    		  pstmt.setInt(5, product.getPcount()); 
    		  pstmt.setString(6, product.getPexp());
    		  pstmt.setString(7, product.getPic());
    		  pstmt.setDouble(8, product.getPdiscount());
    		  pstmt.setInt(9, product.getParent().getId());
    		  pstmt.setInt(10, product.getChildren().getId());
    		  pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, null);
		}    	  
      }
 
      //修改产品的全部内容，管理员
      public void updateProductDaoAll(int id,String pname,int isbargain,double price,double marketprice,int pcount ,
    	      String pexp ,String pic,double pdiscount ,int tid,int mistid){
    	  Connection conn = DBUtil.getConn();
    	  PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_product set pname=?,isbargain=?," +
    	  		"price=?,marketprice=?,pcount=?,pexp=?,pic=?,pdiscount=?,tid=?,mistid =? where id=?");
    	  try {
    		  pstmt.setString(1,pname);
    		  pstmt.setInt(2, isbargain);
    		  pstmt.setDouble(3, price);
    		  pstmt.setDouble(4, marketprice);
    		  pstmt.setInt(5, pcount);
    		  pstmt.setString(6, pexp);
    		  pstmt.setString(7, pic);
    		  pstmt.setDouble(8, pdiscount);
    		  pstmt.setInt(9, tid);    		
    		  pstmt.setInt(10, mistid);
    		  pstmt.setInt(11, id);
    		  pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, null);
		}
      } 
      //修改其中是否隐藏,管理员
      public void updateProductDaoIs(int isprefered,int id){
    	  Connection conn = DBUtil.getConn();
    	  PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_product set isprefered=0 where id=?");
    	  try {
    		  pstmt.setInt(1,id);
    		  pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, null);
		}
      }
      //修改产品的总的数据，管理员
      public void updateProductDaoAllCounnt(int id,int pcount){
    	  Connection conn = DBUtil.getConn();
    	  PreparedStatement pstem = DBUtil.getPstmt(conn,"update t_product set pcount=? where id=?");
    	  int count = findProductDaoAcount(id);
    	  try {
			pstem.setInt(2,id);
			pstem.setInt(1, pcount+count);
			pstem.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstem, null);
		}
      }
      //当购买的是时候更改数量需要知道总量,返回一个布尔类型，已得到能不能购买
      public boolean updateProductDaoCounnt(int id,int pcount){
    	  int allCount = findProductDaoAcount(id);
    	  if(pcount <= allCount ){
    	  int count = allCount - pcount;
          Connection conn = DBUtil.getConn();
    	  PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_product set pcount=? where id=?");
    	  try {
    		  pstmt.setInt(2,id);
    		  pstmt.setInt(1, count);
    		  pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.getClose(conn, pstmt, null);
		}
    	  return true;
    	  }else{
    		  return false;
    	  }
      }
      
      public List<Product> findProductById1(int id) {
  	    List<Product> products=new ArrayList<Product>();
  		Connection conn=DBUtil.getConn();
  		PreparedStatement pstmt=DBUtil.getPstmt(conn, "select * from t_product where id=?");
  		ResultSet rs=null;
  		try {
  			pstmt.setInt(1,id);
  			rs=DBUtil.getRs(pstmt);
  			while(rs.next()){
  				Product product=new Product();
  				product.setPname(rs.getString("pname"));
  				product.setPrice(rs.getDouble("price"));
  				products.add(product);
  			}
  		} catch (SQLException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
  		return products;
  	}

	
	

  
}
