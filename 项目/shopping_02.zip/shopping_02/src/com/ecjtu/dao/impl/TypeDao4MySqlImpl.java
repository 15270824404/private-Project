package com.ecjtu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ecjtu.dao.TypeDao;
import com.ecjtu.pojo.Type;
import com.ecjtu.util.DBUtil;

public class TypeDao4MySqlImpl implements TypeDao {
	
	

	public void addTypes(Type type, int tid) {
		
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"insert into t_type values(null,?,?,?)");
		try {
			
			pstmt.setString(1,type.getName());
			pstmt.setString(2, type.getExp());
			pstmt.setInt(3,tid);
	        pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
	
	}

	public void removeTypes(int id) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"delete from t_type where id=?");
		try {
			pstmt.setInt(1,id);
			
	        pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
		
	}

	public void updateTypes(int id,String name,String exp) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_type set name=?,exp=? where id=?");
		try {
		//���ʺ�˳������ֵ������÷�����û���á�
			 pstmt.setString(1, name);		      
		     pstmt.setString(2, exp);
		     pstmt.setInt(3,id);
	         pstmt.executeUpdate();		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
		
	}

	public Type findTypeById(int id) {
		Type types =null;
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_type where id=?");
		ResultSet rs = null;		
		try {
			pstmt.setInt(1,id);
			rs =  DBUtil.getRs(pstmt);
			
			while(rs.next()){
				types = new Type();
				types.setId(rs.getInt(1));
				types.setName(rs.getString(2));
				types.setExp(rs.getString(3));
				//�����������������ˣ���
				//types.setParent((Type)this.findTypesByTid(rs.getInt(4)));
				//types.setChildren(findTypesByTid(rs.getInt(4)));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt, rs);
		return types;
	}

	public void removeCtypes(int tid) {
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = DBUtil.getPstmt(conn,"delete from t_type where id=?");
		try {
			pstmt.setInt(1,tid);
			
	        pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.getClose(conn, pstmt,null);
		
		
	}
	//遍历大类和小类，通过一个tid查找出大类和小类。
		public List<Type> findTypesByTid(int tid) {
			List<Type> type = new ArrayList<Type>();
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_type where tid=?");
			ResultSet rs = null;
			Type types = null;
			try {
				pstmt.setInt(1,tid);
				rs =  DBUtil.getRs(pstmt);
				
				while(rs.next()){
					types = new Type();
					types.setId(rs.getInt(1));
					types.setName(rs.getString(2));
					types.setExp(rs.getString(3));
					types.setParent(findParentTypesByTid(tid));
//					types.setChildren(findChildrenTypesByTid(tid));
					type.add(types);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();}
			DBUtil.getClose(conn, pstmt, rs);
			return type;
		}
		public Type findChildrenTypesByTid(int tid) {
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_type where id=?");
			ResultSet rs = null;
			Type type = null;
			try {
				pstmt.setInt(1,tid);
				rs =  DBUtil.getRs(pstmt);
				
				while(rs.next()){
					type = new Type();
					type.setId(rs.getInt(1));
					type.setName(rs.getString(2));
					type.setExp(rs.getString(3));
					//types.setParent();
					//types.getChildren();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();}
			DBUtil.getClose(conn, pstmt, rs);
			return type;
		}
		
		public Type findParentTypesByTid(int tid) {
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_type where id=? and tid=0");
			ResultSet rs = null;
			Type type = null;
			try {
				pstmt.setInt(1,tid);
				rs =  DBUtil.getRs(pstmt);
				
				while(rs.next()){
					type = new Type();
					type.setId(rs.getInt(1));
					type.setName(rs.getString(2));
					type.setExp(rs.getString(3));
					//types.setParent();
					//types.getChildren();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();}
			DBUtil.getClose(conn, pstmt, rs);
			return type;
		}

	
}
