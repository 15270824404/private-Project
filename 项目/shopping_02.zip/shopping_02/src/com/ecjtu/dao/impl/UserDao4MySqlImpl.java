package com.ecjtu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ecjtu.dao.UserDao;
import com.ecjtu.exception.PasswordErrorException;
import com.ecjtu.exception.UserfreezingException;
import com.ecjtu.exception.UsernameNotFoundException;
import com.ecjtu.pojo.Page;
import com.ecjtu.pojo.User;
import com.ecjtu.util.DBUtil;

public class UserDao4MySqlImpl implements UserDao {

	
		public User findUserById(int id) {
			User user = null;
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_user where id=?");
			ResultSet rs =null;
			
			try {
				pstmt.setInt(1, id);
				rs=DBUtil.getRs(pstmt);
				while(rs.next()){
					user = new User();
					user.setId(rs.getInt(1));
					user.setUsername(rs.getString(2));
					user.setEmail(rs.getString(3));
					user.setPassword(rs.getString(4));
					user.setAddress(rs.getString(5));
					user.setPostcode(rs.getString(6));
					user.setPhone(rs.getString(7));
					user.setUserexp(rs.getString(8));
					user.setRealname(rs.getString(9));
					user.setLocks(rs.getString(10));
					user.setGrade(rs.getInt(11));
					user.setProvince(rs.getString(12));
					user.setCity(rs.getString(13));
					user.setArea(rs.getString(14));
					user.setUdate(rs.getTimestamp(15));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}
			return user;
		}

		public User findUserByUsername(String username) {
			User user = null;
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_user where username=?");
			ResultSet rs =null;
			
			try {
				pstmt.setString(1, username);
				rs=DBUtil.getRs(pstmt);
				while(rs.next()){
					user = new User();
					user.setId(rs.getInt(1));
					user.setUsername(rs.getString(2));
					user.setEmail(rs.getString(3));
					user.setPassword(rs.getString(4));
					user.setAddress(rs.getString(5));
					user.setPostcode(rs.getString(6));
					user.setPhone(rs.getString(7));
					user.setUserexp(rs.getString(8));
					user.setRealname(rs.getString(9));
					user.setLocks(rs.getString(10));
					user.setGrade(rs.getInt(11));
					user.setProvince(rs.getString(12));
					user.setCity(rs.getString(13));
					user.setArea(rs.getString(14));	
					user.setUdate(rs.getTimestamp(15));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}
			return user;
		}

		//�����û�
		public void addUser(String username, String email,String password, String address, String postcode, String phone,String realname,String province, String city, String area) {
			// TODO Auto-generated method stub
//			int n = -1;
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"insert into t_user value(null,?,?,?,?,?,?,'',?,'nolock',1,?,?,?,now())");
			try {
				//pstmt.setInt(1, user.getId());
				pstmt.setString(1,username);
				pstmt.setString(2, email);
				pstmt.setString(3,password);
				pstmt.setString(4, address);
				pstmt.setString(5, postcode);
				pstmt.setString(6, phone);				
				pstmt.setString(7, realname);
			
				pstmt.setString(8,province);
				pstmt.setString(9, city);
				pstmt.setString(10, area);
			    
			    pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				DBUtil.getClose(conn, pstmt, null);
			}
//			return n;
			
		}
		
		
		public void Login(String username, String password) {
			// TODO Auto-generated method stub
			Connection conn = DBUtil.getConn();
		      PreparedStatement pstmt = DBUtil.getPstmt(conn, "select password,locks from t_user where username=?");
		      ResultSet rs = null;       
		      try {
		         pstmt.setString(1, username);
		         rs =  DBUtil.getRs(pstmt);		         
		         if(rs.next()){
		              if(!password.equals(rs.getString(1))){
		                 throw new PasswordErrorException();		                 
		               }else{
		            	   if("locked".equals(rs.getString(2))){
		            		   throw new UserfreezingException();
		            	   }
		               }
		              }
		         else{
		              throw new UsernameNotFoundException();
		         } 
		         } catch (SQLException e) {
		   // TODO Auto-generated catch block
		     e.printStackTrace();
		     }finally{
		     DBUtil.getClose(conn, pstmt, rs);
		}
		}
		    
		public User findUserByUidUname(int uid ,String username) {
			User user = null;
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_user where username like? and id=?");
			ResultSet rs =null;
			
			try {				
				if(username != null){
					   pstmt.setString(1, "%"+username+"%");
					   }else{
						   pstmt.setString(1, "%%");  
					   }
				pstmt.setInt(2, uid);
				rs=DBUtil.getRs(pstmt);
				while(rs.next()){
					user = new User();
					user.setId(rs.getInt(1));
					user.setUsername(rs.getString(2));
					user.setEmail(rs.getString(3));
					user.setPassword(rs.getString(4));
					user.setAddress(rs.getString(5));
					user.setPostcode(rs.getString(6));
					user.setPhone(rs.getString(7));
					user.setUserexp(rs.getString(8));
					user.setRealname(rs.getString(9));
					user.setLocks(rs.getString(10));
					user.setGrade(rs.getInt(11));
					user.setProvince(rs.getString(12));
					user.setCity(rs.getString(13));
					user.setArea(rs.getString(14));	
					user.setUdate(rs.getTimestamp(15));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}
			return user;
		}
		
		
		public List<User> findUser(Page page) {
			List<User> users = new ArrayList<User>();
			Connection conn = DBUtil.getConn();
			User user =null;
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"select * from t_user limit ?,?");
			ResultSet rs = null;
			 page.setTotalPage(getUserAcount());
	         page.setCurrentPage(page.getCurrentPage());
	 		 page.setTotalPage(page.getTotalPage()%page.getMaxResult() == 0 ?  page.getTotalPage()/page.getMaxResult() : page.getTotalPage()/page.getMaxResult() +1);	
			try {
				pstmt.setInt(1, (page.getCurrentPage()-1)*page.getMaxResult());
	    		pstmt.setInt(2, page.getMaxResult());
	    		rs= DBUtil.getRs(pstmt);
				while(rs.next()){
					user = new User();
					user.setId(rs.getInt(1));
					user.setUsername(rs.getString(2));
					user.setEmail(rs.getString(3));
					user.setPassword(rs.getString(4));
					user.setAddress(rs.getString(5));
					user.setPostcode(rs.getString(6));
					user.setPhone(rs.getString(7));
					user.setUserexp(rs.getString(8));
					user.setRealname(rs.getString(9));
					user.setLocks(rs.getString(10));
					user.setGrade(rs.getInt(11));
					user.setProvince(rs.getString(12));
					user.setCity(rs.getString(13));
					user.setArea(rs.getString(14));
					user.setUdate(rs.getTimestamp(15));
					users.add(user);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}
			
			return users;
		}
		
	   

		public   int  getUserAcount(){
	    	 int count = 0;
	    	 Connection conn = DBUtil.getConn();
	    	 PreparedStatement pstmt = DBUtil.getPstmt(conn, "select count(*) from t_user");
	    	 ResultSet rs = null;
	    	 try {
				rs = pstmt.executeQuery();
				 while(rs.next()){
		    		 count = rs.getInt(1);
		    	 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}    	  
	    	 
	    	 return count;
	     }

		public void updateUserPassword(String username,String password) {		   
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_user set password=? where username=?");			
			
			try {
				pstmt.setString(1, password);
				pstmt.setString(2, username);
				pstmt.executeUpdate();				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt,null);
			}
		}
		
		
		public void updateUser(int id , String address, String postcode, String phone,String realname,String province, String city, String area) {
		   
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_user set address=?,postcode=?,phone=?, realname=?, province=?,city=?, area=? where id=?");
			ResultSet rs =null;
			
			try {
				pstmt.setInt(8, id);				
				pstmt.setString(1, address);
				pstmt.setString(2, postcode);
				pstmt.setString(3, phone);				
				pstmt.setString(4, realname);			
				pstmt.setString(5,province);
				pstmt.setString(6, city);
				pstmt.setString(7, area);			    
			    pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}
		}
		public void updateUserLocks(int uid ,String locks){
			Connection conn = DBUtil.getConn();
			PreparedStatement pstmt = DBUtil.getPstmt(conn,"update t_user set locks=? where id=?");
			ResultSet rs =null;
			
			try {
							
				pstmt.setString(1, locks);
				pstmt.setInt(2, uid);			    
			    pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.getClose(conn, pstmt, rs);
			}
		}

			
}
