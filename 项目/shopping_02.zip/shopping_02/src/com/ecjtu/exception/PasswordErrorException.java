package com.ecjtu.exception;

public class PasswordErrorException extends RuntimeException {

}
