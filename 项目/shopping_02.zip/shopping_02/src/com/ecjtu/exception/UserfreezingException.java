package com.ecjtu.exception;

public class UserfreezingException extends RuntimeException {

}
