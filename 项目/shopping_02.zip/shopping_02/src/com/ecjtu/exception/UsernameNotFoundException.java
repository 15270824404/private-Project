package com.ecjtu.exception;

public class UsernameNotFoundException extends RuntimeException {

}
