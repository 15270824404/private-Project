package com.ecjtu.factory;

import com.ecjtu.dao.CommentDao;
import com.ecjtu.dao.NoticeDao;
import com.ecjtu.util.prop.PropUtil;

public class CommentFactory {
	public static CommentDao getInstance(){
		CommentDao commentDao = null;
		try {
			 String commentDaoName = PropUtil.getValueKey("config.properties", "commentDao");
			commentDao =(CommentDao)Class.forName(commentDaoName).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return commentDao;
	}

}
