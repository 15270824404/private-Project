package com.ecjtu.factory;

import com.ecjtu.dao.DetailDao;
import com.ecjtu.util.prop.PropUtil;

public class DetailFactoty {
	public static DetailDao getInstance(){
		DetailDao detailDao = null;
  	  try {
  		 String p = PropUtil.getValueKey("config.properties", "DetailDao");
  		detailDao = (DetailDao) Class.forName(p).newInstance();	
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  	  return detailDao;
    }
}
