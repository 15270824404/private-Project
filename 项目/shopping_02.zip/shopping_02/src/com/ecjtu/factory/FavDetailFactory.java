package com.ecjtu.factory;

import com.ecjtu.dao.FavDetailDao;
import com.ecjtu.util.prop.PropUtil;

public class FavDetailFactory {
		public static  FavDetailDao getInstance(){
			FavDetailDao favDetailDao = null;
	  	  try {
	  		 String p = PropUtil.getValueKey("config.properties", "FavDetailDao4MySqlImpl");
	  		favDetailDao = (FavDetailDao) Class.forName(p).newInstance();	
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  	  return favDetailDao;
	}
}
