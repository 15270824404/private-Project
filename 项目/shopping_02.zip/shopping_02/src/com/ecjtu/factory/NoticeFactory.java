package com.ecjtu.factory;

import com.ecjtu.dao.NoticeDao;
import com.ecjtu.util.prop.PropUtil;

public class NoticeFactory {
	//noticeDaoNameΪ����
	   public static NoticeDao getInstance(){
		   NoticeDao noticeDao = null;
		   
		  try {
			  String notceDaoName = PropUtil.getValueKey("config.properties", "NoticeDao4MySqlImpl");
			  noticeDao =(NoticeDao) Class.forName(notceDaoName).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noticeDao;
		   
	   }
}
