package com.ecjtu.factory;

import com.ecjtu.dao.DetailDao;
import com.ecjtu.dao.OrderDao;
import com.ecjtu.util.prop.PropUtil;

public class OrderFactory {
	public static OrderDao getInstance(){
		OrderDao orderDao = null;
  	  try {
  		 String p = PropUtil.getValueKey("config.properties", "OrderDao");
  		orderDao = (OrderDao) Class.forName(p).newInstance();	
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  	  return orderDao;
    }
}
