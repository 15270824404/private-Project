package com.ecjtu.factory;

import com.ecjtu.dao.ProductDao;
import com.ecjtu.util.prop.PropUtil;

public class ProductDaoFactory {
	public static ProductDao getInstance(){
		ProductDao productDao = null;
  	  try {
  		 String p = PropUtil.getValueKey("config.properties", "ProductDao4MySqlImpl");
  		productDao = (ProductDao) Class.forName(p).newInstance();	
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  	  return productDao;
    }
}