package com.ecjtu.factory;

import com.ecjtu.dao.TypeDao;
import com.ecjtu.util.prop.PropUtil;

public class TypeFactory {
    public static TypeDao getInstance(){
    	TypeDao typeDao = null;
    	try {
    		String p = PropUtil.getValueKey("config.properties", "TypeDao4MySqlImpl");
			typeDao = (TypeDao) Class.forName(p).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return typeDao;
    	
    }
   
}
