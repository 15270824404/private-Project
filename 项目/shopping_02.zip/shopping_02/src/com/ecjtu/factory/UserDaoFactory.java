package com.ecjtu.factory;

import com.ecjtu.dao.UserDao;
import com.ecjtu.util.prop.PropUtil;

public class UserDaoFactory {
	public static UserDao getInstance(){
		UserDao userDao = null;
  	  try {
  		 String p = PropUtil.getValueKey("config.properties", "UserDao4MySqlImpl");
  		userDao = (UserDao) Class.forName(p).newInstance();	
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  	  return userDao;
    }
}
