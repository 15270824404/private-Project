package com.ecjtu.pojo;

public class Car {
     private int id;
     private Product product;
     private int pcount;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Product getPrdouct() {
		return product;
	}
	public void setPrdouct(Product product) {
		this.product = product;
	}
	public int getPcount() {
		return pcount;
	}
	public void setPcount(int pcount) {
		this.pcount = pcount;
	}
     
}
