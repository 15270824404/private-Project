package com.ecjtu.pojo;

import java.util.Date;
import java.util.List;

public class Order {
	private int id;
	private float sum;
	private String texp;
	private User user;
	private List<Detail> detail;
	private String isbill;
	private String paytype;
	private String content;
	private String sendtype;
	private Date odate;
	private int state;
	private double sumPrice;
	
	public double getSumPrice() {
		return sumPrice;
	}
	public void setSumPrice(double sumPrice) {
		this.sumPrice = sumPrice;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getSum() {
		return sum;
	}
	public void setSum(float sum) {
		this.sum = sum;
	}
	public String getTexp() {
		return texp;
	}
	public void setTexp(String texp) {
		this.texp = texp;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public List<Detail> getDetail() {
		return detail;
	}
	public void setDetail(List<Detail> detail) {
		this.detail = detail;
	}
	public String getIsbill() {
		return isbill;
	}
	public void setIsbill(String isbill) {
		this.isbill = isbill;
	}
	public String getPaytype() {
		return paytype;
	}
	public void setPaytype(String paytype) {
		this.paytype = paytype;
	}
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSendtype() {
		return sendtype;
	}
	public void setSendtype(String sendtype) {
		this.sendtype = sendtype;
	}
	public Date getOdate() {
		return odate;
	}
	public void setOdate(Date odate) {
		this.odate = odate;
	}
	
}
