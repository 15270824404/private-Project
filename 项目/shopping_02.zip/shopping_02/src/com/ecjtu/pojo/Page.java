package com.ecjtu.pojo;

public class Page {
  private int maxResult=5;
  private int currentPage;
  private int totalPage;
  private int totalResult;
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public int getTotalResult() {
		return totalResult;
	}
	public void setTotalResult(int totalResult) {
		this.totalResult = totalResult;
	}
	public int getMaxResult() {
		return maxResult;
	}
}
