package com.ecjtu.pojo;

import java.util.Date;
import java.util.List;

public class Product {
		 
			 private int id ;//#产品编号
			 private String pname ;//产品名称
			 private int isbargain ;//是否特价 特价为0
			 private double price ;//商场价格
			 private double marketprice ;//#市场价格
			 private int pcount ;//产品数量
			 private int isprefered ;//是否推荐为新品
			 private String pexp ;//产品描述
			 private String pic;//#产品图片
			 private Date pdate ;
			 private double pdiscount ;//产品折扣		     
			 private Type parent;
			 private Type children;
			
			public Type getParent() {
				return parent;
			}
			public void setParent(Type parent) {
				this.parent = parent;
			}
			
			public Type getChildren() {
				return children;
			}
			public void setChildren(Type children) {
				this.children = children;
			}
			public int getId() {
				return id;
			}
			public void setId(int id) {
				this.id = id;
			}
			public String getPname() {
				return pname;
			}
			public void setPname(String pname) {
				this.pname = pname;
			}
			public int getIsbargain() {
				return isbargain;
			}
			public void setIsbargain(int isbargain) {
				this.isbargain = isbargain;
			}
			public double getPrice() {
				return price;
			}
			public void setPrice(double price) {
				this.price = price;
			}
			public double getMarketprice() {
				return marketprice;
			}
			public void setMarketprice(double marketprice) {
				this.marketprice = marketprice;
			}
			public int getPcount() {
				return pcount;
			}
			public void setPcount(int pcount) {
				this.pcount = pcount;
			}
			public int getIsprefered() {
				return isprefered;
			}
			public void setIsprefered(int isprefered) {
				this.isprefered = isprefered;
			}
			public String getPexp() {
				return pexp;
			}
			public void setPexp(String pexp) {
				this.pexp = pexp;
			}
			public String getPic() {
				return pic;
			}
			public void setPic(String pic) {
				this.pic = pic;
			}
			public Date getPdate() {
				return pdate;
			}
			public void setPdate(Date pdate) {
				this.pdate = pdate;
			}
			public double getPdiscount() {
				return pdiscount;
			}
			public void setPdiscount(double pdiscount) {
				this.pdiscount = pdiscount;
			}
				
		
}
