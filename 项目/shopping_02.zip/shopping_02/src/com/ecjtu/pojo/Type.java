package com.ecjtu.pojo;

import java.util.List;

public class Type {
	private int id;
	private String name;
	private String exp;
	private  Type parent;
	private Type children;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExp() {
		return exp;
	}
	public void setExp(String exp) {
		this.exp = exp;
	}
	public Type getParent() {
		return parent;
	}
	public void setParent(Type parent) {
		this.parent = parent;
	}
	public Type getChildren() {
		return children;
	}
	public void setChildren(Type children) {
		this.children = children;
	}
	

	
}
