package com.ecjtu.service;

import java.sql.Timestamp;
import java.util.List;

import com.ecjtu.pojo.Comment;

public interface CommentService {
	public List<Comment> getComments();
	public void saveComment(Comment comm,int pid,int uid);
}
