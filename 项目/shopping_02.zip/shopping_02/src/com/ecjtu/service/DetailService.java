package com.ecjtu.service;

import java.util.List;

import com.ecjtu.pojo.Detail;

public interface DetailService {
    public List<Detail> getDetailsByOid(int oid);
    public boolean saveDetail(int pid,int oid,int num);
    public List<Detail> getDetails();
}
