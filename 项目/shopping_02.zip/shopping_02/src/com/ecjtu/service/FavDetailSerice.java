package com.ecjtu.service;

import java.util.List;

import com.ecjtu.pojo.FavDetail;

public interface FavDetailSerice {
	public List<FavDetail> getFavDetail(int uid);
	public void saveFavDetailByUPid(int uid,int pid);
	public int getFavDetailByPid(int uid,int pid);
}
