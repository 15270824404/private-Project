package com.ecjtu.service;

import com.ecjtu.pojo.Manager;

public interface ManagerService {
   public Manager login(String username,String password);
}
