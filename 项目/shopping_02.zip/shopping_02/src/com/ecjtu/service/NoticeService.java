package com.ecjtu.service;

import java.sql.Timestamp;
import java.util.List;

import com.ecjtu.pojo.Notice;
import com.ecjtu.pojo.Page;

public interface NoticeService {
    public Notice getNotice(int id);
    public List<Notice> getNoticesForTitle(Page page);
    public void saveNotice(Notice notice);
 
    public void deleteTypes(int id);
    
    public void renewTypes(int id,String title,String content,String fdate,String sdate);
}
