package com.ecjtu.service;

import java.util.List;

import com.ecjtu.pojo.Order;
import com.ecjtu.pojo.Page;

public interface OrderService {
  public List<Order> getOrders();
  public Order getOrder(int id);
  public List<Order> getOrdersByPage(Page page);
  public void delete(int id);
  public int  saveOrder(int uid,String isbill,String paytype,String content,String sendtype);
  public List<Order> getOrdersByUid(int uid);
}
