package com.ecjtu.service;

import java.util.List;

import com.ecjtu.dao.ProductDao;
import com.ecjtu.pojo.Page;
import com.ecjtu.pojo.Product;
import com.ecjtu.service.impl.ProductServiceImpl;

public interface ProductService {
	//public ProductDao getProductDao();
	//查询全部数据
	public List<Product> getProductDaoAll( );
	 //查询是否特价
   public List<Product> getProductDaoIsbargain(Page page);
 //查询个别的特价
   public Product getProductDaoIsbargainOnly(int id);
   //查询id得到产品
   public Product getProductById(int id);
 //查询最新的产品
   public List<Product> getProductDaoIsprefered(Page page );
 //查询以id来查询到产品的数量
   public int getProductDaoAcount(int id);
 //以小类id查询产品的	  
   public List<Product> getProductDao(int tid);
   //以小类id和pname来模糊查询数据：
   public List<Product> getProductDaoPname(Page page,int tid,String pname);
 //增加产品的中全部数据
   public void saveProductDaoAll(Product product);

 //修改产品的全部内容
   public void renewProductDaoAll(int id,String pname,int isbargain,double price,double marketprice,int pcount ,
 	     String pexp ,String pic,double pdiscount ,int tid,int mistid);
   //修改其中是否特价
   public void renewProductDaoIs(int isbargain,int id);
 //修改产品的数据
   public void renewProductDaoAllCounnt(int id,int pcount);
 //当购买的是时候更改数量需要知道总量,返回一个布尔类型，已得到能不能购买
   public boolean renewProductDaoCounnt(int id,int pcount);

}
