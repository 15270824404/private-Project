package com.ecjtu.service;

import java.util.List;

import com.ecjtu.pojo.Type;

public interface TypeService {
	 public List<Type> getTypesByTid(int tid);
	 public void saveTypes(Type type,int tid);
	 public void deleteTypes(int id);
	 public void renewTypes(int id,String name,String exp);
	 public void deleteCtypes(int tid);
	 public Type getTypeById(int id);
	 public Type getChildrenTypesByTid(int tid);
		public Type getParentTypesByTid(int tid);
}
