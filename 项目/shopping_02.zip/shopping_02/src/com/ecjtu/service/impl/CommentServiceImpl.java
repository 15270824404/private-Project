package com.ecjtu.service.impl;

import java.sql.Timestamp;
import java.util.List;
import com.ecjtu.dao.CommentDao;
import com.ecjtu.factory.CommentFactory;
import com.ecjtu.pojo.Comment;
import com.ecjtu.service.CommentService;

public class CommentServiceImpl implements CommentService {
	private CommentServiceImpl(){}
	private static CommentService commentService = new CommentServiceImpl();
	public static CommentService getInstance(){
		return commentService;
	}
	
	private static CommentDao commentDao;
	static{
		
		commentDao = CommentFactory.getInstance();
	}
	public List<Comment> getComments() {
		
		return commentDao.findComments();
	}
	
	public void saveComment(Comment comm,int pid,int uid) {
		commentDao.addComment(comm, pid, uid);
		
	}
}
