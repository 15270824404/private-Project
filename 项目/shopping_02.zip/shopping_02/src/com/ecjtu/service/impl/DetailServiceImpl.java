package com.ecjtu.service.impl;

import java.util.List;

import com.ecjtu.dao.DetailDao;
import com.ecjtu.dao.impl.DetailDao4MySqlImpl;
import com.ecjtu.factory.DetailFactoty;
import com.ecjtu.pojo.Detail;
import com.ecjtu.service.DetailService;

public class DetailServiceImpl implements DetailService {
    private DetailServiceImpl(){};
    
    private static DetailServiceImpl detailService=new DetailServiceImpl();
    public static DetailServiceImpl getInstance(){
    	return detailService;
    }
    private static DetailDao detailDao;
    static{
    	detailDao = DetailFactoty.getInstance();
    }
	public List<Detail> getDetailsByOid(int oid) {
		// TODO Auto-generated method stub
		return detailDao.findDetailByOid(oid);
	}
	public boolean saveDetail(int pid, int oid, int num) {
		// TODO Auto-generated method stub
		return detailDao.addDetail(pid, oid, num);
	}
	public List<Detail> getDetails() {
		// TODO Auto-generated method stub
		return detailDao.findDetail();
	}

}
