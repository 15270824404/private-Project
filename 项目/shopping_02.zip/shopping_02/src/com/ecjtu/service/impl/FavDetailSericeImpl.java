package com.ecjtu.service.impl;

import java.util.List;

import com.ecjtu.dao.FavDetailDao;
import com.ecjtu.factory.FavDetailFactory;
import com.ecjtu.pojo.FavDetail;
import com.ecjtu.service.FavDetailSerice;

public class FavDetailSericeImpl implements FavDetailSerice {
	private static FavDetailSerice favDetailSerice = new FavDetailSericeImpl();
	private  FavDetailSericeImpl(){};
	public static FavDetailSerice getStance(){
		return favDetailSerice;
	}
	private static FavDetailDao favDetailDao ;
	static {
		favDetailDao = FavDetailFactory.getInstance();
	}
	public List<FavDetail> getFavDetail(int uid){
		
		return favDetailDao.findFavDetail(uid);
	}
	
	public void saveFavDetailByUPid(int uid,int pid){
		favDetailDao.addfavDetailByUPid(uid, pid);
	}
	public int getFavDetailByPid(int uid, int pid) {
		return favDetailDao.findFavDetailByPid(uid, pid);
		
	}
}
