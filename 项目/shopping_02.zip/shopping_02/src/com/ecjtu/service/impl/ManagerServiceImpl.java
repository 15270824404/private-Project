package com.ecjtu.service.impl;

import com.ecjtu.dao.ManagerDao;
import com.ecjtu.dao.impl.ManagerDao4MySql;
import com.ecjtu.exception.UsernameNotFoundException;
import com.ecjtu.pojo.Manager;
import com.ecjtu.service.ManagerService;
import com.ecjtu.exception.PasswordErrorException;

public class ManagerServiceImpl implements ManagerService {
    private ManagerServiceImpl(){}
    private static ManagerDao managerDao=new ManagerDao4MySql();
    private static ManagerServiceImpl managerService=new ManagerServiceImpl();
    public static ManagerServiceImpl getInstance(){
    	return managerService;
    }
	public Manager login(String username, String password) {
		Manager manager=managerDao.findManager(username);
		if(manager==null){
			throw new UsernameNotFoundException();
		}
		if(!password.equals(manager.getPassword())){
			 throw new PasswordErrorException();
		 }
		return manager;
	}

}
