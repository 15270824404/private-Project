package com.ecjtu.service.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Properties;

import com.ecjtu.dao.NoticeDao;
import com.ecjtu.factory.NoticeFactory;
import com.ecjtu.pojo.Notice;
import com.ecjtu.pojo.Page;
import com.ecjtu.service.NoticeService;


public class NoticeServiceImpl implements NoticeService {
	public NoticeServiceImpl(){}
	private static NoticeService noticeService = new NoticeServiceImpl();
	public static NoticeService getInstance(){
		return noticeService;
	}
	
	private static NoticeDao noticeDao;
	static{		
		noticeDao = NoticeFactory.getInstance();
	}

	

	public List<Notice> getNoticesForTitle(Page page) {
		
		return noticeDao.findNoticesForTitle(page);
	}

	public Notice getNotice(int id) {
		
		return noticeDao.findNotice(id);
	}

	public void saveNotice(Notice notice) {
		noticeDao.addNotice(notice);
		
	}

	public void deleteTypes(int id) {
		noticeDao.removeTypes(id);
	}

	public void renewTypes(int id, String title, String content,
			String fdate, String sdate) {
		
		noticeDao.updateTypes(id, title, content, fdate, sdate);
	}
     
}
