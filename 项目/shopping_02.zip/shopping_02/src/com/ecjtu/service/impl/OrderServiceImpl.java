package com.ecjtu.service.impl;

import java.util.List;

import com.ecjtu.dao.OrderDao;
import com.ecjtu.dao.impl.OrderDao4MySqlImpl;
import com.ecjtu.factory.OrderFactory;
import com.ecjtu.pojo.Order;
import com.ecjtu.pojo.Page;
import com.ecjtu.service.OrderService;

public class OrderServiceImpl implements OrderService {
    private OrderServiceImpl(){};
    
    private static OrderServiceImpl orderService=new OrderServiceImpl();
    public static OrderServiceImpl getInstance(){
    	return orderService;
    }
    private static OrderDao orderDao;
    static {
    	orderDao = OrderFactory.getInstance();
    }
	public List<Order> getOrders() {
		return orderDao.findOrders();
	}
	public Order getOrder(int id) {
		// TODO Auto-generated method stub
		return orderDao.findOrder(id);
	}
	public void delete(int id) {
		// TODO Auto-generated method stub
		orderDao.renew(id);
	}
	public List<Order> getOrdersByPage(Page page) {
		// TODO Auto-generated method stub
		return orderDao.findOrdersByPage(page);
	}
	public int saveOrder(int uid, String isbill, String paytype,
			String content, String sendtype) {
		return orderDao.addOrder(uid, isbill, paytype, content, sendtype);
	}
	public List<Order> getOrdersByUid(int uid) {
		// TODO Auto-generated method stub
		return orderDao.findOrdersByUid(uid);
	}
	

}
