package com.ecjtu.service.impl;

import java.util.Iterator;
import java.util.List;

import com.ecjtu.dao.ProductDao;
import com.ecjtu.factory.ProductDaoFactory;
import com.ecjtu.pojo.Page;
import com.ecjtu.pojo.Product;
import com.ecjtu.service.ProductService;

public class ProductServiceImpl implements ProductService {
	

	
	private static ProductService productService = new ProductServiceImpl();
	private ProductServiceImpl(){};

	public static ProductService getStance(){
		return productService;
	}
	private static ProductDao productDao ;
	static{
		productDao = ProductDaoFactory.getInstance();
	}
	//查询所有产品
	public List<Product> getProductDaoAll() {
		// TODO Auto-generated method stub
		return productDao.findProductDaoAll();
	}
	//以id来查询是否特价
	public List<Product> getProductDaoIsbargain(Page page ) {
		// TODO Auto-generated method stub
		return productDao.findProductDaoIsbargainAll(page);
	}
	//查询个别的特价
	public Product getProductDaoIsbargainOnly(int id) {
		// TODO Auto-generated method stub
		return productDao.findProductDaoIsbargainOnly(id);
	}
	//查询最新的产品，会员
	public List<Product> getProductDaoIsprefered(Page page) {
		// TODO Auto-generated method stub
		return productDao.findProductDaoIsprefered(page);
	}
	//查询以id来查询到产品的数量，会员
	public int getProductDaoAcount(int id) {
		// TODO Auto-generated method stub
		return productDao.findProductDaoAcount(id);
	}
	//以小类id查询产品的，会员  
	public List<Product> getProductDao(int tid) {
		// TODO Auto-generated method stub
		return productDao.findProductDao(tid);
	}
	//以小类id和pname来模糊查询数据：会员
	public List<Product> getProductDaoPname(Page page,int tid, String pname) {
		// TODO Auto-generated method stub
		return productDao.findProductDaoPname(page,tid, pname);
	}
	  //增加产品的中全部数据，管理员
	public void saveProductDaoAll(Product product) {
		// TODO Auto-generated method stub
		productDao.addProductDaoAll(product);
	}

	 //修改产品的全部内容，管理员
	public void renewProductDaoAll(int id, String pname, int isbargain,
			double price, double marketprice, int pcount,
			String pexp, String pic, double pdiscount, int tid,int mistid) {
		// TODO Auto-generated method stub
		productDao.updateProductDaoAll(id, pname, isbargain, price, marketprice, pcount, pexp, pic, pdiscount, tid,mistid);
	}
	 //修改其中是否隐藏,管理员
	public void renewProductDaoIs(int isbargain, int id) {
		// TODO Auto-generated method stub
		productDao.updateProductDaoIs(isbargain, id);
	}//修改产品的总的数据，管理员
	public void renewProductDaoAllCounnt(int id, int pcount) {
		productDao.updateProductDaoAllCounnt(id, pcount);
		
	}
	//当购买的是时候更改数量需要知道总量,返回一个布尔类型，已得到能不能购买
	   public boolean renewProductDaoCounnt(int id,int pcount){
		   return 	productDao.updateProductDaoCounnt(id, pcount);	   
	   }

	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productDao.findProductById(id);
	}
}
