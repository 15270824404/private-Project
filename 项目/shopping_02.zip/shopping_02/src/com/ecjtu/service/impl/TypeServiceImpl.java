package com.ecjtu.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.ecjtu.dao.TypeDao;
import com.ecjtu.factory.TypeFactory;
import com.ecjtu.pojo.Type;
import com.ecjtu.service.TypeService;
import com.ecjtu.util.DBUtil;

public class TypeServiceImpl implements TypeService {
	private TypeServiceImpl(){}
	private static TypeService typeService = new TypeServiceImpl();
	public static TypeService getInstance(){
		return typeService;
		
	}
 
	private static TypeDao typeDao;
	static{		
		typeDao = TypeFactory.getInstance();
	}
	public List<Type> getTypesByTid(int tid) {
	
		return typeDao.findTypesByTid(tid);
	}
	public void saveTypes(Type type, int tid) {
		
		typeDao.addTypes(type, tid);
	}
	public void deleteTypes(int id) {
		typeDao.removeTypes(id);
		
	}
	public void renewTypes(int id, String name, String exp) {
		
		typeDao.updateTypes(id, name, exp);
	}
	public Type getTypeById(int id) {
		
		return typeDao.findTypeById(id);
	}
	public void deleteCtypes(int tid) {
		typeDao.removeCtypes(tid);
		
	}
	public Type getChildrenTypesByTid(int tid){
		return typeDao.findChildrenTypesByTid(tid);
	}
	public Type getParentTypesByTid(int tid){
		return typeDao.findParentTypesByTid(tid);
	}
	
}
