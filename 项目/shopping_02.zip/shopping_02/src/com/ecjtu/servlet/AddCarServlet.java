package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecjtu.pojo.Car;
import com.ecjtu.pojo.Product;
import com.ecjtu.service.impl.ProductServiceImpl;

public class AddCarServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int pid = Integer.parseInt(request.getParameter("pid"));	
		HttpSession session =  request.getSession();
		Product product = ProductServiceImpl.getStance().getProductById(pid);
		Car car = new Car();
		List<Car> cart = (List<Car>)session.getAttribute("cart");
		car.setPrdouct(product);
		car.setPcount(1);
		cart.add(car);
//	    session.setMaxInactiveInterval(30*60);
		session.setAttribute("cart",cart);	
		PrintWriter out = response.getWriter();
        out.print(1);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
		
	}

}
