package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Car;

public class AddCatProductNumServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//购物车有问题？？？保证其中的数据提交 >=正整数 还需要保证数据不超过商品的数据
		List<Car> cart = (List<Car>) request.getSession().getAttribute("cart");
		List<Car> cart2 = new ArrayList<Car>();
		int i = 1;
		for (Iterator<Car> it = cart.iterator();it.hasNext();++i){
			Car car = it.next();
			int gnum =  Integer.parseInt(request.getParameter("car"+i));
			car.setPcount(gnum);
			cart2.add(car);
						
		}
		request.getSession().setAttribute("cart", cart2);
		request.getRequestDispatcher("./cart_add.jsp").forward(request, response);
	}

}
