package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Notice;
import com.ecjtu.service.NoticeService;
import com.ecjtu.service.impl.NoticeServiceImpl;

public class AddNoticeServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            Notice notice = new Notice();
            String title = request.getParameter("title");
			String content = request.getParameter("content");
			int year1 = Integer.parseInt(request.getParameter("year1"));
			int year2 = Integer.parseInt(request.getParameter("year2"));
			int month1 = Integer.parseInt(request.getParameter("month1"));
			int month2 = Integer.parseInt(request.getParameter("month2"));
			int day1 = Integer.parseInt(request.getParameter("day1"));
			int day2 = Integer.parseInt(request.getParameter("day2"));
			String months1 = month1+"";
			String months2 = month2+"";
			String days1 = day1+"";
			String days2 = day2+"";
			int nid = Integer.parseInt(request.getParameter("nid"));
			if (month1<10){
				months1 = 0+months1;
			}
			if (day1<10){
				days1 = 0+days1;
			}
			if (month2<10){
				months2 = 0+months2;
			}
			if (day2<10){
				day2 = 0+day2;
			}
			String uptime = ""+year1+months1+days1;
			String deadtime =""+year2+months2+days2;
            notice.setContent(content);
            notice.setFdate(uptime);
            notice.setSdate(deadtime);
            notice.setTitle(title);			
			NoticeService noticeService = new NoticeServiceImpl();
			if (nid == 0){
				noticeService.saveNotice(notice);
			}else{
				noticeService.renewTypes(nid, title, content, uptime, deadtime);
			}
            request.getRequestDispatcher("./getNotices.do").forward(request, response);
	}

}
