package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Car;
import com.ecjtu.pojo.User;
import com.ecjtu.service.impl.DetailServiceImpl;
import com.ecjtu.service.impl.OrderServiceImpl;
import com.ecjtu.service.impl.UserServiceImpl;

public class AddOrderServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		   int uid =Integer.parseInt(request.getParameter("uid"));
		    String realname =request.getParameter("realname");
		    String address =request.getParameter("address");
		    String postcode =request.getParameter("postcode");
		    String phone =request.getParameter("phone");
		    User user = (User) request.getSession().getAttribute("login");
		    UserServiceImpl.getInstance().updaUser(uid, address, postcode, phone, realname, user.getProvince(), user.getCity(),user.getArea());	    
		    String isbill = "否";
		    String bill = request.getParameter("needinvoice");
		    if(bill != null){
		    	isbill = "是";
		    }
		    int pay =Integer.parseInt(request.getParameter("paytype"));
		    int send =Integer.parseInt(request.getParameter("sendtype"));		   
		    String sendtype = null;
		    String paytype = null;		    
		    String content  =request.getParameter("remark");
		    if(pay==1){
		    	 paytype = "邮政付款";	
		    }else if(pay == 2){
		    	paytype = "货到付款";
		    }else{
		    	paytype = "网银付款";
		    }
		    if(send ==1){
		    	 sendtype = "快递";	
		    }else if(send == 2){
		    	sendtype = "EMS";
		    }else{
		    	sendtype = "平邮";
		    }
		    int oid = OrderServiceImpl.getInstance().saveOrder(uid, isbill, paytype, content, sendtype);
		    List<Car> cart = (List<Car>) request.getSession().getAttribute("cart");
		    
		    for(Iterator<Car> i = cart.iterator();i.hasNext();){
		    	Car car = i.next();		    	
//		    	System.out.println(car.getPrdouct().getId()+"       "+car.getPcount());
		    	DetailServiceImpl.getInstance().saveDetail(car.getPrdouct().getId(), oid, car.getPcount());
		    }
	        request.getRequestDispatcher("./showOrders.do").forward(request, response);
		}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       this.doGet(request, response);
	}

}
