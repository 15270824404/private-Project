package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.dao.impl.ProductDao4MySqlImpl;
import com.ecjtu.pojo.Product;
import com.ecjtu.service.impl.ProductServiceImpl;
import com.ecjtu.service.impl.TypeServiceImpl;

public class AddProductAllServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 Product product = new Product();
	     int tid = Integer.parseInt(request.getParameter("supertype"));
	     int mistid = Integer.parseInt(request.getParameter("typeID"));
	     product.setPname(request.getParameter("pname"));
	     product.setPrice(Double.parseDouble(request.getParameter("price")));	 
	     product.setMarketprice(Double.parseDouble(request.getParameter("marketprice")));
	     product.setPdiscount(Double.parseDouble(request.getParameter("pdiscount")));
	     product.setPcount(Integer.parseInt(request.getParameter("pcount")));
	     product.setIsbargain(Integer.parseInt(request.getParameter("isbargain")));
	     product.setPexp(request.getParameter("pexp"));
	     product.setPic(request.getParameter("pic"));
//	     System.out.println(product.getPic());
	     product.setChildren(TypeServiceImpl.getInstance().getChildrenTypesByTid(mistid));
	     product.setParent(TypeServiceImpl.getInstance().getParentTypesByTid(tid));
	     
	     ProductServiceImpl.getStance().saveProductDaoAll(product);
	     //request.getRequestDispatcher("./manage/GoodsManage.jsp").forward(request, response);    
	     request.getRequestDispatcher("./showProductByTidMis.do?tid="+tid+"&mistid="+mistid).forward(request, response);    
	    
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
         this.doGet(request, response);
	}

}
