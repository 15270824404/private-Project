package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Type;
import com.ecjtu.service.impl.TypeServiceImpl;

public class AddPtypeServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
	     Type type = new Type();
	     type.setName(request.getParameter("typename"));
	     type.setExp(request.getParameter("exp"));
	     int tid = Integer.parseInt(request.getParameter("tid"));
	   
	   TypeServiceImpl.getInstance().saveTypes(type, tid);
	
	   request.getRequestDispatcher("./showPtypes.do?tid="+tid).forward(request, response);
	   
	}

}
