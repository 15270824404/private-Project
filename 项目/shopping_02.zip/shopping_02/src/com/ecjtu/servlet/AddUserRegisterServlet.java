package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecjtu.exception.PasswordErrorException;
import com.ecjtu.exception.UsernameNotFoundException;
import com.ecjtu.pojo.User;
import com.ecjtu.service.impl.UserServiceImpl;

public class AddUserRegisterServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String realname = request.getParameter("truename");
		String address = request.getParameter("address");
		String province = request.getParameter("province");
		String city = request.getParameter("city");
		String area = request.getParameter("area");
//		System.out.println(province);
		String postcode = request.getParameter("postcode");
		String phone = request.getParameter("telephone");
	    UserServiceImpl.getInstance().saveUser(username, email, password, address, postcode, phone, realname, province, city, area);
	    UserServiceImpl.getInstance().Login(username, password);	
	    User user = UserServiceImpl.getInstance().getUserByUsername(username);
	    HttpSession session = request.getSession();
		session.setAttribute("login", user); 	   	    	    	
        request.getRequestDispatcher("index.jsp").forward(request, response);
	    
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
         this.doGet(request, response);
	}

}
