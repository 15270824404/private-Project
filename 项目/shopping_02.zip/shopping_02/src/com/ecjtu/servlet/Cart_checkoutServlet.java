package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecjtu.pojo.Car;
import com.ecjtu.pojo.User;


public class Cart_checkoutServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = (User)request.getSession().getAttribute("login");
		if(user==null){
			request.setAttribute("path", "cart_add.jsp");			
			request.setAttribute("msg", "您没有登录，请登录");
			request.getRequestDispatcher("./swipe.jsp").forward(request, response);
		}else{
			request.getRequestDispatcher("./cart_checkout.jsp").forward(request, response);
		}		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
