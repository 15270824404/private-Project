package com.ecjtu.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecjtu.pojo.Car;


public class CheckCarInByServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		    String path = null;
			HttpSession session = request.getSession();
			if(session.getAttribute("cart") != null){
			List<Car> cart = (List<Car>) session.getAttribute("cart");			
			if (cart.size() != 0 || "".equals(cart)){
				path = "cart_add.jsp";
			}else{
				path = "cart_see.jsp";
			}
			}else{
				path = "cart_see.jsp";
			}
			
			request.getRequestDispatcher(path).forward(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			this.doGet(request, response);
		
	}


}
