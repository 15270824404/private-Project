package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Comment;
import com.ecjtu.pojo.Notice;
import com.ecjtu.pojo.Page;
import com.ecjtu.service.impl.CommentServiceImpl;
import com.ecjtu.service.impl.NoticeServiceImpl;

public class CheckCommentServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Comment> comm = CommentServiceImpl.getInstance().getComments();
//	System.out.println("111111111111111");
     Page page = null;
	 List<Notice> notices = NoticeServiceImpl.getInstance().getNoticesForTitle(page);
	 request.setAttribute("notices",notices);
		request.setAttribute("comm", comm);
		
		request.getRequestDispatcher("./goods_detail.jsp").forward(request, response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          this.doGet(request, response);
	}

}
