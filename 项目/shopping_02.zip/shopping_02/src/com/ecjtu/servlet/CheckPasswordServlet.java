package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.exception.PasswordErrorException;
import com.ecjtu.exception.UsernameNotFoundException;
import com.ecjtu.pojo.User;
import com.ecjtu.service.impl.UserServiceImpl;

public class CheckPasswordServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");	
		String oldPassword = request.getParameter("oldpwd");
		String newPassword = request.getParameter("password");
//		System.out.println(username+"    "+oldPassword);
		
		 User user = UserServiceImpl.getInstance().getUserByUsername(username);
  	     try{		    		
  		  UserServiceImpl.getInstance().Login(username, oldPassword);
  		  UserServiceImpl.getInstance().updaUserPassword(username, newPassword); 
  		 request.setAttribute("msg", "修改成功");  
  		  }catch(UsernameNotFoundException e) {			      
  			 request.setAttribute("msg", "密码错误");  
  		  }catch(PasswordErrorException e) {
  			 request.setAttribute("msg", "密码错误");
  		  }
  	    
  	     request.getRequestDispatcher("member.jsp").forward(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}

