package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecjtu.pojo.Car;
import com.ecjtu.pojo.Product;
import com.ecjtu.service.impl.ProductServiceImpl;

public class DeletetCarByPidServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          int pid = Integer.parseInt(request.getParameter("pid"));
//          Product product = ProductServiceImpl.getStance().getProductById(pid);
          HttpSession session = request.getSession();
          Car deleteCar = null;
          List<Car> cart = (List<Car>)session.getAttribute("cart");
          for(Iterator<Car> i = cart.iterator();i.hasNext();){
        	  Car car = i.next();

              if(car.getPrdouct().getId() == pid){
                 deleteCar = car ;//不能在迭代时删除
               }
          }
          cart.remove(deleteCar);
          request.getSession().setAttribute("cart", cart);
          request.getRequestDispatcher("checkCarInBy.do").forward(request, response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          this.doGet(request, response);
	}

}
