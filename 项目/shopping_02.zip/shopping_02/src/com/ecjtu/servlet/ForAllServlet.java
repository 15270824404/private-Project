package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ForAllServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          int i = Integer.parseInt(request.getParameter("i"));
          int tid = Integer.parseInt(request.getParameter("id"));
          String path = null;
 		 switch (i){
 		 case 0:
 			 path="./manage/placard_add.jsp?nid=0";
 			 break;
          case 1:
         	 path="./manage/subType_add.jsp?tid="+tid; 
              break;
          case 3:
         	 path="./manage/placard_modify.jsp?nid="+tid;  
              break;
//          case 3:
//         	 path="./sale.jsp";
//              break;
//          case 4:
//         	 path="./goods_detail.jsp";
//         	 break;
//          case 5:
//         	 path="./type.jsp";
//         	 break;
//          case 6:
////         	 request.getAttribute("favDetail");
//         	 path="./favorite.jsp";
//         	 break;
//          case 7:
//         	 path="./cart_add.jsp";
//         	 break;
//          case 8:
//         	 path="./cart_see.jsp";
//         	 break;
      }

 		 request.getRequestDispatcher(path).forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
