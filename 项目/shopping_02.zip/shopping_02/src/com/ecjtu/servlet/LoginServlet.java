package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecjtu.exception.PasswordErrorException;
import com.ecjtu.exception.UserfreezingException;
import com.ecjtu.exception.UsernameNotFoundException;
import com.ecjtu.pojo.User;
import com.ecjtu.service.impl.UserServiceImpl;

public class LoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {	 
		
		  HttpSession session = request.getSession();
		  String validateC = (String)request.getSession().getAttribute("rand");
		  String veryCode = request.getParameter("checkCode");
		  String username = request.getParameter("username");
  		  String password = request.getParameter("password");
  		  User user = UserServiceImpl.getInstance().getUserByUsername(username);
  	     try{		    		
  		  UserServiceImpl.getInstance().Login(username, password);
  		  if (veryCode == null || "".equals(veryCode)) {
			  request.setAttribute("msg", "验证码为空");	
		  } else {
		   if (validateC.compareToIgnoreCase(veryCode) == 0) {
			   request.setAttribute("msg", "登录成功");			   
			   session.setAttribute("login", user);
		   } else {
			   request.setAttribute("msg", "验证码错误");	
		   }		  
		  }  	    	    	
  		  }catch(UsernameNotFoundException e) {			      
  			      request.setAttribute("msg", "用户名不存在");  
  		  }catch(PasswordErrorException e) {
  			 request.setAttribute("msg", "密码错误");
  		  }catch(UserfreezingException e){
  			 request.setAttribute("msg", "账号被冻结,请与管理员联系"); 
  		  }		  
		  request.getRequestDispatcher("./index.jsp").forward(request, response);       	
		  }

}

