package com.ecjtu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.exception.PasswordErrorException;
import com.ecjtu.exception.UsernameNotFoundException;
import com.ecjtu.pojo.Manager;
import com.ecjtu.service.impl.ManagerServiceImpl;

public class ManageLoginServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       	String username=request.getParameter("manager");
       	String password=request.getParameter("password");
       	String path=null;
       	String msg="用户["+username+"]登录成功！";
       	Manager manager=null;
       	try{
       		manager=ManagerServiceImpl.getInstance().login(username, password);
       	    path="mamberManager.do";
       	}catch(UsernameNotFoundException e){
       		path="./manage/login.jsp";
       		msg="用户["+username+"]找不到，请重新登录！";
//  		    e.printStackTrace();
       	}catch(PasswordErrorException e){
       		path="./manage/login.jsp";
       		msg="密码错误，请重新登录！";
// 		    e.printStackTrace();
       	} 
       //request.setAttribute("path", path);
 	   request.setAttribute("msg", msg);
 	   request.getSession().setAttribute("manager", manager);
 	   request.setAttribute("path", path);
 	   request.getRequestDispatcher("./swipe.jsp").forward(request, response);
 	   
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}


