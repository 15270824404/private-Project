package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Order;
import com.ecjtu.pojo.Page;
import com.ecjtu.service.impl.OrderServiceImpl;

public class ManageShowOrdersServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Page page=new Page();
		page.setCurrentPage(1);
		if(request.getParameter("currentPage")!=null){
			page.setCurrentPage(Integer.parseInt(request.getParameter("currentPage")));
		}
		List<Order> orders=OrderServiceImpl.getInstance().getOrdersByPage(page);
		request.setAttribute("orders", orders);
		request.setAttribute("page", page);
		request.getRequestDispatcher("./manage/OrderManage.jsp").forward(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          this.doGet(request, response);
	}

}
