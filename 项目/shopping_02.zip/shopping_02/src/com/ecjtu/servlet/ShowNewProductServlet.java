package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Page;
import com.ecjtu.pojo.Product;
import com.ecjtu.service.impl.ProductServiceImpl;

public class ShowNewProductServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Page page=new Page();
		page.setCurrentPage(1);
		if(request.getParameter("currentPage")!=null ){
			page.setCurrentPage(Integer.parseInt(request.getParameter("currentPage")));
		}
           List<Product> products = ProductServiceImpl.getStance().getProductDaoIsprefered(page);
         
           request.setAttribute("newGoods", products);
           int id = Integer.parseInt(request.getParameter("id"));
  		 String path = null;
  		 if(id == 0){
  			 path="./index.jsp";
  		 }else{		  
  		   path="./NewGoods.jsp"; 
  			request.setAttribute("page", page);
  		 }
  		 request.getRequestDispatcher(path).forward(request, response);
       
    }


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
