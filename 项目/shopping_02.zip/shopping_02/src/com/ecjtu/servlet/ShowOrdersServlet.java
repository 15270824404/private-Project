package com.ecjtu.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Order;
import com.ecjtu.pojo.User;
import com.ecjtu.service.impl.DetailServiceImpl;
import com.ecjtu.service.impl.OrderServiceImpl;

public class ShowOrdersServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		User user = (User)request.getSession().getAttribute("login");
		if(user != null){
		    
		    List<Order> orders=OrderServiceImpl.getInstance().getOrdersByUid(user.getId());
			request.setAttribute("orders", orders);
			request.getRequestDispatcher("./order.jsp").forward(request, response);
		}else{
			request.setAttribute("path", "./index.jsp");			
			request.setAttribute("msg", "您没有登录，请登录");
			request.getRequestDispatcher("./swipe.jsp").forward(request, response);
		}
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
