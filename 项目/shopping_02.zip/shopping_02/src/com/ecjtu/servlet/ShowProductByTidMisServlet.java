package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.dao.ProductDao;
import com.ecjtu.dao.impl.ProductDao4MySqlImpl;
import com.ecjtu.pojo.Page;
import com.ecjtu.pojo.Product;
import com.ecjtu.service.impl.ProductServiceImpl;

public class ShowProductByTidMisServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		 int tid = Integer.parseInt(request.getParameter("tid"));
		 int mistid = Integer.parseInt(request.getParameter("mistid"));
	     String pname = request.getParameter("pname");  
	 	Page page=new Page();
		page.setCurrentPage(1);
//		System.out.println(!request.getParameter("currentPage").equals(""));
		if(request.getParameter("currentPage")!=null ){
			page.setCurrentPage(Integer.parseInt(request.getParameter("currentPage")));
		}
	     List<Product> products = new ProductDao4MySqlImpl().findProductDaoPname1(page, tid, pname, mistid);
	     request.setAttribute("products", products);
	     request.setAttribute("page", page);
	     request.getRequestDispatcher("./manage/GoodsManage.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
         this.doGet(request, response);
	}

}
