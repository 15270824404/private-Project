package com.ecjtu.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Detail;
import com.ecjtu.service.impl.DetailServiceImpl;

public class ShowSellSortServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        List<Detail> details=DetailServiceImpl.getInstance().getDetails();
		request.setAttribute("details", details); 
	    int id = Integer.parseInt(request.getParameter("id"));
		 String path = null;
		 switch (id){
		 case 0:
			 path="./index.jsp";
			 break;
        case 1:
       	 path="./search_deal.jsp"; 
            break;
        case 2:
       	 path="./NewGoods.jsp";  
            break;
        case 3:
       	 path="./sale.jsp";
            break;
        case 4:
       	 path="./goods_detail.jsp";
       	 break;
        case 5:
       	 path="./type.jsp";
       	 break;
        case 6:
       	 path="./favorite.jsp";
       	 break;
        case 7:
       	 path="./cart_add.jsp";
       	 break;
        case 8:
       	 path="./cart_see.jsp";
       	 break;
        case 9:
       	 path="./cart_checkout.jsp";
       	 break;
        case 10:
       	 path="./SellSort.jsp";
       	 break;
        case 11:
          	 path="./member.jsp";
          	 break;
        case 13:
         	 path="./order_detail.jsp";
         	 break;
        case 14:
        	 path="./order.jsp";
        	 break;
        case 12:
       	 path="./placard_detail.jsp";
       	 break;
        case 15:
          	 path="./register.jsp";
          	 break;
    }

		 request.getRequestDispatcher(path).forward(request, response);
	}


	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       this.doGet(request, response);
	}

}
