package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Type;
import com.ecjtu.service.impl.TypeServiceImpl;

public class ShowTypesServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");

		response.setDateHeader("Expires", 0);
		response.setHeader("Pragma","no-cache"); 
		 
		int tid = Integer.parseInt(request.getParameter("tid"));
		 PrintWriter out = response.getWriter();
		 List<Type> type =TypeServiceImpl.getInstance().getTypesByTid(tid);
		 StringBuffer str = new StringBuffer("[");
		 for(Iterator<Type> i = type.iterator();i.hasNext();){
			 Type t = i.next();
	str.append("{id:").append(t.getId()).append(",name:\"").append(t.getName()).append("\"},");
		 
		 }
		 str.deleteCharAt(str.length()-1);
		 str.append("]");
		 out.print(str);
		 out.flush();
		  out.close();
//		 System.out.println(str);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
