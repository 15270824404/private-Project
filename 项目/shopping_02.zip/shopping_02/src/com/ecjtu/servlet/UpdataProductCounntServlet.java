package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.pojo.Product;
import com.ecjtu.service.impl.ProductServiceImpl;

public class UpdataProductCounntServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          int newAmount = Integer.parseInt(request.getParameter("newAmount"));
          int id = Integer.parseInt(request.getParameter("id"));
          Product product = ProductServiceImpl.getStance().getProductById(id);
          int tid = product.getParent().getId();
          int mistid = product.getChildren().getId();
          ProductServiceImpl.getStance().renewProductDaoAllCounnt(id, newAmount);
//          request.getRequestDispatcher("./manage/GoodsManage.jsp").forward(request, response);
         
          request.getRequestDispatcher("./showProductByTidMis.do?tid="+tid+"&mistid="+mistid).forward(request, response); 
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       this.doGet(request, response);
	}

}
