package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateCServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
         int tid = Integer.parseInt(request.getParameter("tid"));
         request.setAttribute("id", id);
         request.setAttribute("tid", tid);
         request.getRequestDispatcher("./manage/updateCtypes.jsp").forward(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
     this.doGet(request, response);
	}

}
