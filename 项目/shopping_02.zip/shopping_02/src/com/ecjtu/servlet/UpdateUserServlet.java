package com.ecjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecjtu.service.impl.UserServiceImpl;

public class UpdateUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		int id = Integer.parseInt(request.getParameter("id"));
		String realname = request.getParameter("truename");
		String address = request.getParameter("address");
		String province = request.getParameter("province");
		
		String city = request.getParameter("city");
		String area = request.getParameter("area");
		String postcode = request.getParameter("postcode");
		String phone = request.getParameter("telephone");
		UserServiceImpl.getInstance().updaUser(id, address, postcode, phone, realname, province, city, area);
		request.setAttribute("msg1", "地址栏修改成功");
		request.getRequestDispatcher("member.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
