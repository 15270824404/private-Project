package com.ecjtu.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.ecjtu.util.prop.PropUtil;


public class DBUtil {

	private static String  classNames ;
	private static String url ;
    private static String dbName ;
    private static String username;
    private static String password;
	private DBUtil(){}
	static{
		classNames = PropUtil.getValueKey("JDBC.properties","classNames");
		url = PropUtil.getValueKey("JDBC.properties","url");
		dbName = PropUtil.getValueKey("JDBC.properties","dbName");
		username = PropUtil.getValueKey("JDBC.properties","username");
		password = PropUtil.getValueKey("JDBC.properties","password");		
			try {
				Class.forName(classNames);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
	}
	public static Connection getConn(){
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url+dbName,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	public static PreparedStatement getPstmt(Connection conn,String sql){
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pstmt;
	}
	public static ResultSet getRs(PreparedStatement pstmt){
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	public static void getClose(Connection conn, PreparedStatement pstmt,ResultSet rs){
		if(rs !=null){
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			rs = null;
		}
		if(pstmt !=null){
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			pstmt = null;
		}
		if(conn !=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			conn = null;
		}
	}
}
