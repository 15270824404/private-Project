package com.ecjtu.util.prop;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropUtil {
				public static String getValueKey(String filName,String key){
					String str = null;
					Properties prop = new Properties();
					InputStream is = PropUtil.class.getClassLoader().getResourceAsStream(filName);	
				    try {
						prop.load(is);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally{
						try {
							is.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				    str = prop.getProperty(key);
				    return str;
				}

	}

